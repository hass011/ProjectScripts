import requests

# Test different time ranges
for hours, label in [(0.083, "5 min"), (0.25, "15 min"), (0.5, "30 min"), (1, "1 hour"), (2, "2 hours")]:
    r = requests.get(f'http://localhost:5001/api/feed/recent?hours={hours}&limit=10')
    data = r.json()
    print(f"{label:10} - Items: {data.get('total', 0)}")
