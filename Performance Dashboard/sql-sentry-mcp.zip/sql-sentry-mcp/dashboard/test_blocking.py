import requests
import json

r = requests.get('http://localhost:5001/api/feed/blocking')
print(f"Status: {r.status_code}")
data = r.json()
print(f"Error: {data.get('error', 'None')}")
