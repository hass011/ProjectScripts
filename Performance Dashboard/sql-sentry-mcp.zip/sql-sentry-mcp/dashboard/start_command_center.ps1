# Start DevOps Command Center Dashboard
# Advanced monitoring dashboard integrating SQL Sentry, PagerDuty, Jira, and Confluence

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "DevOps Command Center Dashboard" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Stop any existing Flask servers
Write-Host "Stopping existing Flask servers..." -ForegroundColor Yellow
Get-Process python -ErrorAction SilentlyContinue | Where-Object {
    $_.MainWindowTitle -match "flask" -or $_.CommandLine -match "app"
} | Stop-Process -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 2

# Check if .env file exists
if (-not (Test-Path ".env")) {
    Write-Host "WARNING: .env file not found!" -ForegroundColor Yellow
    Write-Host "Creating .env from template..." -ForegroundColor Yellow
    Copy-Item ".env.example" ".env"
    Write-Host ""
    Write-Host "Please edit .env file and configure:" -ForegroundColor Red
    Write-Host "  - PAGERDUTY_API_KEY" -ForegroundColor Red
    Write-Host "  - JIRA_USERNAME (your email)" -ForegroundColor Red
    Write-Host "  - CONFLUENCE_USERNAME (your email)" -ForegroundColor Red
    Write-Host ""
}

# Load environment variables
Write-Host "Loading environment variables..." -ForegroundColor Green
Get-Content .env | ForEach-Object {
    if ($_ -match '^([^=]+)=(.*)$') {
        $name = $matches[1].Trim()
        $value = $matches[2].Trim()
        [Environment]::SetEnvironmentVariable($name, $value, "Process")
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Starting Command Center..." -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Dashboard will be available at:" -ForegroundColor Green
Write-Host "  http://localhost:5000" -ForegroundColor Cyan
Write-Host ""
Write-Host "Features:" -ForegroundColor Yellow
Write-Host "  ✓ PagerDuty Incidents" -ForegroundColor White
Write-Host "  ✓ SQL Sentry Alerts & Blocking" -ForegroundColor White
Write-Host "  ✓ Jira Tickets & Sprint Board" -ForegroundColor White
Write-Host "  ✓ Confluence Runbooks" -ForegroundColor White
Write-Host "  ✓ Intelligent Correlation Engine" -ForegroundColor White
Write-Host "  ✓ MTTR Metrics" -ForegroundColor White
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

# Start Flask app
python app_v2.py
