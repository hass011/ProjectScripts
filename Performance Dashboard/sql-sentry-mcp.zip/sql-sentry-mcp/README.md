# SQL Sentry MCP Server

A Model Context Protocol (MCP) server that provides access to SQL Sentry monitoring data through the SentryOne database.

## Features

This MCP server provides the following tools:

- **get_active_alerts** - Retrieve current active alerts with filtering by severity
- **get_top_queries** - Get top queries by CPU, duration, or execution count
- **get_blocking_sessions** - View current blocking and blocked sessions
- **get_performance_metrics** - Fetch CPU, memory, and disk performance metrics
- **get_deadlocks** - Retrieve recent deadlock information

## Prerequisites

- Python 3.10 or higher
- SQL Sentry (SentryOne) installed and configured
- ODBC Driver 17 for SQL Server (or compatible driver)
- Access to the SentryOne database

## Installation

1. Install the package using `uv` or `pip`:

```bash
# Using uv (recommended)
uv pip install -e .

# Or using pip
pip install -e .
```

2. Ensure ODBC Driver 17 for SQL Server is installed:
   - Windows: Download from Microsoft's website
   - Linux: Install `msodbcsql17` package

## Configuration

### Environment Variables

Set the following environment variables:

- `SQL_SENTRY_SERVER` (required) - SQL Server instance hosting the SentryOne database (e.g., `SERVER\INSTANCE`)
- `SQL_SENTRY_DATABASE` (optional) - Database name (default: `SentryOne`)
- `SQL_SENTRY_USERNAME` (optional) - SQL authentication username (if not using Windows auth)
- `SQL_SENTRY_PASSWORD` (optional) - SQL authentication password (if not using Windows auth)

### MCP Configuration

Add to your `mcp_config.json`:

```json
{
  "mcpServers": {
    "sql-sentry": {
      "command": "python",
      "args": ["C:\\Users\\hassan.hassan\\CascadeProjects\\sql-sentry-mcp\\server.py"],
      "env": {
        "SQL_SENTRY_SERVER": "YOUR_SERVER\\INSTANCE",
        "SQL_SENTRY_DATABASE": "SentryOne",
        "SQL_SENTRY_USERNAME": "",
        "SQL_SENTRY_PASSWORD": ""
      }
    }
  }
}
```

**Note**: Leave `SQL_SENTRY_USERNAME` and `SQL_SENTRY_PASSWORD` empty to use Windows Authentication.

## Usage

Once configured, you can use the tools through your MCP client:

### Get Active Alerts
```
Get all critical alerts from SQL Sentry
```

### Get Top Queries
```
Show me the top 10 queries by CPU usage in the last 24 hours
```

### Get Blocking Sessions
```
List current blocking sessions with duration over 10 seconds
```

### Get Performance Metrics
```
Show CPU and memory metrics for SERVER01 in the last hour
```

### Get Deadlocks
```
Get recent deadlocks from the last 48 hours
```

## Database Schema Notes

This server assumes the following tables exist in the SentryOne database:

- `dbo.Alert` - Alert information
- `dbo.QueryStats` - Query statistics
- `dbo.BlockingSession` - Blocking session data
- `dbo.PerformanceMetric` - Performance metrics
- `dbo.Deadlock` - Deadlock information

**Important**: The actual SQL Sentry schema may differ. You may need to adjust the queries in `server.py` to match your SQL Sentry version's schema.

## Troubleshooting

### Connection Issues

1. Verify ODBC driver is installed:
   ```powershell
   Get-OdbcDriver | Where-Object {$_.Name -like "*SQL Server*"}
   ```

2. Test database connection:
   ```powershell
   sqlcmd -S YOUR_SERVER\INSTANCE -d SentryOne -Q "SELECT @@VERSION"
   ```

3. Check SQL Sentry database name:
   ```sql
   SELECT name FROM sys.databases WHERE name LIKE '%Sentry%'
   ```

### Schema Mismatches

If you get errors about missing tables or columns, you may need to:

1. Query your SQL Sentry database to find the correct table/column names
2. Update the SQL queries in `server.py` accordingly

Common SQL Sentry table variations:
- Alert tables: `Alert`, `AlertHistory`, `EventSourceAlert`
- Query tables: `QueryStore`, `PerformanceAnalysisQueryStatistics`
- Blocking tables: `BlockingSnapshot`, `BlockingChain`

## License

MIT
