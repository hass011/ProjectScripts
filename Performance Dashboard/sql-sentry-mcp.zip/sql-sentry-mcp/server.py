#!/usr/bin/env python3
"""
SQL Sentry MCP Server
Provides tools to query SQL Sentry monitoring data via the SentryOne database.
"""

import asyncio
import os
from typing import Any, Optional
import pyodbc
from mcp.server import Server
from mcp.types import Tool, TextContent
import mcp.server.stdio

app = Server("sql-sentry-mcp")

def get_connection():
    """Create database connection to SQL Sentry."""
    server = os.getenv("SQL_SENTRY_SERVER")
    database = os.getenv("SQL_SENTRY_DATABASE", "SentryOne")
    username = os.getenv("SQL_SENTRY_USERNAME")
    password = os.getenv("SQL_SENTRY_PASSWORD")
    
    if not server:
        raise ValueError("SQL_SENTRY_SERVER environment variable is required")
    
    if username and password:
        conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}"
    else:
        conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes"
    
    return pyodbc.connect(conn_str)

@app.list_tools()
async def list_tools() -> list[Tool]:
    """List available SQL Sentry tools."""
    return [
        Tool(
            name="get_active_alerts",
            description="Get current active alerts from SQL Sentry",
            inputSchema={
                "type": "object",
                "properties": {
                    "severity": {
                        "type": "string",
                        "description": "Filter by severity: Critical, Warning, Informational (optional)",
                        "enum": ["Critical", "Warning", "Informational"]
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of alerts to return (default: 50)",
                        "default": 50
                    }
                }
            }
        ),
        Tool(
            name="get_top_queries",
            description="Get top queries by CPU, duration, or execution count",
            inputSchema={
                "type": "object",
                "properties": {
                    "server_name": {
                        "type": "string",
                        "description": "SQL Server instance name (optional, returns all if not specified)"
                    },
                    "database_name": {
                        "type": "string",
                        "description": "Database name (optional)"
                    },
                    "metric": {
                        "type": "string",
                        "description": "Sort by: cpu, duration, executions (default: cpu)",
                        "enum": ["cpu", "duration", "executions"],
                        "default": "cpu"
                    },
                    "hours": {
                        "type": "integer",
                        "description": "Time window in hours (default: 24)",
                        "default": 24
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Number of queries to return (default: 20)",
                        "default": 20
                    }
                }
            }
        ),
        Tool(
            name="get_blocking_sessions",
            description="Get current blocking and blocked sessions",
            inputSchema={
                "type": "object",
                "properties": {
                    "server_name": {
                        "type": "string",
                        "description": "SQL Server instance name (optional)"
                    },
                    "min_duration_seconds": {
                        "type": "integer",
                        "description": "Minimum blocking duration in seconds (default: 5)",
                        "default": 5
                    }
                }
            }
        ),
        Tool(
            name="get_performance_metrics",
            description="Get CPU, memory, and disk performance metrics",
            inputSchema={
                "type": "object",
                "properties": {
                    "server_name": {
                        "type": "string",
                        "description": "SQL Server instance name (required)"
                    },
                    "hours": {
                        "type": "integer",
                        "description": "Time window in hours (default: 1)",
                        "default": 1
                    },
                    "metric_type": {
                        "type": "string",
                        "description": "Metric type: cpu, memory, disk, all (default: all)",
                        "enum": ["cpu", "memory", "disk", "all"],
                        "default": "all"
                    }
                },
                "required": ["server_name"]
            }
        ),
        Tool(
            name="get_deadlocks",
            description="Get recent deadlock information",
            inputSchema={
                "type": "object",
                "properties": {
                    "server_name": {
                        "type": "string",
                        "description": "SQL Server instance name (optional)"
                    },
                    "hours": {
                        "type": "integer",
                        "description": "Time window in hours (default: 24)",
                        "default": 24
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Number of deadlocks to return (default: 10)",
                        "default": 10
                    }
                }
            }
        ),
        Tool(
            name="discover_schema",
            description="Discover SQL Sentry database schema (tables and columns)",
            inputSchema={
                "type": "object",
                "properties": {
                    "search_term": {
                        "type": "string",
                        "description": "Optional search term to filter tables (e.g., 'alert', 'query', 'block')"
                    }
                }
            }
        )
    ]

@app.call_tool()
async def call_tool(name: str, arguments: Any) -> list[TextContent]:
    """Handle tool calls."""
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        if name == "get_active_alerts":
            severity = arguments.get("severity")
            limit = arguments.get("limit", 50)
            
            severity_map = {"Critical": 3, "Warning": 2, "Informational": 1}
            
            query = """
                SELECT TOP (?)
                    a.ID,
                    a.ObjectName,
                    a.ParentObjectName,
                    a.Severity,
                    a.NormalizedStartTimeUtc,
                    a.NormalizedEndTimeUtc,
                    a.IsResolved,
                    a.Duration,
                    a.AlertingChannelLogStatus
                FROM dbo.AlertingChannelLog a
                WHERE CAST(a.NormalizedStartTimeUtc as DATE) = CAST(GETDATE() as DATE)
            """
            params = [limit]
            
            if severity:
                query += " AND a.Severity = ?"
                params.append(severity_map.get(severity, 2))
            
            query += " ORDER BY a.NormalizedStartTimeUtc DESC"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            if not rows:
                return [TextContent(type="text", text="No alerts found for today.")]
            
            total = len(rows)
            active = sum(1 for r in rows if not r.IsResolved)
            resolved = sum(1 for r in rows if r.IsResolved)
            critical = sum(1 for r in rows if r.Severity == 3)
            warning = sum(1 for r in rows if r.Severity == 2)
            info = sum(1 for r in rows if r.Severity == 1)
            
            result = f"**SQL Sentry Alerts for Today**\n\n"
            result += f"Total: {total} | Active: {active} | Resolved: {resolved}\n"
            result += f"Critical: {critical} | Warning: {warning} | Info: {info}\n\n"
            result += "=" * 80 + "\n\n"
            
            for row in rows:
                severity_name = {1: "Info", 2: "Warning", 3: "Critical"}.get(row.Severity, "Unknown")
                status = "ACTIVE" if not row.IsResolved else "Resolved"
                duration_min = row.Duration / 60000000000 if row.Duration else 0
                
                result += f"**[{severity_name}] {row.ObjectName}** - {status}\n"
                result += f"Server: {row.ParentObjectName or 'N/A'}\n"
                result += f"Started: {row.NormalizedStartTimeUtc}\n"
                if row.IsResolved and row.NormalizedEndTimeUtc:
                    result += f"Ended: {row.NormalizedEndTimeUtc}\n"
                if duration_min > 0:
                    result += f"Duration: {duration_min:.1f} minutes\n"
                result += "-" * 80 + "\n\n"
            
            return [TextContent(type="text", text=result)]
        
        elif name == "get_top_queries":
            server_name = arguments.get("server_name")
            database_name = arguments.get("database_name")
            metric = arguments.get("metric", "cpu")
            hours = arguments.get("hours", 24)
            limit = arguments.get("limit", 20)
            
            metric_column = {
                "cpu": "TotalCPU",
                "duration": "TotalDuration",
                "executions": "ExecutionCount"
            }.get(metric, "TotalCPU")
            
            query = f"""
                SELECT TOP (?)
                    qs.QueryHash,
                    qs.QueryText,
                    qs.DatabaseName,
                    qs.ServerName,
                    qs.ExecutionCount,
                    qs.TotalCPU,
                    qs.AvgCPU,
                    qs.TotalDuration,
                    qs.AvgDuration,
                    qs.LastExecutionTime
                FROM dbo.QueryStats qs
                WHERE qs.LastExecutionTime >= DATEADD(HOUR, -?, GETDATE())
            """
            params = [limit, hours]
            
            if server_name:
                query += " AND qs.ServerName = ?"
                params.append(server_name)
            
            if database_name:
                query += " AND qs.DatabaseName = ?"
                params.append(database_name)
            
            query += f" ORDER BY qs.{metric_column} DESC"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            if not rows:
                return [TextContent(type="text", text="No query statistics found for the specified criteria.")]
            
            result = f"Top {len(rows)} queries by {metric} (last {hours} hours):\n\n"
            for idx, row in enumerate(rows, 1):
                result += f"**#{idx} - Query Hash**: {row.QueryHash}\n"
                result += f"**Server**: {row.ServerName}\n"
                result += f"**Database**: {row.DatabaseName}\n"
                result += f"**Executions**: {row.ExecutionCount:,}\n"
                result += f"**Total CPU**: {row.TotalCPU:,.2f} ms\n"
                result += f"**Avg CPU**: {row.AvgCPU:,.2f} ms\n"
                result += f"**Total Duration**: {row.TotalDuration:,.2f} ms\n"
                result += f"**Avg Duration**: {row.AvgDuration:,.2f} ms\n"
                result += f"**Last Execution**: {row.LastExecutionTime}\n"
                result += f"**Query Text**:\n```sql\n{row.QueryText[:500]}{'...' if len(row.QueryText) > 500 else ''}\n```\n"
                result += "-" * 80 + "\n\n"
            
            return [TextContent(type="text", text=result)]
        
        elif name == "get_blocking_sessions":
            server_name = arguments.get("server_name")
            min_duration = arguments.get("min_duration_seconds", 5)
            
            query = """
                SELECT
                    b.BlockingSessionID,
                    b.BlockedSessionID,
                    b.ServerName,
                    b.DatabaseName,
                    b.BlockingDurationSeconds,
                    b.BlockingQuery,
                    b.BlockedQuery,
                    b.WaitType,
                    b.WaitResource,
                    b.DetectedTime
                FROM dbo.BlockingSession b
                WHERE b.IsActive = 1
                  AND b.BlockingDurationSeconds >= ?
            """
            params = [min_duration]
            
            if server_name:
                query += " AND b.ServerName = ?"
                params.append(server_name)
            
            query += " ORDER BY b.BlockingDurationSeconds DESC"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            if not rows:
                return [TextContent(type="text", text="No blocking sessions found.")]
            
            result = f"Found {len(rows)} blocking chain(s):\n\n"
            for row in rows:
                result += f"**Blocking SPID**: {row.BlockingSessionID} → **Blocked SPID**: {row.BlockedSessionID}\n"
                result += f"**Server**: {row.ServerName}\n"
                result += f"**Database**: {row.DatabaseName}\n"
                result += f"**Duration**: {row.BlockingDurationSeconds} seconds\n"
                result += f"**Wait Type**: {row.WaitType}\n"
                result += f"**Wait Resource**: {row.WaitResource}\n"
                result += f"**Detected**: {row.DetectedTime}\n"
                result += f"**Blocking Query**:\n```sql\n{row.BlockingQuery[:300] if row.BlockingQuery else 'N/A'}\n```\n"
                result += f"**Blocked Query**:\n```sql\n{row.BlockedQuery[:300] if row.BlockedQuery else 'N/A'}\n```\n"
                result += "-" * 80 + "\n\n"
            
            return [TextContent(type="text", text=result)]
        
        elif name == "get_performance_metrics":
            server_name = arguments["server_name"]
            hours = arguments.get("hours", 1)
            metric_type = arguments.get("metric_type", "all")
            
            result = f"Performance metrics for **{server_name}** (last {hours} hour(s)):\n\n"
            
            if metric_type in ["cpu", "all"]:
                query = """
                    SELECT
                        AVG(CPUPercent) as AvgCPU,
                        MAX(CPUPercent) as MaxCPU,
                        MIN(CPUPercent) as MinCPU
                    FROM dbo.PerformanceMetric
                    WHERE ServerName = ?
                      AND MetricTime >= DATEADD(HOUR, -?, GETDATE())
                      AND MetricType = 'CPU'
                """
                cursor.execute(query, [server_name, hours])
                row = cursor.fetchone()
                if row and row.AvgCPU is not None:
                    result += f"**CPU Usage**:\n"
                    result += f"  - Average: {row.AvgCPU:.2f}%\n"
                    result += f"  - Maximum: {row.MaxCPU:.2f}%\n"
                    result += f"  - Minimum: {row.MinCPU:.2f}%\n\n"
            
            if metric_type in ["memory", "all"]:
                query = """
                    SELECT
                        AVG(MemoryUsedMB) as AvgMemory,
                        MAX(MemoryUsedMB) as MaxMemory,
                        AVG(MemoryAvailableMB) as AvgAvailable
                    FROM dbo.PerformanceMetric
                    WHERE ServerName = ?
                      AND MetricTime >= DATEADD(HOUR, -?, GETDATE())
                      AND MetricType = 'Memory'
                """
                cursor.execute(query, [server_name, hours])
                row = cursor.fetchone()
                if row and row.AvgMemory is not None:
                    result += f"**Memory Usage**:\n"
                    result += f"  - Average Used: {row.AvgMemory:,.0f} MB\n"
                    result += f"  - Maximum Used: {row.MaxMemory:,.0f} MB\n"
                    result += f"  - Average Available: {row.AvgAvailable:,.0f} MB\n\n"
            
            if metric_type in ["disk", "all"]:
                query = """
                    SELECT
                        DriveLetter,
                        AVG(DiskQueueLength) as AvgQueueLength,
                        MAX(DiskQueueLength) as MaxQueueLength,
                        AVG(DiskReadLatencyMS) as AvgReadLatency,
                        AVG(DiskWriteLatencyMS) as AvgWriteLatency
                    FROM dbo.PerformanceMetric
                    WHERE ServerName = ?
                      AND MetricTime >= DATEADD(HOUR, -?, GETDATE())
                      AND MetricType = 'Disk'
                    GROUP BY DriveLetter
                """
                cursor.execute(query, [server_name, hours])
                rows = cursor.fetchall()
                if rows:
                    result += f"**Disk Performance**:\n"
                    for row in rows:
                        result += f"  - Drive {row.DriveLetter}:\n"
                        result += f"    - Avg Queue Length: {row.AvgQueueLength:.2f}\n"
                        result += f"    - Max Queue Length: {row.MaxQueueLength:.2f}\n"
                        result += f"    - Avg Read Latency: {row.AvgReadLatency:.2f} ms\n"
                        result += f"    - Avg Write Latency: {row.AvgWriteLatency:.2f} ms\n"
            
            return [TextContent(type="text", text=result)]
        
        elif name == "get_deadlocks":
            server_name = arguments.get("server_name")
            hours = arguments.get("hours", 24)
            limit = arguments.get("limit", 10)
            
            query = f"""
                SELECT TOP (?)
                    d.DeadlockID,
                    d.ServerName,
                    d.DatabaseName,
                    d.DeadlockTime,
                    d.VictimSPID,
                    d.VictimQuery,
                    d.DeadlockGraph
                FROM dbo.Deadlock d
                WHERE d.DeadlockTime >= DATEADD(HOUR, -?, GETDATE())
            """
            params = [limit, hours]
            
            if server_name:
                query += " AND d.ServerName = ?"
                params.append(server_name)
            
            query += " ORDER BY d.DeadlockTime DESC"
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            if not rows:
                return [TextContent(type="text", text="No deadlocks found in the specified time window.")]
            
            result = f"Found {len(rows)} deadlock(s) in the last {hours} hours:\n\n"
            for row in rows:
                result += f"**Deadlock ID**: {row.DeadlockID}\n"
                result += f"**Server**: {row.ServerName}\n"
                result += f"**Database**: {row.DatabaseName}\n"
                result += f"**Time**: {row.DeadlockTime}\n"
                result += f"**Victim SPID**: {row.VictimSPID}\n"
                result += f"**Victim Query**:\n```sql\n{row.VictimQuery[:400] if row.VictimQuery else 'N/A'}\n```\n"
                result += "-" * 80 + "\n\n"
            
            return [TextContent(type="text", text=result)]
        
        elif name == "discover_schema":
            search_term = arguments.get("search_term", "").lower()
            
            query = """
                SELECT TABLE_SCHEMA, TABLE_NAME,
                       (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS c 
                        WHERE c.TABLE_SCHEMA = t.TABLE_SCHEMA 
                        AND c.TABLE_NAME = t.TABLE_NAME) as ColumnCount
                FROM INFORMATION_SCHEMA.TABLES t
                WHERE TABLE_TYPE = 'BASE TABLE'
                ORDER BY TABLE_NAME
            """
            
            cursor.execute(query)
            rows = cursor.fetchall()
            
            if search_term:
                rows = [r for r in rows if search_term in r.TABLE_NAME.lower()]
            
            if not rows:
                return [TextContent(type="text", text=f"No tables found{' matching: ' + search_term if search_term else ''}.")]
            
            result = f"SQL Sentry Database Schema ({len(rows)} tables{' matching: ' + search_term if search_term else ''}):\n\n"
            
            for row in rows:
                result += f"**{row.TABLE_SCHEMA}.{row.TABLE_NAME}** ({row.ColumnCount} columns)\n"
                
                cursor.execute("""
                    SELECT TOP 10 COLUMN_NAME, DATA_TYPE, IS_NULLABLE
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
                    ORDER BY ORDINAL_POSITION
                """, row.TABLE_SCHEMA, row.TABLE_NAME)
                
                cols = cursor.fetchall()
                for col in cols:
                    nullable = "NULL" if col.IS_NULLABLE == "YES" else "NOT NULL"
                    result += f"  - {col.COLUMN_NAME} ({col.DATA_TYPE}, {nullable})\n"
                result += "\n"
            
            return [TextContent(type="text", text=result)]
        
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
    
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]
    
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()

async def main():
    """Run the MCP server."""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )

if __name__ == "__main__":
    asyncio.run(main())
