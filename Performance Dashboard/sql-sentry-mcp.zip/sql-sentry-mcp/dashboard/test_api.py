import requests
import json

r = requests.get('http://localhost:5001/api/feed/recent?hours=1&limit=5')
data = r.json()

print(f"Total items: {len(data.get('items', []))}")
print("\nFirst 3 items:")
for item in data.get('items', [])[:3]:
    print(f"\nType: {item.get('type')}")
    print(f"Severity: {item.get('severity')}")
    print(f"Object: {item.get('object', '')[:50]}")
