import pyodbc

conn_str = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=elkcrpsql02;"
    "DATABASE=SentryOne;"
    "UID=Windsirf;"
    "PWD=Cday321"
)

conn = pyodbc.connect(conn_str)
cursor = conn.cursor()

print("PerformanceAnalysisTraceData columns:")
cursor.execute("SELECT TOP 1 * FROM PerformanceAnalysisTraceData")
for col in cursor.description:
    print(f"  - {col[0]}")

print("\nQueryStats columns:")
cursor.execute("SELECT TOP 1 * FROM QueryStats")
for col in cursor.description:
    print(f"  - {col[0]}")

cursor.close()
conn.close()
