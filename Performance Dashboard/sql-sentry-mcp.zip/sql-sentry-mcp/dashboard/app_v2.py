#!/usr/bin/env python3
"""
DevOps Command Center Dashboard
Integrates SQL Sentry, PagerDuty, Jira, and Confluence for unified operations monitoring
"""

from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import requests
import pyodbc
from datetime import datetime, timedelta, timezone
import os
from collections import defaultdict
from pathlib import Path
import base64

app = Flask(__name__)
CORS(app)

# Load environment variables from .env file
env_path = Path(__file__).parent / '.env'
if env_path.exists():
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key.strip()] = value.strip()

# Configuration
PAGERDUTY_API_KEY = os.getenv('PAGERDUTY_API_KEY', 'REPLACE_ME')
PAGERDUTY_API_HOST = "https://api.pagerduty.com"

SQL_SERVER = os.getenv('SQL_SERVER', 'elkcrpsql02')
SQL_DATABASE = os.getenv('SQL_DATABASE', 'SentryOne')
SQL_USERNAME = os.getenv('SQL_USERNAME', 'Windsirf')
SQL_PASSWORD = os.getenv('SQL_PASSWORD', 'Cday321')

JIRA_URL = os.getenv('JIRA_URL', 'https://payroc.atlassian.net')
JIRA_USERNAME = os.getenv('JIRA_USERNAME', 'firstname.lastname@payroc.com')
JIRA_API_TOKEN = os.getenv('JIRA_API_TOKEN', '')

CONFLUENCE_URL = os.getenv('CONFLUENCE_URL', 'https://payroc.atlassian.net/wiki')
CONFLUENCE_USERNAME = os.getenv('CONFLUENCE_USERNAME', 'firstname.lastname@payroc.com')
CONFLUENCE_API_TOKEN = os.getenv('CONFLUENCE_API_TOKEN', '')

def get_sql_connection():
    """Get SQL Server connection"""
    conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={SQL_SERVER};DATABASE={SQL_DATABASE};UID={SQL_USERNAME};PWD={SQL_PASSWORD}"
    return pyodbc.connect(conn_str, timeout=10)

def get_pagerduty_headers():
    """Get PagerDuty API headers"""
    return {
        "Authorization": f"Token token={PAGERDUTY_API_KEY}",
        "Accept": "application/vnd.pagerduty+json;version=2",
        "Content-Type": "application/json"
    }

def get_jira_auth():
    """Get Jira authentication"""
    auth_str = f"{JIRA_USERNAME}:{JIRA_API_TOKEN}"
    b64_auth = base64.b64encode(auth_str.encode()).decode()
    return {
        "Authorization": f"Basic {b64_auth}",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }

def get_confluence_auth():
    """Get Confluence authentication"""
    auth_str = f"{CONFLUENCE_USERNAME}:{CONFLUENCE_API_TOKEN}"
    b64_auth = base64.b64encode(auth_str.encode()).decode()
    return {
        "Authorization": f"Basic {b64_auth}",
        "Accept": "application/json"
    }

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('command_center.html')

@app.route('/api/overview')
def get_overview():
    """Get complete overview of all systems"""
    try:
        overview = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'incidents': {'total': 0, 'triggered': 0, 'acknowledged': 0},
            'alerts': {'total': 0, 'active': 0, 'critical': 0},
            'blocking': {'chains': 0, 'sessions': 0},
            'jira': {'open': 0, 'in_progress': 0, 'blocked': 0},
            'oncall': {'name': 'Unknown', 'contact': ''}
        }
        
        # Get PagerDuty summary
        try:
            pd_response = requests.get(
                f"{PAGERDUTY_API_HOST}/incidents",
                headers=get_pagerduty_headers(),
                params={'statuses[]': ['triggered', 'acknowledged'], 'limit': 100},
                timeout=5
            )
            if pd_response.status_code == 200:
                incidents = pd_response.json().get('incidents', [])
                overview['incidents']['total'] = len(incidents)
                overview['incidents']['triggered'] = sum(1 for i in incidents if i['status'] == 'triggered')
                overview['incidents']['acknowledged'] = sum(1 for i in incidents if i['status'] == 'acknowledged')
        except:
            pass
        
        # Get SQL Sentry summary
        try:
            conn = get_sql_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT 
                    COUNT(*) as Total,
                    SUM(CASE WHEN IsResolved = 0 THEN 1 ELSE 0 END) as Active,
                    SUM(CASE WHEN Severity = 3 THEN 1 ELSE 0 END) as Critical
                FROM dbo.AlertingChannelLog
                WHERE NormalizedStartTimeUtc >= DATEADD(HOUR, -24, GETDATE())
            """)
            row = cursor.fetchone()
            if row:
                overview['alerts']['total'] = row.Total or 0
                overview['alerts']['active'] = row.Active or 0
                overview['alerts']['critical'] = row.Critical or 0
            
            cursor.execute("""
                SELECT 
                    COUNT(DISTINCT bc.ID) as Chains,
                    COUNT(*) as Sessions
                FROM dbo.BlockChain bc
                INNER JOIN dbo.BlockChainDetail bcd ON bc.ID = bcd.BlockChainID
                WHERE bc.StartTime >= DATEADD(HOUR, -24, GETDATE())
            """)
            row = cursor.fetchone()
            if row:
                overview['blocking']['chains'] = row.Chains or 0
                overview['blocking']['sessions'] = row.Sessions or 0
            
            cursor.close()
            conn.close()
        except:
            pass
        
        # Get Jira summary
        try:
            username = JIRA_USERNAME.split('@')[0] if '@' in JIRA_USERNAME else JIRA_USERNAME
            jql_query = f'assignee = "{username}" AND resolution = Unresolved'
            jira_response = requests.get(
                f"{JIRA_URL}/rest/api/2/search",
                headers=get_jira_auth(),
                params={'jql': jql_query, 'maxResults': 100},
                timeout=5
            )
            if jira_response.status_code == 200:
                issues = jira_response.json().get('issues', [])
                overview['jira']['open'] = len(issues)
                overview['jira']['in_progress'] = sum(1 for i in issues if i['fields']['status']['name'] == 'In Progress')
                overview['jira']['blocked'] = sum(1 for i in issues if 'blocked' in i['fields']['status']['name'].lower())
        except:
            pass
        
        # Get on-call info
        try:
            oncall_response = requests.get(
                f"{PAGERDUTY_API_HOST}/oncalls",
                headers=get_pagerduty_headers(),
                params={'include[]': 'users'},
                timeout=5
            )
            if oncall_response.status_code == 200:
                oncalls = oncall_response.json().get('oncalls', [])
                if oncalls:
                    user = oncalls[0].get('user', {})
                    overview['oncall']['name'] = user.get('summary', 'Unknown')
                    overview['oncall']['contact'] = user.get('email', '')
        except:
            pass
        
        return jsonify(overview)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/pagerduty/incidents')
def get_pagerduty_incidents():
    """Fetch recent PagerDuty incidents"""
    try:
        hours = int(request.args.get('hours', 24))
        since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        
        url = f"{PAGERDUTY_API_HOST}/incidents"
        params = {
            'since': since,
            'limit': 100,
            'statuses[]': ['triggered', 'acknowledged']
        }
        
        response = requests.get(url, headers=get_pagerduty_headers(), params=params, timeout=10)
        response.raise_for_status()
        
        incidents = response.json().get('incidents', [])
        
        summary = {
            'total': len(incidents),
            'triggered': sum(1 for i in incidents if i['status'] == 'triggered'),
            'acknowledged': sum(1 for i in incidents if i['status'] == 'acknowledged'),
            'high_urgency': sum(1 for i in incidents if i['urgency'] == 'high'),
            'incidents': [{
                'id': i['id'],
                'incident_number': i['incident_number'],
                'title': i['title'],
                'status': i['status'],
                'urgency': i['urgency'],
                'created_at': i['created_at'],
                'service': i['service']['summary'] if i.get('service') else 'Unknown',
                'assignees': [a['summary'] for a in i.get('assignments', [])]
            } for i in incidents[:50]]
        }
        
        return jsonify(summary)
    except Exception as e:
        return jsonify({'error': str(e), 'incidents': [], 'total': 0}), 500

@app.route('/api/sentry/alerts')
def get_sentry_alerts():
    """Fetch recent SQL Sentry alerts"""
    try:
        hours = int(request.args.get('hours', 24))
        since = datetime.now() - timedelta(hours=hours)
        
        conn = get_sql_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                ID,
                ObjectName,
                ParentObjectName,
                Severity,
                NormalizedStartTimeUtc,
                NormalizedEndTimeUtc,
                IsResolved,
                Duration
            FROM dbo.AlertingChannelLog
            WHERE NormalizedStartTimeUtc >= ?
            ORDER BY NormalizedStartTimeUtc DESC
        """, since)
        
        rows = cursor.fetchall()
        
        alerts = []
        severity_counts = {1: 0, 2: 0, 3: 0}
        active_count = 0
        
        for row in rows:
            severity_counts[row.Severity] = severity_counts.get(row.Severity, 0) + 1
            if not row.IsResolved:
                active_count += 1
            
            alerts.append({
                'id': row.ID,
                'object': row.ObjectName,
                'server': row.ParentObjectName or 'Unknown',
                'severity': {1: 'Info', 2: 'Warning', 3: 'Critical'}.get(row.Severity, 'Unknown'),
                'severity_level': row.Severity,
                'started': row.NormalizedStartTimeUtc.isoformat() if row.NormalizedStartTimeUtc else None,
                'ended': row.NormalizedEndTimeUtc.isoformat() if row.NormalizedEndTimeUtc else None,
                'resolved': row.IsResolved,
                'duration_minutes': (row.Duration / 60000000000) if row.Duration else 0
            })
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'total': len(alerts),
            'active': active_count,
            'critical': severity_counts.get(3, 0),
            'warning': severity_counts.get(2, 0),
            'info': severity_counts.get(1, 0),
            'alerts': alerts[:100]
        })
    except Exception as e:
        return jsonify({'error': str(e), 'alerts': [], 'total': 0}), 500

@app.route('/api/sentry/blocking')
def get_sentry_blocking():
    """Fetch recent blocking sessions"""
    try:
        hours = int(request.args.get('hours', 24))
        since = datetime.now() - timedelta(hours=hours)
        
        conn = get_sql_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                bc.ID as BlockChainID,
                bc.StartTime,
                bc.EndTime,
                DATEDIFF(SECOND, bc.StartTime, ISNULL(bc.EndTime, GETDATE())) as DurationSeconds,
                bcd.SPID,
                bcd.BlockedBySpid,
                bcd.WaitText,
                bcd.WaitTime,
                bcd.DatabaseName,
                bcg.ProgramName,
                bcg.LoginName
            FROM dbo.BlockChain bc
            INNER JOIN dbo.BlockChainDetail bcd ON bc.ID = bcd.BlockChainID
            LEFT JOIN dbo.BlockChainGroup bcg ON bc.BlockChainGroupID = bcg.ID
            WHERE bc.StartTime >= ?
            ORDER BY DurationSeconds DESC
        """, since)
        
        rows = cursor.fetchall()
        
        blocking_chains = defaultdict(list)
        for row in rows:
            blocking_chains[row.BlockChainID].append({
                'spid': row.SPID,
                'blocked_by': row.BlockedBySpid,
                'wait_type': row.WaitText or 'N/A',
                'wait_time_ms': row.WaitTime,
                'database': row.DatabaseName,
                'program': row.ProgramName,
                'login': row.LoginName,
                'duration_seconds': row.DurationSeconds
            })
        
        chains = []
        for chain_id, sessions in blocking_chains.items():
            chains.append({
                'chain_id': chain_id,
                'session_count': len(sessions),
                'max_duration': max(s['duration_seconds'] for s in sessions),
                'sessions': sessions
            })
        
        # Sort by max duration
        chains.sort(key=lambda x: x['max_duration'], reverse=True)
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'total_chains': len(chains),
            'total_sessions': sum(len(c['sessions']) for c in chains),
            'chains': chains[:50]
        })
    except Exception as e:
        return jsonify({'error': str(e), 'chains': [], 'total_chains': 0}), 500

@app.route('/api/jira/my-tickets')
def get_jira_my_tickets():
    """Get current user's Jira tickets"""
    try:
        # Extract username from email (hassan.hassan from hassan.hassan@payroc.com)
        username = JIRA_USERNAME.split('@')[0] if '@' in JIRA_USERNAME else JIRA_USERNAME
        # Try simplified query first
        default_jql = f'assignee = {username} ORDER BY updated DESC'
        jql = request.args.get('jql', default_jql)
        max_results = int(request.args.get('limit', 50))
        
        response = requests.get(
            f"{JIRA_URL}/rest/api/2/search",
            headers=get_jira_auth(),
            params={'jql': jql, 'maxResults': max_results, 'fields': 'summary,status,priority,assignee,created,updated'},
            timeout=10
        )
        response.raise_for_status()
        
        data = response.json()
        issues = data.get('issues', [])
        
        tickets = [{
            'key': i['key'],
            'summary': i['fields']['summary'],
            'status': i['fields']['status']['name'],
            'priority': i['fields']['priority']['name'] if i['fields'].get('priority') else 'None',
            'assignee': i['fields']['assignee']['displayName'] if i['fields'].get('assignee') else 'Unassigned',
            'created': i['fields']['created'],
            'updated': i['fields']['updated']
        } for i in issues]
        
        status_counts = defaultdict(int)
        for t in tickets:
            status_counts[t['status']] += 1
        
        return jsonify({
            'total': len(tickets),
            'status_counts': dict(status_counts),
            'tickets': tickets
        })
    except Exception as e:
        return jsonify({'error': str(e), 'tickets': [], 'total': 0}), 500

@app.route('/api/jira/sprint')
def get_jira_sprint():
    """Get current sprint information"""
    try:
        # Get active sprints
        response = requests.get(
            f"{JIRA_URL}/rest/agile/1.0/board",
            headers=get_jira_auth(),
            params={'type': 'scrum'},
            timeout=10
        )
        
        if response.status_code != 200:
            return jsonify({'error': 'No boards found', 'sprint': None}), 404
        
        boards = response.json().get('values', [])
        if not boards:
            return jsonify({'error': 'No boards found', 'sprint': None}), 404
        
        board_id = boards[0]['id']
        
        # Get active sprint
        sprint_response = requests.get(
            f"{JIRA_URL}/rest/agile/1.0/board/{board_id}/sprint",
            headers=get_jira_auth(),
            params={'state': 'active'},
            timeout=10
        )
        
        sprints = sprint_response.json().get('values', [])
        if not sprints:
            return jsonify({'sprint': None, 'issues': []})
        
        sprint = sprints[0]
        sprint_id = sprint['id']
        
        # Get sprint issues
        issues_response = requests.get(
            f"{JIRA_URL}/rest/agile/1.0/sprint/{sprint_id}/issue",
            headers=get_jira_auth(),
            params={'maxResults': 100},
            timeout=10
        )
        
        issues = issues_response.json().get('issues', [])
        
        sprint_data = {
            'name': sprint['name'],
            'state': sprint['state'],
            'start_date': sprint.get('startDate'),
            'end_date': sprint.get('endDate'),
            'total_issues': len(issues),
            'by_status': defaultdict(int),
            'issues': []
        }
        
        for issue in issues:
            status = issue['fields']['status']['name']
            sprint_data['by_status'][status] += 1
            sprint_data['issues'].append({
                'key': issue['key'],
                'summary': issue['fields']['summary'],
                'status': status,
                'assignee': issue['fields']['assignee']['displayName'] if issue['fields'].get('assignee') else 'Unassigned'
            })
        
        sprint_data['by_status'] = dict(sprint_data['by_status'])
        
        return jsonify(sprint_data)
    except Exception as e:
        return jsonify({'error': str(e), 'sprint': None}), 500

@app.route('/api/confluence/runbooks')
def get_confluence_runbooks():
    """Get recent runbooks from Confluence"""
    try:
        search_query = request.args.get('q', 'runbook OR troubleshooting OR incident')
        
        response = requests.get(
            f"{CONFLUENCE_URL}/rest/api/content/search",
            headers=get_confluence_auth(),
            params={'cql': f'type=page AND text~"{search_query}"', 'limit': 20},
            timeout=10
        )
        
        if response.status_code != 200:
            return jsonify({'runbooks': [], 'total': 0})
        
        results = response.json().get('results', [])
        
        runbooks = [{
            'id': r['id'],
            'title': r['title'],
            'url': f"{CONFLUENCE_URL}/pages/viewpage.action?pageId={r['id']}",
            'space': r['_expandable'].get('space', '').split('/')[-1] if r.get('_expandable') else 'Unknown'
        } for r in results]
        
        return jsonify({
            'total': len(runbooks),
            'runbooks': runbooks
        })
    except Exception as e:
        return jsonify({'error': str(e), 'runbooks': [], 'total': 0}), 500

@app.route('/api/correlation/advanced')
def get_advanced_correlation():
    """Advanced correlation between PagerDuty, SQL Sentry, and Jira"""
    try:
        hours = int(request.args.get('hours', 24))
        time_window = timedelta(minutes=10)  # Correlation window
        
        correlations = []
        
        # Get PagerDuty incidents
        pd_response = requests.get(
            f"{PAGERDUTY_API_HOST}/incidents",
            headers=get_pagerduty_headers(),
            params={
                'since': (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(),
                'limit': 100
            },
            timeout=10
        )
        
        if pd_response.status_code != 200:
            return jsonify({'correlations': [], 'total': 0})
        
        incidents = pd_response.json().get('incidents', [])
        
        # Get SQL Sentry alerts
        conn = get_sql_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT ID, ObjectName, ParentObjectName, Severity, NormalizedStartTimeUtc
            FROM dbo.AlertingChannelLog
            WHERE NormalizedStartTimeUtc >= DATEADD(HOUR, -?, GETDATE())
        """, hours)
        alerts = cursor.fetchall()
        
        # Get Jira tickets
        jira_response = requests.get(
            f"{JIRA_URL}/rest/api/2/search",
            headers=get_jira_auth(),
            params={
                'jql': f'created >= -{hours}h ORDER BY created DESC',
                'maxResults': 100,
                'fields': 'summary,created,status'
            },
            timeout=10
        )
        jira_tickets = jira_response.json().get('issues', []) if jira_response.status_code == 200 else []
        
        # Correlate
        for incident in incidents:
            incident_time = datetime.fromisoformat(incident['created_at'].replace('Z', '+00:00'))
            correlation = {
                'incident': {
                    'id': incident['id'],
                    'number': incident['incident_number'],
                    'title': incident['title'],
                    'time': incident['created_at'],
                    'service': incident['service']['summary'] if incident.get('service') else 'Unknown'
                },
                'alerts': [],
                'tickets': []
            }
            
            # Find matching alerts
            for alert in alerts:
                if alert.NormalizedStartTimeUtc:
                    alert_time = alert.NormalizedStartTimeUtc.replace(tzinfo=timezone.utc)
                    time_diff = abs((incident_time - alert_time).total_seconds())
                    
                    if time_diff <= time_window.total_seconds():
                        correlation['alerts'].append({
                            'id': alert.ID,
                            'object': alert.ObjectName,
                            'server': alert.ParentObjectName,
                            'severity': {1: 'Info', 2: 'Warning', 3: 'Critical'}.get(alert.Severity, 'Unknown'),
                            'time_diff_seconds': int(time_diff)
                        })
            
            # Find matching Jira tickets
            for ticket in jira_tickets:
                ticket_time = datetime.fromisoformat(ticket['fields']['created'].replace('Z', '+00:00'))
                time_diff = abs((incident_time - ticket_time).total_seconds())
                
                if time_diff <= time_window.total_seconds():
                    correlation['tickets'].append({
                        'key': ticket['key'],
                        'summary': ticket['fields']['summary'],
                        'status': ticket['fields']['status']['name'],
                        'time_diff_seconds': int(time_diff)
                    })
            
            if correlation['alerts'] or correlation['tickets']:
                correlations.append(correlation)
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'total': len(correlations),
            'correlations': correlations
        })
    except Exception as e:
        return jsonify({'error': str(e), 'correlations': [], 'total': 0}), 500

@app.route('/api/metrics/mttr')
def get_mttr_metrics():
    """Calculate Mean Time To Resolution metrics"""
    try:
        hours = int(request.args.get('hours', 168))  # Default 7 days
        
        response = requests.get(
            f"{PAGERDUTY_API_HOST}/incidents",
            headers=get_pagerduty_headers(),
            params={
                'since': (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(),
                'statuses[]': ['resolved'],
                'limit': 100
            },
            timeout=10
        )
        
        if response.status_code != 200:
            return jsonify({'mttr_minutes': 0, 'total_incidents': 0})
        
        incidents = response.json().get('incidents', [])
        
        resolution_times = []
        for incident in incidents:
            created = datetime.fromisoformat(incident['created_at'].replace('Z', '+00:00'))
            resolved = datetime.fromisoformat(incident['last_status_change_at'].replace('Z', '+00:00'))
            resolution_time = (resolved - created).total_seconds() / 60  # minutes
            resolution_times.append(resolution_time)
        
        mttr = sum(resolution_times) / len(resolution_times) if resolution_times else 0
        
        return jsonify({
            'mttr_minutes': round(mttr, 2),
            'total_incidents': len(incidents),
            'fastest_minutes': round(min(resolution_times), 2) if resolution_times else 0,
            'slowest_minutes': round(max(resolution_times), 2) if resolution_times else 0
        })
    except Exception as e:
        return jsonify({'error': str(e), 'mttr_minutes': 0}), 500

if __name__ == '__main__':
    print("=" * 80)
    print("DevOps Command Center Dashboard")
    print("=" * 80)
    print(f"SQL Sentry: {SQL_SERVER}/{SQL_DATABASE}")
    print(f"PagerDuty: {PAGERDUTY_API_HOST}")
    print(f"Jira: {JIRA_URL}")
    print(f"Confluence: {CONFLUENCE_URL}")
    print("=" * 80)
    app.run(debug=True, host='0.0.0.0', port=5000)
