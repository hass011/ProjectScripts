#!/usr/bin/env python3
"""
Integrated Dashboard: PagerDuty + SQL Sentry
Real-time monitoring dashboard combining incident and database performance data
"""

from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import requests
import pyodbc
from datetime import datetime, timedelta, timezone
import os
from collections import defaultdict
from pathlib import Path

app = Flask(__name__)
CORS(app)

# Load environment variables from .env file
env_path = Path(__file__).parent / '.env'
if env_path.exists():
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key.strip()] = value.strip()

# Configuration
PAGERDUTY_API_KEY = os.getenv('PAGERDUTY_API_KEY', 'REPLACE_ME')
PAGERDUTY_API_HOST = "https://api.pagerduty.com"

SQL_SERVER = os.getenv('SQL_SERVER', 'elkcrpsql02')
SQL_DATABASE = os.getenv('SQL_DATABASE', 'SentryOne')
SQL_USERNAME = os.getenv('SQL_USERNAME', 'Windsirf')
SQL_PASSWORD = os.getenv('SQL_PASSWORD', 'Cday321')

def get_sql_connection():
    """Get SQL Server connection"""
    conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={SQL_SERVER};DATABASE={SQL_DATABASE};UID={SQL_USERNAME};PWD={SQL_PASSWORD}"
    return pyodbc.connect(conn_str, timeout=10)

def get_pagerduty_headers():
    """Get PagerDuty API headers"""
    return {
        "Authorization": f"Token token={PAGERDUTY_API_KEY}",
        "Accept": "application/vnd.pagerduty+json;version=2",
        "Content-Type": "application/json"
    }

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/api/pagerduty/incidents')
def get_pagerduty_incidents():
    """Fetch recent PagerDuty incidents"""
    try:
        hours = int(request.args.get('hours', 24))
        since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        
        url = f"{PAGERDUTY_API_HOST}/incidents"
        params = {
            'since': since,
            'limit': 100,
            'statuses[]': ['triggered', 'acknowledged']
        }
        
        response = requests.get(url, headers=get_pagerduty_headers(), params=params)
        response.raise_for_status()
        
        incidents = response.json().get('incidents', [])
        
        # Summarize incidents
        summary = {
            'total': len(incidents),
            'triggered': sum(1 for i in incidents if i['status'] == 'triggered'),
            'acknowledged': sum(1 for i in incidents if i['status'] == 'acknowledged'),
            'high_urgency': sum(1 for i in incidents if i['urgency'] == 'high'),
            'incidents': [{
                'id': i['id'],
                'incident_number': i['incident_number'],
                'title': i['title'],
                'status': i['status'],
                'urgency': i['urgency'],
                'created_at': i['created_at'],
                'service': i['service']['summary'] if i.get('service') else 'Unknown'
            } for i in incidents[:20]]
        }
        
        return jsonify(summary)
    except Exception as e:
        return jsonify({'error': str(e), 'incidents': [], 'total': 0}), 500

@app.route('/api/sentry/alerts')
def get_sentry_alerts():
    """Fetch recent SQL Sentry alerts"""
    try:
        hours = int(request.args.get('hours', 24))
        since = datetime.now() - timedelta(hours=hours)
        
        conn = get_sql_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                ID,
                ObjectName,
                ParentObjectName,
                Severity,
                NormalizedStartTimeUtc,
                NormalizedEndTimeUtc,
                IsResolved,
                Duration
            FROM dbo.AlertingChannelLog
            WHERE NormalizedStartTimeUtc >= ?
            ORDER BY NormalizedStartTimeUtc DESC
        """, since)
        
        rows = cursor.fetchall()
        
        alerts = []
        severity_counts = {1: 0, 2: 0, 3: 0}
        active_count = 0
        
        for row in rows:
            severity_counts[row.Severity] = severity_counts.get(row.Severity, 0) + 1
            if not row.IsResolved:
                active_count += 1
            
            alerts.append({
                'id': row.ID,
                'object': row.ObjectName,
                'server': row.ParentObjectName or 'Unknown',
                'severity': {1: 'Info', 2: 'Warning', 3: 'Critical'}.get(row.Severity, 'Unknown'),
                'severity_level': row.Severity,
                'started': row.NormalizedStartTimeUtc.isoformat() if row.NormalizedStartTimeUtc else None,
                'ended': row.NormalizedEndTimeUtc.isoformat() if row.NormalizedEndTimeUtc else None,
                'resolved': row.IsResolved,
                'duration_minutes': (row.Duration / 60000000000) if row.Duration else 0
            })
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'total': len(alerts),
            'active': active_count,
            'critical': severity_counts.get(3, 0),
            'warning': severity_counts.get(2, 0),
            'info': severity_counts.get(1, 0),
            'alerts': alerts[:50]
        })
    except Exception as e:
        return jsonify({'error': str(e), 'alerts': [], 'total': 0}), 500

@app.route('/api/sentry/blocking')
def get_sentry_blocking():
    """Fetch recent blocking sessions"""
    try:
        hours = int(request.args.get('hours', 24))
        since = datetime.now() - timedelta(hours=hours)
        
        conn = get_sql_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                bc.ID as BlockChainID,
                bc.StartTime,
                bc.EndTime,
                DATEDIFF(SECOND, bc.StartTime, ISNULL(bc.EndTime, GETDATE())) as DurationSeconds,
                bcd.SPID,
                bcd.BlockedBySpid,
                bcd.WaitText,
                bcd.WaitTime,
                bcd.DatabaseName,
                bcg.ProgramName
            FROM dbo.BlockChain bc
            INNER JOIN dbo.BlockChainDetail bcd ON bc.ID = bcd.BlockChainID
            LEFT JOIN dbo.BlockChainGroup bcg ON bc.BlockChainGroupID = bcg.ID
            WHERE bc.StartTime >= ?
            ORDER BY DurationSeconds DESC
        """, since)
        
        rows = cursor.fetchall()
        
        blocking_chains = defaultdict(list)
        for row in rows:
            blocking_chains[row.BlockChainID].append({
                'spid': row.SPID,
                'blocked_by': row.BlockedBySpid,
                'wait_type': row.WaitText or 'N/A',
                'wait_time_ms': row.WaitTime,
                'database': row.DatabaseName,
                'program': row.ProgramName
            })
        
        chains = []
        for chain_id, sessions in blocking_chains.items():
            first_session = sessions[0]
            chains.append({
                'chain_id': chain_id,
                'session_count': len(sessions),
                'sessions': sessions
            })
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'total_chains': len(chains),
            'total_sessions': sum(len(c['sessions']) for c in chains),
            'chains': chains[:20]
        })
    except Exception as e:
        return jsonify({'error': str(e), 'chains': [], 'total_chains': 0}), 500

@app.route('/api/sentry/servers')
def get_sentry_servers():
    """Get alert distribution by server"""
    try:
        hours = int(request.args.get('hours', 24))
        since = datetime.now() - timedelta(hours=hours)
        
        conn = get_sql_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                ParentObjectName as ServerName,
                COUNT(*) as AlertCount,
                SUM(CASE WHEN Severity = 3 THEN 1 ELSE 0 END) as CriticalCount,
                SUM(CASE WHEN Severity = 2 THEN 1 ELSE 0 END) as WarningCount,
                SUM(CASE WHEN IsResolved = 0 THEN 1 ELSE 0 END) as ActiveCount
            FROM dbo.AlertingChannelLog
            WHERE NormalizedStartTimeUtc >= ?
            GROUP BY ParentObjectName
            HAVING COUNT(*) > 0
            ORDER BY AlertCount DESC
        """, since)
        
        rows = cursor.fetchall()
        
        servers = [{
            'name': row.ServerName or 'Unknown',
            'total': row.AlertCount,
            'critical': row.CriticalCount,
            'warning': row.WarningCount,
            'active': row.ActiveCount
        } for row in rows]
        
        cursor.close()
        conn.close()
        
        return jsonify({'servers': servers})
    except Exception as e:
        return jsonify({'error': str(e), 'servers': []}), 500

@app.route('/api/correlation')
def get_correlation():
    """Correlate PagerDuty incidents with SQL Sentry alerts"""
    try:
        hours = int(request.args.get('hours', 24))
        
        # Get PagerDuty incidents
        pd_response = requests.get(
            f"{app.config.get('SERVER_NAME', 'http://localhost:5000')}/api/pagerduty/incidents?hours={hours}"
        )
        pd_data = pd_response.json() if pd_response.status_code == 200 else {'incidents': []}
        
        # Get SQL Sentry alerts
        sentry_response = requests.get(
            f"{app.config.get('SERVER_NAME', 'http://localhost:5000')}/api/sentry/alerts?hours={hours}"
        )
        sentry_data = sentry_response.json() if sentry_response.status_code == 200 else {'alerts': []}
        
        # Simple time-based correlation (within 5 minutes)
        correlations = []
        for incident in pd_data.get('incidents', []):
            incident_time = datetime.fromisoformat(incident['created_at'].replace('Z', '+00:00'))
            
            matching_alerts = []
            for alert in sentry_data.get('alerts', []):
                if alert.get('started'):
                    alert_time = datetime.fromisoformat(alert['started'])
                    time_diff = abs((incident_time - alert_time).total_seconds())
                    
                    if time_diff <= 300:  # Within 5 minutes
                        matching_alerts.append({
                            'alert': alert,
                            'time_diff_seconds': time_diff
                        })
            
            if matching_alerts:
                correlations.append({
                    'incident': incident,
                    'matching_alerts': matching_alerts
                })
        
        return jsonify({
            'correlations': correlations,
            'total': len(correlations)
        })
    except Exception as e:
        return jsonify({'error': str(e), 'correlations': []}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
