import requests
import json

r = requests.get('http://localhost:5001/api/feed/stats')
print(f"Status: {r.status_code}")
data = r.json()
print(json.dumps(data, indent=2))
