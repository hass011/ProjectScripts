import pyodbc

conn_str = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=elkcrpsql02;"
    "DATABASE=SentryOne;"
    "UID=Windsirf;"
    "PWD=Cday321"
)

conn = pyodbc.connect(conn_str)
cursor = conn.cursor()

print("BlockChain columns:")
cursor.execute("SELECT TOP 1 * FROM BlockChain")
for col in cursor.description:
    print(f"  - {col[0]}")

print("\nBlockChainGroup columns:")
cursor.execute("SELECT TOP 1 * FROM BlockChainGroup")
for col in cursor.description:
    print(f"  - {col[0]}")

print("\nBlockChainDetail columns:")
cursor.execute("SELECT TOP 1 * FROM BlockChainDetail")
for col in cursor.description:
    print(f"  - {col[0]}")

cursor.close()
conn.close()
