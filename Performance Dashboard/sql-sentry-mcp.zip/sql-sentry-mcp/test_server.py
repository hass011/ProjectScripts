#!/usr/bin/env python3
"""
Test script to diagnose SQL Sentry MCP server issues
"""

import os
import sys

print("=" * 80)
print("SQL Sentry MCP Server Diagnostic")
print("=" * 80)

# Check Python version
print(f"\n1. Python Version: {sys.version}")

# Check environment variables
print("\n2. Environment Variables:")
env_vars = [
    "SQL_SENTRY_SERVER",
    "SQL_SENTRY_DATABASE",
    "SQL_SENTRY_USERNAME",
    "SQL_SENTRY_PASSWORD"
]

for var in env_vars:
    value = os.getenv(var, "<NOT SET>")
    if var == "SQL_SENTRY_PASSWORD" and value != "<NOT SET>":
        value = "***HIDDEN***"
    print(f"   {var}: {value}")

# Check required packages
print("\n3. Checking Required Packages:")
packages = ["mcp", "pyodbc"]

for package in packages:
    try:
        __import__(package)
        print(f"   ✓ {package} - installed")
    except ImportError:
        print(f"   ✗ {package} - NOT INSTALLED")

# Check ODBC drivers
print("\n4. Checking ODBC Drivers:")
try:
    import pyodbc
    drivers = pyodbc.drivers()
    print(f"   Available drivers: {len(drivers)}")
    for driver in drivers:
        if "SQL Server" in driver:
            print(f"   ✓ {driver}")
except Exception as e:
    print(f"   ✗ Error: {e}")

# Test database connection (if server is configured)
print("\n5. Testing Database Connection:")
server = os.getenv("SQL_SENTRY_SERVER")
if not server or server == "YOUR_SERVER\\INSTANCE":
    print("   ⚠ SQL_SENTRY_SERVER not configured (still set to placeholder)")
    print("   → You need to set the actual SQL Sentry server name in mcp_config.json")
else:
    database = os.getenv("SQL_SENTRY_DATABASE", "SentryOne")
    username = os.getenv("SQL_SENTRY_USERNAME")
    password = os.getenv("SQL_SENTRY_PASSWORD")
    
    try:
        import pyodbc
        
        if username and password:
            conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}"
        else:
            conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes"
        
        print(f"   Attempting connection to: {server}/{database}")
        print(f"   Auth method: {'SQL Auth' if username else 'Windows Auth'}")
        
        conn = pyodbc.connect(conn_str, timeout=5)
        cursor = conn.cursor()
        cursor.execute("SELECT @@VERSION")
        version = cursor.fetchone()[0]
        print(f"   ✓ Connection successful!")
        print(f"   SQL Server: {version[:80]}...")
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"   ✗ Connection failed: {e}")

# Test MCP server import
print("\n6. Testing MCP Server Import:")
try:
    sys.path.insert(0, os.path.dirname(__file__))
    import server
    print("   ✓ server.py imports successfully")
except Exception as e:
    print(f"   ✗ Import failed: {e}")

print("\n" + "=" * 80)
print("Diagnostic Complete")
print("=" * 80)
