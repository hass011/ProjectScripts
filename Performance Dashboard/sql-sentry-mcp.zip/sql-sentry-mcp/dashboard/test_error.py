import requests

r = requests.get('http://localhost:5001/api/feed/recent?hours=0.5&limit=10')
print(f"Status: {r.status_code}")
data = r.json()
print(f"Error: {data.get('error', 'None')}")
