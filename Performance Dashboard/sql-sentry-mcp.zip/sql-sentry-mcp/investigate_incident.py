#!/usr/bin/env python3
"""
Investigate PagerDuty incident Q33WV69TRWFZKS and correlate with SQL Sentry
"""

import requests
import pyodbc
from datetime import datetime, timedelta
import json

# PagerDuty configuration
PAGERDUTY_API_KEY = "REPLACE_ME"  # Will be replaced with actual key
PAGERDUTY_API_HOST = "https://api.pagerduty.com"
INCIDENT_ID = "Q33WV69TRWFZKS"

# SQL Sentry configuration
SQL_SERVER = "elkcrpsql02"
SQL_DATABASE = "SentryOne"
SQL_USERNAME = "Windsirf"
SQL_PASSWORD = "Cday321"

print("=" * 100)
print("PAGERDUTY INCIDENT INVESTIGATION WITH SQL SENTRY CORRELATION")
print("=" * 100)

# Step 1: Fetch PagerDuty incident details
print(f"\n[1/5] Fetching PagerDuty incident {INCIDENT_ID}...")

headers = {
    "Authorization": f"Token token={PAGERDUTY_API_KEY}",
    "Accept": "application/vnd.pagerduty+json;version=2",
    "Content-Type": "application/json"
}

try:
    # Get incident details
    incident_url = f"{PAGERDUTY_API_HOST}/incidents/{INCIDENT_ID}"
    response = requests.get(incident_url, headers=headers)
    response.raise_for_status()
    
    incident = response.json()["incident"]
    
    print(f"\n{'=' * 100}")
    print("PAGERDUTY INCIDENT DETAILS")
    print("=" * 100)
    print(f"Incident ID: {incident['id']}")
    print(f"Incident Number: #{incident['incident_number']}")
    print(f"Title: {incident['title']}")
    print(f"Status: {incident['status']}")
    print(f"Urgency: {incident['urgency']}")
    print(f"Created: {incident['created_at']}")
    print(f"Service: {incident['service']['summary']}")
    
    if incident.get('first_trigger_log_entry'):
        print(f"\nFirst Trigger:")
        print(f"  Time: {incident['first_trigger_log_entry']['created_at']}")
        if incident['first_trigger_log_entry'].get('channel'):
            print(f"  Summary: {incident['first_trigger_log_entry']['channel'].get('summary', 'N/A')}")
    
    # Get incident alerts
    alerts_url = f"{PAGERDUTY_API_HOST}/incidents/{INCIDENT_ID}/alerts"
    alerts_response = requests.get(alerts_url, headers=headers)
    alerts_response.raise_for_status()
    
    alerts = alerts_response.json()["alerts"]
    
    print(f"\n{'=' * 100}")
    print(f"INCIDENT ALERTS ({len(alerts)} total)")
    print("=" * 100)
    
    query_info = None
    server_info = None
    incident_time = None
    
    for i, alert in enumerate(alerts, 1):
        print(f"\nAlert #{i}:")
        print(f"  Status: {alert['status']}")
        print(f"  Severity: {alert['severity']}")
        print(f"  Created: {alert['created_at']}")
        
        if alert.get('body'):
            body = alert['body']
            print(f"  Details: {json.dumps(body.get('details', {}), indent=4)}")
            
            # Try to extract query/server information
            details = body.get('details', {})
            if isinstance(details, dict):
                # Look for common patterns
                for key, value in details.items():
                    key_lower = key.lower()
                    if 'query' in key_lower or 'sql' in key_lower:
                        query_info = value
                        print(f"  >>> QUERY IDENTIFIED: {key} = {value[:200] if isinstance(value, str) else value}")
                    if 'server' in key_lower or 'host' in key_lower or 'database' in key_lower:
                        server_info = value
                        print(f"  >>> SERVER/DB IDENTIFIED: {key} = {value}")
        
        # Store incident time
        if not incident_time:
            incident_time = datetime.fromisoformat(alert['created_at'].replace('Z', '+00:00'))
    
    # Get incident notes
    notes_url = f"{PAGERDUTY_API_HOST}/incidents/{INCIDENT_ID}/notes"
    notes_response = requests.get(notes_url, headers=headers)
    notes_response.raise_for_status()
    
    notes = notes_response.json()["notes"]
    
    if notes:
        print(f"\n{'=' * 100}")
        print(f"INCIDENT NOTES ({len(notes)} total)")
        print("=" * 100)
        
        for i, note in enumerate(notes, 1):
            print(f"\nNote #{i}:")
            print(f"  User: {note['user']['summary']}")
            print(f"  Created: {note['created_at']}")
            print(f"  Content: {note['content']}")
    
    # Step 2: Query SQL Sentry for correlation
    if incident_time:
        print(f"\n{'=' * 100}")
        print("SQL SENTRY CORRELATION ANALYSIS")
        print("=" * 100)
        print(f"\nIncident Time Window: {incident_time} (±30 minutes)")
        
        conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={SQL_SERVER};DATABASE={SQL_DATABASE};UID={SQL_USERNAME};PWD={SQL_PASSWORD}"
        conn = pyodbc.connect(conn_str, timeout=10)
        cursor = conn.cursor()
        
        # Calculate time window
        start_time = incident_time - timedelta(minutes=30)
        end_time = incident_time + timedelta(minutes=30)
        
        # Check for SQL Sentry alerts during incident window
        print(f"\n[2/5] Checking SQL Sentry alerts during incident window...")
        
        cursor.execute("""
            SELECT 
                ID,
                ObjectName,
                ParentObjectName,
                Severity,
                NormalizedStartTimeUtc,
                NormalizedEndTimeUtc,
                IsResolved,
                Duration
            FROM dbo.AlertingChannelLog
            WHERE NormalizedStartTimeUtc BETWEEN ? AND ?
            ORDER BY NormalizedStartTimeUtc DESC
        """, start_time, end_time)
        
        sentry_alerts = cursor.fetchall()
        
        if sentry_alerts:
            print(f"\nFound {len(sentry_alerts)} SQL Sentry alert(s) during incident window:")
            for alert in sentry_alerts:
                severity_name = {1: "Info", 2: "Warning", 3: "Critical"}.get(alert.Severity, "Unknown")
                status = "ACTIVE" if not alert.IsResolved else "Resolved"
                print(f"\n  [{severity_name}] {alert.ObjectName} - {status}")
                print(f"    Server: {alert.ParentObjectName or 'N/A'}")
                print(f"    Time: {alert.NormalizedStartTimeUtc}")
                if alert.Duration:
                    print(f"    Duration: {alert.Duration / 60000000000:.1f} minutes")
        else:
            print("\nNo SQL Sentry alerts found during incident window.")
        
        # Check for blocking sessions during incident window
        print(f"\n[3/5] Checking for blocking sessions during incident window...")
        
        cursor.execute("""
            SELECT 
                bc.ID as BlockChainID,
                bc.StartTime,
                bc.EndTime,
                DATEDIFF(SECOND, bc.StartTime, ISNULL(bc.EndTime, GETDATE())) as DurationSeconds,
                bcd.SPID,
                bcd.BlockedBySpid,
                bcd.WaitText,
                bcd.WaitTime,
                bcd.WaitResourceFriendly,
                bcd.DatabaseName,
                bcg.LoginName,
                bcg.ProgramName
            FROM dbo.BlockChain bc
            INNER JOIN dbo.BlockChainDetail bcd ON bc.ID = bcd.BlockChainID
            LEFT JOIN dbo.BlockChainGroup bcg ON bc.BlockChainGroupID = bcg.ID
            WHERE bc.StartTime BETWEEN ? AND ?
            ORDER BY bc.StartTime DESC
        """, start_time, end_time)
        
        blocking = cursor.fetchall()
        
        if blocking:
            print(f"\nFound {len(blocking)} blocking session(s) during incident window:")
            current_chain = None
            for row in blocking:
                if current_chain != row.BlockChainID:
                    current_chain = row.BlockChainID
                    status = "ACTIVE" if row.EndTime is None else "Resolved"
                    print(f"\n  Blocking Chain #{row.BlockChainID} - {status}")
                    print(f"    Started: {row.StartTime}")
                    print(f"    Duration: {row.DurationSeconds} seconds ({row.DurationSeconds/60:.1f} minutes)")
                
                print(f"    - SPID {row.SPID} blocked by SPID {row.BlockedBySpid}")
                print(f"      Database: {row.DatabaseName}")
                print(f"      Wait Type: {row.WaitText or 'N/A'}")
                print(f"      Wait Time: {row.WaitTime} ms")
                if row.WaitResourceFriendly:
                    print(f"      Wait Resource: {row.WaitResourceFriendly}")
        else:
            print("\nNo blocking sessions found during incident window.")
        
        # Check for query performance issues
        print(f"\n[4/5] Analyzing query performance during incident window...")
        print("(Note: This requires PerformanceAnalysis tables which may have different schema)")
        
        cursor.close()
        conn.close()
    
    print(f"\n{'=' * 100}")
    print("ROOT CAUSE ANALYSIS")
    print("=" * 100)
    
    print("\nBased on available data:")
    print("1. PagerDuty incident details retrieved")
    print("2. SQL Sentry correlation performed")
    print("3. Review findings above to determine root cause")
    
    if query_info:
        print(f"\nQuery Information: {query_info}")
    if server_info:
        print(f"Server Information: {server_info}")
    
    print("\n" + "=" * 100)
    print("INVESTIGATION COMPLETE")
    print("=" * 100)

except requests.exceptions.HTTPError as e:
    print(f"\nPagerDuty API Error: {e}")
    print(f"Response: {e.response.text if e.response else 'N/A'}")
except Exception as e:
    print(f"\nError: {e}")
    import traceback
    traceback.print_exc()
