# Quick Start Guide

Get your PagerDuty + SQL Sentry dashboard running in 3 steps!

## Step 1: Configure Credentials

1. Copy the environment template:
   ```powershell
   cd C:\Users\hassan.hassan\CascadeProjects\sql-sentry-mcp\dashboard
   copy .env.example .env
   ```

2. Edit `.env` and add your credentials:
   - **PAGERDUTY_API_KEY**: Get from https://payroc.pagerduty.com → User Settings → API Access
   - **SQL_PASSWORD**: Your SQL Sentry database password

## Step 2: Install Dependencies

```powershell
pip install -r requirements.txt
```

## Step 3: Start the Dashboard

### Option A: Use the startup script (Recommended)
```powershell
.\start_dashboard.ps1
```

### Option B: Start manually
```powershell
python app.py
```

## Access the Dashboard

Open your browser and go to:
```
http://localhost:5000
```

## What You'll See

- **PagerDuty Incidents**: Real-time incident tracking
- **SQL Sentry Alerts**: Database performance alerts
- **Blocking Sessions**: Active and historical blocking
- **Correlations**: Automatic matching of incidents with database issues
- **Server Health**: Alert distribution across your SQL Servers

## Features

✅ Real-time data refresh  
✅ Auto-refresh every 30 seconds (toggle on/off)  
✅ Time range filtering (1h to 7 days)  
✅ Interactive charts and tables  
✅ Incident-alert correlation  
✅ Dark theme UI  

## Troubleshooting

**No PagerDuty data?**
- Check your API key in `.env`
- Verify you have incidents in the selected time range

**No SQL Sentry data?**
- Verify SQL Server credentials in `.env`
- Test connection: `sqlcmd -S elkcrpsql02 -U Windsirf -P <password>`

**Port 5000 already in use?**
- Edit `app.py` and change the port number in the last line

## Next Steps

- Set up auto-refresh for continuous monitoring
- Adjust time ranges to match your needs
- Review correlations to identify root causes faster
- Share the dashboard URL with your team

For detailed documentation, see [README.md](README.md)
