import requests
import json

# Test 5 minutes
r = requests.get('http://localhost:5001/api/feed/recent?hours=0.083&limit=10')
print(f"5 minutes - Status: {r.status_code}")
data = r.json()
print(f"Total items: {data.get('total', 0)}")
if data.get('items'):
    print(f"First item: {data['items'][0].get('type')} - {data['items'][0].get('time')}")

# Test 30 minutes
r = requests.get('http://localhost:5001/api/feed/recent?hours=0.5&limit=10')
print(f"\n30 minutes - Status: {r.status_code}")
data = r.json()
print(f"Total items: {data.get('total', 0)}")
