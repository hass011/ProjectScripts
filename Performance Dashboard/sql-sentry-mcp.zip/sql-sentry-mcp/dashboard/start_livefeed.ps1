# Start SQL Sentry Live Feed Dashboard
# Real-time monitoring of SQL Server alerts and blocking

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "SQL Sentry Live Feed Dashboard" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Stop any existing Flask servers on port 5001
Write-Host "Stopping existing servers on port 5001..." -ForegroundColor Yellow
Get-Process python -ErrorAction SilentlyContinue | Where-Object {
    $_.MainWindowTitle -match "flask" -or $_.CommandLine -match "app_livefeed"
} | Stop-Process -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 2

# Check if .env file exists
if (-not (Test-Path ".env")) {
    Write-Host "WARNING: .env file not found!" -ForegroundColor Yellow
    Write-Host "Creating .env from template..." -ForegroundColor Yellow
    Copy-Item ".env.example" ".env"
    Write-Host ""
    Write-Host "Please edit .env file and configure SQL Sentry credentials" -ForegroundColor Red
    Write-Host ""
}

# Load environment variables
Write-Host "Loading environment variables..." -ForegroundColor Green
Get-Content .env | ForEach-Object {
    if ($_ -match '^([^=]+)=(.*)$') {
        $name = $matches[1].Trim()
        $value = $matches[2].Trim()
        [Environment]::SetEnvironmentVariable($name, $value, "Process")
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Starting Live Feed..." -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Dashboard will be available at:" -ForegroundColor Green
Write-Host "  http://localhost:5001" -ForegroundColor Cyan
Write-Host ""
Write-Host "Features:" -ForegroundColor Yellow
Write-Host "  ⚡ Real-time alert streaming" -ForegroundColor White
Write-Host "  🔒 Live blocking session monitoring" -ForegroundColor White
Write-Host "  📊 Auto-updating statistics" -ForegroundColor White
Write-Host "  🎯 Severity filtering (Critical/Warning/Info)" -ForegroundColor White
Write-Host "  📈 Top servers and objects" -ForegroundColor White
Write-Host "  🔄 Auto-scroll feed" -ForegroundColor White
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

# Start Flask app
python app_livefeed.py
