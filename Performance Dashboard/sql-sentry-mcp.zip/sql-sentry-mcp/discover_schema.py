#!/usr/bin/env python3
"""
Discover SQL Sentry database schema
"""

import pyodbc
import os

server = "elkcrpsql01"
database = "SentryOne"
username = "Windsurf"
password = "Cday321"

conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}"

try:
    conn = pyodbc.connect(conn_str, timeout=10)
    cursor = conn.cursor()
    
    print("=" * 80)
    print("SQL Sentry Database Schema Discovery")
    print("=" * 80)
    
    # Get all tables
    print("\n1. All Tables in SentryOne Database:")
    cursor.execute("""
        SELECT TABLE_SCHEMA, TABLE_NAME, 
               (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS c 
                WHERE c.TABLE_SCHEMA = t.TABLE_SCHEMA 
                AND c.TABLE_NAME = t.TABLE_NAME) as ColumnCount
        FROM INFORMATION_SCHEMA.TABLES t
        WHERE TABLE_TYPE = 'BASE TABLE'
        ORDER BY TABLE_NAME
    """)
    
    tables = cursor.fetchall()
    for row in tables:
        print(f"   {row.TABLE_SCHEMA}.{row.TABLE_NAME} ({row.ColumnCount} columns)")
    
    # Look for alert-related tables
    print("\n2. Alert-Related Tables:")
    alert_tables = [t for t in tables if 'alert' in t.TABLE_NAME.lower() or 'event' in t.TABLE_NAME.lower()]
    for row in alert_tables:
        print(f"\n   Table: {row.TABLE_SCHEMA}.{row.TABLE_NAME}")
        cursor.execute(f"""
            SELECT TOP 5 COLUMN_NAME, DATA_TYPE, IS_NULLABLE
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
            ORDER BY ORDINAL_POSITION
        """, row.TABLE_SCHEMA, row.TABLE_NAME)
        cols = cursor.fetchall()
        for col in cols:
            print(f"      - {col.COLUMN_NAME} ({col.DATA_TYPE}, {'NULL' if col.IS_NULLABLE == 'YES' else 'NOT NULL'})")
    
    # Look for performance/query tables
    print("\n3. Performance/Query-Related Tables:")
    perf_tables = [t for t in tables if any(x in t.TABLE_NAME.lower() for x in ['query', 'performance', 'metric', 'stat'])]
    for row in perf_tables[:10]:
        print(f"   {row.TABLE_SCHEMA}.{row.TABLE_NAME}")
    
    # Look for blocking/deadlock tables
    print("\n4. Blocking/Deadlock-Related Tables:")
    block_tables = [t for t in tables if any(x in t.TABLE_NAME.lower() for x in ['block', 'deadlock', 'lock', 'wait'])]
    for row in block_tables:
        print(f"   {row.TABLE_SCHEMA}.{row.TABLE_NAME}")
    
    cursor.close()
    conn.close()
    
    print("\n" + "=" * 80)
    print("Schema Discovery Complete")
    print("=" * 80)
    
except Exception as e:
    print(f"Error: {e}")
