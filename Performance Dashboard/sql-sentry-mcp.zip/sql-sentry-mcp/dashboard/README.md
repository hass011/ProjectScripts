# PagerDuty + SQL Sentry Integrated Dashboard

Real-time monitoring dashboard that combines PagerDuty incident data with SQL Sentry database performance metrics.

## Features

### 📊 Real-Time Monitoring
- **PagerDuty Incidents**: Track triggered and acknowledged incidents
- **SQL Sentry Alerts**: Monitor database alerts by severity
- **Blocking Sessions**: View active and historical blocking chains
- **Server Health**: Alert distribution across SQL Server instances

### 🔗 Intelligent Correlation
- Automatically correlates PagerDuty incidents with SQL Sentry alerts
- Time-based matching (within 5-minute window)
- Helps identify root causes faster

### 📈 Visualizations
- Interactive charts using Chart.js
- Doughnut charts for incident/alert distribution
- Bar charts for server alert patterns
- Real-time data tables with filtering

### ⚡ Auto-Refresh
- Manual refresh on demand
- Optional auto-refresh every 30 seconds
- Configurable time ranges (1h, 6h, 24h, 48h, 7d)

## Prerequisites

- Python 3.8+
- SQL Server ODBC Driver 17
- PagerDuty API token
- SQL Sentry database access

## Installation

1. **Navigate to dashboard directory:**
   ```powershell
   cd C:\Users\hassan.hassan\CascadeProjects\sql-sentry-mcp\dashboard
   ```

2. **Install Python dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

3. **Configure environment variables:**
   
   Create a `.env` file (copy from `.env.example`):
   ```powershell
   copy .env.example .env
   ```
   
   Edit `.env` and add your credentials:
   ```
   PAGERDUTY_API_KEY=your_actual_api_key
   SQL_SERVER=elkcrpsql02
   SQL_DATABASE=SentryOne
   SQL_USERNAME=Windsirf
   SQL_PASSWORD=your_actual_password
   ```

## Getting PagerDuty API Key

1. Log in to PagerDuty: https://payroc.pagerduty.com
2. Go to **User Icon** → **My Profile** → **User Settings**
3. Click **Create API User Token**
4. Copy the token and add to `.env` file

## Usage

### Start the Dashboard

```powershell
python app.py
```

The dashboard will be available at: **http://localhost:5000**

### Access the Dashboard

Open your web browser and navigate to:
```
http://localhost:5000
```

### Dashboard Controls

- **Time Range Selector**: Choose from 1h, 6h, 24h, 48h, or 7 days
- **Refresh Button**: Manually refresh all data
- **Auto-Refresh Toggle**: Enable/disable automatic refresh every 30 seconds

## Dashboard Sections

### 1. Summary Statistics (Top Cards)
- **PagerDuty Incidents**: Total incidents with triggered/acknowledged breakdown
- **SQL Sentry Alerts**: Total alerts with active/critical counts
- **Blocking Sessions**: Number of blocking chains and total sessions
- **Correlations**: Incidents matched with SQL Sentry alerts

### 2. PagerDuty Incidents Panel
- Pie chart showing incident distribution
- Table with recent incidents (number, title, service, status, urgency)

### 3. SQL Sentry Alerts Panel
- Pie chart showing alert severity distribution
- Table with recent alerts (object, server, severity, status, duration)

### 4. Alert Distribution by Server
- Bar chart showing alert counts per server
- Breakdown by critical, warning, and active alerts

### 5. Incident-Alert Correlations
- Shows PagerDuty incidents matched with SQL Sentry alerts
- Displays time difference between incident and alert
- Helps identify database issues causing application incidents

### 6. Recent Blocking Sessions
- Table of blocking chains from SQL Sentry
- Shows chain ID, session count, database, wait type, and wait time

## API Endpoints

The dashboard exposes the following REST API endpoints:

### PagerDuty
- `GET /api/pagerduty/incidents?hours=24` - Get recent incidents

### SQL Sentry
- `GET /api/sentry/alerts?hours=24` - Get recent alerts
- `GET /api/sentry/blocking?hours=24` - Get blocking sessions
- `GET /api/sentry/servers?hours=24` - Get alert distribution by server

### Correlation
- `GET /api/correlation?hours=24` - Get correlated incidents and alerts

## Troubleshooting

### No PagerDuty Data
- Verify your API token is correct in `.env`
- Check that you have access to incidents in PagerDuty
- Ensure the API token has read permissions

### No SQL Sentry Data
- Verify SQL Server connection details in `.env`
- Test SQL Server connectivity: `sqlcmd -S elkcrpsql02 -U Windsirf -P <password>`
- Ensure ODBC Driver 17 is installed

### Dashboard Not Loading
- Check that Flask is running on port 5000
- Verify no firewall is blocking port 5000
- Check browser console for JavaScript errors

### CORS Errors
- The dashboard uses `flask-cors` to allow cross-origin requests
- If issues persist, check browser security settings

## Architecture

```
dashboard/
├── app.py                 # Flask backend API
├── templates/
│   └── dashboard.html     # Frontend dashboard
├── requirements.txt       # Python dependencies
├── .env.example          # Environment variables template
└── README.md             # This file
```

### Backend (Flask)
- RESTful API endpoints for data fetching
- PagerDuty API integration
- SQL Sentry database queries
- Correlation logic

### Frontend (HTML/CSS/JS)
- Responsive design with dark theme
- Chart.js for visualizations
- Vanilla JavaScript (no framework dependencies)
- Auto-refresh capability

## Customization

### Change Refresh Interval
Edit `dashboard.html`, line with `setInterval`:
```javascript
autoRefreshInterval = setInterval(refreshData, 30000); // Change 30000 to desired ms
```

### Modify Correlation Window
Edit `app.py`, correlation endpoint:
```python
if time_diff <= 300:  # Change 300 to desired seconds
```

### Add Custom Metrics
1. Add new API endpoint in `app.py`
2. Add fetch function in `dashboard.html`
3. Add visualization or table section

## Security Notes

- **Never commit `.env` file** to version control
- Store API keys and passwords securely
- Use environment variables for sensitive data
- Consider using HTTPS in production
- Implement authentication for production deployments

## Production Deployment

For production use:

1. **Use a production WSGI server** (e.g., Gunicorn):
   ```powershell
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5000 app:app
   ```

2. **Set up reverse proxy** (e.g., Nginx)

3. **Enable HTTPS** with SSL certificates

4. **Add authentication** (e.g., Flask-Login, OAuth)

5. **Configure logging** for monitoring

## Support

For issues or questions:
- Check SQL Sentry MCP documentation
- Review PagerDuty API documentation
- Check Flask and Chart.js documentation

## License

Internal use only - Payroc
