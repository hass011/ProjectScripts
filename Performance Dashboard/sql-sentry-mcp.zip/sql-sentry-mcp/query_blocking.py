#!/usr/bin/env python3
"""Query blocking sessions from SQL Sentry"""

import pyodbc
from datetime import datetime

server = "elkcrpsql02"
database = "SentryOne"
username = "Windsirf"
password = "Cday321"

conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}"

try:
    conn = pyodbc.connect(conn_str, timeout=10)
    cursor = conn.cursor()
    
    # Query recent blocking (last 24 hours)
    query = """
        SELECT 
            bc.ID as BlockChainID,
            bc.StartTime,
            bc.EndTime,
            DATEDIFF(SECOND, bc.StartTime, ISNULL(bc.EndTime, GETDATE())) as DurationSeconds,
            bcd.SPID,
            bcd.BlockedBySpid,
            bcd.WaitText,
            bcd.WaitTime,
            bcd.WaitResource,
            bcd.WaitResourceFriendly,
            bcd.DatabaseName,
            bcg.HostName,
            bcg.ProgramName,
            bcg.LoginName
        FROM dbo.BlockChain bc
        INNER JOIN dbo.BlockChainDetail bcd ON bc.ID = bcd.BlockChainID
        LEFT JOIN dbo.BlockChainGroup bcg ON bc.BlockChainGroupID = bcg.ID
        WHERE bc.StartTime >= DATEADD(HOUR, -24, GETDATE())
        ORDER BY bc.StartTime DESC
    """
    
    cursor.execute(query)
    rows = cursor.fetchall()
    
    print("=" * 80)
    print(f"SQL Sentry Blocking Sessions (Last 24 Hours)")
    print("=" * 80)
    
    if not rows:
        print("\nNo blocking sessions found in the last 24 hours.")
    else:
        print(f"\nTotal blocking chains found: {len(rows)}\n")
        
        current_chain = None
        for row in rows:
            if current_chain != row.BlockChainID:
                if current_chain is not None:
                    print("-" * 80)
                current_chain = row.BlockChainID
                
                status = "ACTIVE" if row.EndTime is None else "Resolved"
                print(f"\n**Blocking Chain #{row.BlockChainID}** - {status}")
                print(f"Started: {row.StartTime}")
                if row.EndTime:
                    print(f"Ended: {row.EndTime}")
                print(f"Duration: {row.DurationSeconds} seconds ({row.DurationSeconds/60:.1f} minutes)")
                print()
            
            print(f"  SPID {row.SPID} blocked by SPID {row.BlockedBySpid}")
            print(f"  Database: {row.DatabaseName}")
            print(f"  Wait Type: {row.WaitText or 'N/A'}")
            print(f"  Wait Time: {row.WaitTime} ms")
            if row.WaitResourceFriendly:
                print(f"  Wait Resource: {row.WaitResourceFriendly}")
            if row.LoginName:
                print(f"  Login: {row.LoginName}")
            if row.HostName:
                print(f"  Host: {row.HostName}")
            if row.ProgramName:
                print(f"  Program: {row.ProgramName}")
            print()
    
    # Get summary statistics
    cursor.execute("""
        SELECT 
            COUNT(DISTINCT bc.ID) as TotalChains,
            COUNT(DISTINCT bcd.SPID) as TotalBlockedSessions,
            AVG(DATEDIFF(SECOND, bc.StartTime, ISNULL(bc.EndTime, GETDATE()))) as AvgDurationSeconds,
            MAX(DATEDIFF(SECOND, bc.StartTime, ISNULL(bc.EndTime, GETDATE()))) as MaxDurationSeconds
        FROM dbo.BlockChain bc
        INNER JOIN dbo.BlockChainDetail bcd ON bc.ID = bcd.BlockChainID
        WHERE bc.StartTime >= DATEADD(HOUR, -24, GETDATE())
    """)
    
    stats = cursor.fetchone()
    if stats and stats.TotalChains > 0:
        print("=" * 80)
        print("Summary Statistics (Last 24 Hours):")
        print("=" * 80)
        print(f"Total Blocking Chains: {stats.TotalChains}")
        print(f"Total Blocked Sessions: {stats.TotalBlockedSessions}")
        print(f"Average Duration: {stats.AvgDurationSeconds:.1f} seconds ({stats.AvgDurationSeconds/60:.1f} minutes)")
        print(f"Maximum Duration: {stats.MaxDurationSeconds} seconds ({stats.MaxDurationSeconds/60:.1f} minutes)")
    
    cursor.close()
    conn.close()
    
    print("\n" + "=" * 80)
    
except Exception as e:
    print(f"Error: {e}")
