#!/usr/bin/env python3
"""
Analyze recent query timeouts and performance issues from SQL Sentry
This script searches for timeout-related issues in the last 24-48 hours
"""

import pyodbc
from datetime import datetime, timedelta

SQL_SERVER = "elkcrpsql02"
SQL_DATABASE = "SentryOne"
SQL_USERNAME = "Windsirf"
SQL_PASSWORD = "Cday321"

print("=" * 100)
print("SQL SENTRY TIMEOUT & PERFORMANCE ANALYSIS")
print("=" * 100)
print(f"\nAnalyzing last 48 hours for query timeout issues...")
print(f"Current time: {datetime.now()}")

conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={SQL_SERVER};DATABASE={SQL_DATABASE};UID={SQL_USERNAME};PWD={SQL_PASSWORD}"

try:
    conn = pyodbc.connect(conn_str, timeout=10)
    cursor = conn.cursor()
    
    # Calculate time windows
    now = datetime.now()
    last_48h = now - timedelta(hours=48)
    last_24h = now - timedelta(hours=24)
    
    # 1. Check for timeout-related alerts
    print(f"\n{'=' * 100}")
    print("[1/5] TIMEOUT-RELATED ALERTS (Last 48 Hours)")
    print("=" * 100)
    
    cursor.execute("""
        SELECT 
            ID,
            ObjectName,
            ParentObjectName,
            Severity,
            NormalizedStartTimeUtc,
            NormalizedEndTimeUtc,
            IsResolved,
            Duration,
            OpenedByResults
        FROM dbo.AlertingChannelLog
        WHERE NormalizedStartTimeUtc >= ?
          AND (
              LOWER(ObjectName) LIKE '%timeout%' OR
              LOWER(ObjectName) LIKE '%slow%' OR
              LOWER(ObjectName) LIKE '%performance%' OR
              LOWER(ObjectName) LIKE '%query%' OR
              LOWER(ObjectName) LIKE '%duration%'
          )
        ORDER BY NormalizedStartTimeUtc DESC
    """, last_48h)
    
    timeout_alerts = cursor.fetchall()
    
    if timeout_alerts:
        print(f"\nFound {len(timeout_alerts)} timeout/performance-related alert(s):\n")
        for alert in timeout_alerts:
            severity_name = {1: "Info", 2: "Warning", 3: "Critical"}.get(alert.Severity, "Unknown")
            status = "ACTIVE" if not alert.IsResolved else "Resolved"
            duration_min = alert.Duration / 60000000000 if alert.Duration else 0
            
            print(f"[{severity_name}] {alert.ObjectName} - {status}")
            print(f"  Server: {alert.ParentObjectName or 'N/A'}")
            print(f"  Started: {alert.NormalizedStartTimeUtc}")
            if alert.IsResolved and alert.NormalizedEndTimeUtc:
                print(f"  Ended: {alert.NormalizedEndTimeUtc}")
            if duration_min > 0:
                print(f"  Duration: {duration_min:.1f} minutes")
            if alert.OpenedByResults:
                print(f"  Details: {str(alert.OpenedByResults)[:200]}...")
            print()
    else:
        print("\nNo timeout-related alerts found.")
    
    # 2. Check for all critical alerts in last 48h
    print(f"\n{'=' * 100}")
    print("[2/5] ALL CRITICAL ALERTS (Last 48 Hours)")
    print("=" * 100)
    
    cursor.execute("""
        SELECT TOP 20
            ID,
            ObjectName,
            ParentObjectName,
            Severity,
            NormalizedStartTimeUtc,
            NormalizedEndTimeUtc,
            IsResolved,
            Duration
        FROM dbo.AlertingChannelLog
        WHERE NormalizedStartTimeUtc >= ?
          AND Severity = 3
        ORDER BY NormalizedStartTimeUtc DESC
    """, last_48h)
    
    critical_alerts = cursor.fetchall()
    
    if critical_alerts:
        print(f"\nFound {len(critical_alerts)} critical alert(s):\n")
        for alert in critical_alerts:
            status = "ACTIVE" if not alert.IsResolved else "Resolved"
            duration_min = alert.Duration / 60000000000 if alert.Duration else 0
            
            print(f"[Critical] {alert.ObjectName} - {status}")
            print(f"  Server: {alert.ParentObjectName or 'N/A'}")
            print(f"  Started: {alert.NormalizedStartTimeUtc}")
            if duration_min > 0:
                print(f"  Duration: {duration_min:.1f} minutes")
            print()
    else:
        print("\nNo critical alerts found.")
    
    # 3. Check for long-running blocking sessions
    print(f"\n{'=' * 100}")
    print("[3/5] LONG-RUNNING BLOCKING SESSIONS (Last 48 Hours, >30 seconds)")
    print("=" * 100)
    
    cursor.execute("""
        SELECT 
            bc.ID as BlockChainID,
            bc.StartTime,
            bc.EndTime,
            DATEDIFF(SECOND, bc.StartTime, ISNULL(bc.EndTime, GETDATE())) as DurationSeconds,
            bcd.SPID,
            bcd.BlockedBySpid,
            bcd.WaitText,
            bcd.WaitTime,
            bcd.WaitResourceFriendly,
            bcd.DatabaseName,
            bcg.LoginName,
            bcg.ProgramName,
            bcg.HostName
        FROM dbo.BlockChain bc
        INNER JOIN dbo.BlockChainDetail bcd ON bc.ID = bcd.BlockChainID
        LEFT JOIN dbo.BlockChainGroup bcg ON bc.BlockChainGroupID = bcg.ID
        WHERE bc.StartTime >= ?
          AND DATEDIFF(SECOND, bc.StartTime, ISNULL(bc.EndTime, GETDATE())) > 30
        ORDER BY DurationSeconds DESC
    """, last_48h)
    
    long_blocking = cursor.fetchall()
    
    if long_blocking:
        print(f"\nFound {len(long_blocking)} long-running blocking session(s):\n")
        current_chain = None
        for row in long_blocking:
            if current_chain != row.BlockChainID:
                current_chain = row.BlockChainID
                status = "ACTIVE" if row.EndTime is None else "Resolved"
                print(f"Blocking Chain #{row.BlockChainID} - {status}")
                print(f"  Started: {row.StartTime}")
                print(f"  Duration: {row.DurationSeconds} seconds ({row.DurationSeconds/60:.1f} minutes)")
            
            print(f"  - SPID {row.SPID} blocked by SPID {row.BlockedBySpid}")
            print(f"    Database: {row.DatabaseName}")
            print(f"    Wait Type: {row.WaitText or 'N/A'}")
            print(f"    Wait Time: {row.WaitTime} ms")
            if row.WaitResourceFriendly:
                print(f"    Wait Resource: {row.WaitResourceFriendly}")
            if row.LoginName:
                print(f"    Login: {row.LoginName}")
            if row.ProgramName:
                print(f"    Program: {row.ProgramName}")
            print()
    else:
        print("\nNo long-running blocking sessions found.")
    
    # 4. Search for database/table patterns in alerts
    print(f"\n{'=' * 100}")
    print("[4/5] ALERT PATTERNS BY DATABASE/OBJECT (Last 48 Hours)")
    print("=" * 100)
    
    cursor.execute("""
        SELECT 
            ParentObjectName as ServerName,
            COUNT(*) as AlertCount,
            SUM(CASE WHEN Severity = 3 THEN 1 ELSE 0 END) as CriticalCount,
            SUM(CASE WHEN Severity = 2 THEN 1 ELSE 0 END) as WarningCount,
            SUM(CASE WHEN IsResolved = 0 THEN 1 ELSE 0 END) as ActiveCount
        FROM dbo.AlertingChannelLog
        WHERE NormalizedStartTimeUtc >= ?
        GROUP BY ParentObjectName
        HAVING COUNT(*) > 0
        ORDER BY AlertCount DESC
    """, last_48h)
    
    patterns = cursor.fetchall()
    
    if patterns:
        print(f"\nAlert distribution by server:\n")
        for row in patterns:
            print(f"{row.ServerName or 'Unknown'}:")
            print(f"  Total: {row.AlertCount} | Critical: {row.CriticalCount} | Warning: {row.WarningCount} | Active: {row.ActiveCount}")
    else:
        print("\nNo alert patterns found.")
    
    # 5. Recent alerts timeline (last 24 hours)
    print(f"\n{'=' * 100}")
    print("[5/5] RECENT ALERTS TIMELINE (Last 24 Hours)")
    print("=" * 100)
    
    cursor.execute("""
        SELECT TOP 30
            ID,
            ObjectName,
            ParentObjectName,
            Severity,
            NormalizedStartTimeUtc,
            IsResolved
        FROM dbo.AlertingChannelLog
        WHERE NormalizedStartTimeUtc >= ?
        ORDER BY NormalizedStartTimeUtc DESC
    """, last_24h)
    
    recent = cursor.fetchall()
    
    if recent:
        print(f"\nLast 30 alerts (most recent first):\n")
        for alert in recent:
            severity_name = {1: "Info", 2: "Warning", 3: "Critical"}.get(alert.Severity, "Unknown")
            status = "✓" if alert.IsResolved else "⚠"
            print(f"{alert.NormalizedStartTimeUtc} | [{severity_name:8}] {status} | {alert.ParentObjectName or 'N/A':20} | {alert.ObjectName}")
    else:
        print("\nNo recent alerts found.")
    
    cursor.close()
    conn.close()
    
    print(f"\n{'=' * 100}")
    print("ANALYSIS COMPLETE")
    print("=" * 100)
    print("\nNEXT STEPS:")
    print("1. Review the alerts and blocking sessions above")
    print("2. Correlate timestamps with PagerDuty incident Q33WV69TRWFZKS")
    print("3. Identify which server/database/query caused the timeout")
    print("4. Investigate root cause (blocking, resource contention, missing indexes)")
    print("\n" + "=" * 100)

except Exception as e:
    print(f"\nError: {e}")
    import traceback
    traceback.print_exc()
