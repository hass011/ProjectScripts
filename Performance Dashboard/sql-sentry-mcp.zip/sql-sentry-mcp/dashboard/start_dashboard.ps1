# Start PagerDuty + SQL Sentry Dashboard
# Quick startup script for the integrated monitoring dashboard

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "PagerDuty + SQL Sentry Dashboard" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if .env file exists
if (-not (Test-Path ".env")) {
    Write-Host "WARNING: .env file not found!" -ForegroundColor Yellow
    Write-Host "Creating .env from template..." -ForegroundColor Yellow
    Copy-Item ".env.example" ".env"
    Write-Host ""
    Write-Host "Please edit .env file and add your credentials:" -ForegroundColor Red
    Write-Host "  - PAGERDUTY_API_KEY" -ForegroundColor Red
    Write-Host "  - SQL_PASSWORD" -ForegroundColor Red
    Write-Host ""
    Write-Host "Press any key to open .env file for editing..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    notepad .env
    Write-Host ""
    Write-Host "After saving .env, press any key to continue..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

# Load environment variables from .env
Write-Host "Loading environment variables..." -ForegroundColor Green
Get-Content .env | ForEach-Object {
    if ($_ -match '^([^=]+)=(.*)$') {
        $name = $matches[1].Trim()
        $value = $matches[2].Trim()
        [Environment]::SetEnvironmentVariable($name, $value, "Process")
    }
}

# Check if dependencies are installed
Write-Host "Checking Python dependencies..." -ForegroundColor Green
$pipList = pip list 2>&1
$missingPackages = @()

if ($pipList -notmatch "Flask") { $missingPackages += "Flask" }
if ($pipList -notmatch "flask-cors") { $missingPackages += "flask-cors" }
if ($pipList -notmatch "requests") { $missingPackages += "requests" }
if ($pipList -notmatch "pyodbc") { $missingPackages += "pyodbc" }

if ($missingPackages.Count -gt 0) {
    Write-Host "Installing missing dependencies..." -ForegroundColor Yellow
    pip install -r requirements.txt
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Starting Dashboard Server..." -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Dashboard will be available at:" -ForegroundColor Green
Write-Host "  http://localhost:5000" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

# Start Flask app
python app.py
