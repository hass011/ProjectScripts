#!/usr/bin/env python3
"""
SQL Sentry Live Feed Dashboard
Real-time monitoring of SQL Server alerts, blocking, and performance
"""

from flask import Flask, render_template, jsonify, request, Response
from flask_cors import CORS
import pyodbc
from datetime import datetime, timedelta, timezone
import os
from pathlib import Path
import json
import time
import random
import requests
import traceback
import gzip as _gzip
import re as _re
import xml.etree.ElementTree as _ET
from concurrent.futures import ThreadPoolExecutor, as_completed

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True
CORS(app)

# Load environment variables from .env file
env_path = Path(__file__).parent / '.env'
if env_path.exists():
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key.strip()] = value.strip()

# Configuration
SQL_SERVER = os.getenv('SQL_SERVER', 'elkcrpsql02')
SQL_DATABASE = os.getenv('SQL_DATABASE', 'SentryOne')
SQL_USERNAME = os.getenv('SQL_USERNAME', 'Windsirf')
SQL_PASSWORD = os.getenv('SQL_PASSWORD', 'Cday321')

# PagerDuty Configuration
PD_API_KEY = os.getenv('PAGERDUTY_USER_API_KEY', 'REPLACE_ME')
PD_API_HOST = os.getenv('PAGERDUTY_API_HOST', 'https://api.pagerduty.com')

# PRTG Configuration
PRTG_SERVER   = os.getenv('PRTG_SERVER', 'https://prtg.corp.payroc.com')
PRTG_USERNAME = os.getenv('PRTG_USERNAME', 'svc-prtg-api-dbas')
PRTG_PASSHASH = os.getenv('PRTG_PASSHASH', '2547364615')

# Rubrik Configuration
RUBRIK_SERVERS       = os.getenv('RUBRIK_SERVERS', '10.40.12.155,10.44.12.155').split(',')
RUBRIK_CLIENT_ID     = os.getenv('RUBRIK_CLIENT_ID', 'client|019b273e-0554-7d73-922c-ce924876bbf8')
RUBRIK_CLIENT_SECRET = os.getenv('RUBRIK_CLIENT_SECRET', 'kfQhDQT3FBZ6ZbwzYvy3wAP7tz_7Hoi1MhLjC3aLvmyYY5Ylrzt1_p5ymVkCQ8cy')
_rubrik_token_cache  = {}   # keyed by server IP
import threading as _threading
_rubrik_token_lock   = _threading.Lock()
_rubrik_backups_cache = {'data': None, 'ts': 0}  # cached hosts response, 5-min TTL
_RUBRIK_CACHE_TTL = 300  # seconds

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

print("=" * 80)
print("SQL Sentry Live Feed Dashboard")
print("=" * 80)
print(f"SQL Sentry: {SQL_SERVER}/{SQL_DATABASE}")
print(f"PagerDuty: {'Configured' if PD_API_KEY != 'REPLACE_ME' else 'MOCK MODE (set PAGERDUTY_USER_API_KEY)'}")
print("=" * 80)

def get_db_connection():
    """Create database connection"""
    conn_str = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={SQL_SERVER};"
        f"DATABASE={SQL_DATABASE};"
        f"UID={SQL_USERNAME};"
        f"PWD={SQL_PASSWORD}"
    )
    return pyodbc.connect(conn_str)

def _no_cache(html):
    resp = app.make_response(html)
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'
    resp.headers['Expires'] = '0'
    return resp

@app.route('/')
def index():
    """Main dashboard page"""
    return _no_cache(render_template('livefeed.html'))

@app.route('/blocking')
def blocking_feed():
    """Blocking sessions live feed page"""
    return _no_cache(render_template('blocking_feed.html'))

@app.route('/api/feed/stream')
def stream_feed():
    """Server-Sent Events stream for real-time updates"""
    def generate():
        last_alert_id = 0
        while True:
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                
                # Get new alerts since last check
                cursor.execute("""
                    SELECT TOP 10
                        ID,
                        ObjectName,
                        ParentObjectName,
                        ConditionTypeName,
                        ObjectTypeName,
                        ActionTypeName,
                        Message,
                        Duration,
                        EventStartTime,
                        EventEndTime,
                        CASE WHEN EventEndTime IS NULL THEN 0 ELSE 1 END as Resolved
                    FROM dbo.vwObjectConditionActionHistory
                    WHERE ID > ?
                      AND ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')
                    ORDER BY EventStartTime DESC
                """, last_alert_id)
                
                alerts = []
                for row in cursor.fetchall():
                    if row.ID > last_alert_id:
                        last_alert_id = row.ID

                    cond = (row.ConditionTypeName or '') if not isinstance(row.ConditionTypeName, bytes) else row.ConditionTypeName.decode('utf-8', errors='replace')
                    if 'error' in cond.lower() or 'fail' in cond.lower() or 'critical' in cond.lower():
                        severity = 'Critical'
                    elif 'warning' in cond.lower() or 'high' in cond.lower():
                        severity = 'Warning'
                    else:
                        severity = 'Info'

                    obj = row.ObjectName
                    if isinstance(obj, bytes): obj = obj.decode('utf-8', errors='replace')
                    srv = row.ParentObjectName
                    if isinstance(srv, bytes): srv = srv.decode('utf-8', errors='replace')
                    msg = row.Message
                    if isinstance(msg, bytes): msg = msg.decode('utf-8', errors='replace')
                    otype = row.ObjectTypeName
                    if isinstance(otype, bytes): otype = otype.decode('utf-8', errors='replace')
                    atype = row.ActionTypeName
                    if isinstance(atype, bytes): atype = atype.decode('utf-8', errors='replace')

                    duration_min = None
                    if row.Duration:
                        duration_min = round(row.Duration / 10000000 / 60, 2)

                    alerts.append({
                        'id': row.ID,
                        'object': obj or 'Unknown',
                        'server': srv or 'Unknown',
                        'severity': severity,
                        'time': row.EventStartTime.isoformat() if row.EventStartTime else None,
                        'resolved': bool(row.Resolved),
                        'duration_minutes': duration_min,
                        'condition_type': cond,
                        'object_type': otype or '',
                        'action_type': atype or '',
                        'alert_details': msg or '',
                        'type': 'alert'
                    })
                
                cursor.close()
                conn.close()
                
                if alerts:
                    yield f"data: {json.dumps({'alerts': alerts})}\n\n"

            except Exception as e:
                yield f"data: {json.dumps({'error': str(e)})}\n\n"

            time.sleep(1)  # Poll every 1 second
    
    return Response(generate(), mimetype='text/event-stream')

@app.route('/api/feed/recent')
def get_recent_feed():
    """Get recent activity feed"""
    try:
        hours = float(request.args.get('hours', 1))
        limit = int(request.args.get('limit', 100))
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        feed_items = []
        
        # Get trace events (filtered: Duration > 10s, specific EventClasses, exclude system DBs & SQL Sentry)
        object_name_filter = request.args.get('object_name', '')
        trace_params = [limit // 2, int(hours * 3600)]
        object_name_clause = ""
        if object_name_filter:
            object_name_clause = "AND PTD.ObjectName = ?"
            trace_params.append(object_name_filter)

        cursor.execute(f"""
            SELECT TOP (?)
                PTD.ID,
                PTD.StartTime AS EventTime,
                ESC.ServerName,
                PTD.ObjectName,
                CASE 
                    WHEN PTD.Duration > 180000 THEN 'LongRunning'
                    WHEN PTD.Duration > 10000 AND PTD.Duration <= 180000 THEN 'Warning'
                    ELSE 'Info'
                END AS Severity,
                CASE PTD.EventClass
                    WHEN 10 THEN 'RPC:Completed'
                    WHEN 41 THEN 'SQL:StmtCompleted'
                    WHEN 45 THEN 'SP:StmtCompleted'
                    ELSE 'EventClass=' + CAST(PTD.EventClass AS VARCHAR(10))
                END AS EventStatus,
                PTD.Duration AS DurationMs,
                PTD.DatabaseName,
                PTD.CPU,
                PTD.Reads,
                PTD.Writes,
                LEFT(PTD.TextData, 200) AS TextData
            FROM dbo.PerformanceAnalysisTraceData PTD WITH (NOLOCK)
            JOIN dbo.EventSourceConnection ESC ON ESC.ID = PTD.EventSourceConnectionID
            WHERE PTD.StartTime >= DATEADD(SECOND, -?, GETDATE())
              AND PTD.ApplicationName NOT LIKE N'SQL Sentry%'
              AND PTD.DatabaseName NOT IN ('master','SentryOne','msdb')
              AND PTD.EventClass IN (10, 41, 45)
              AND PTD.Duration > 10000
              {object_name_clause}
            ORDER BY PTD.StartTime DESC
        """, *trace_params)
        
        for row in cursor.fetchall():
            query_text = (row.TextData or '')[:200]
            time_str = None
            if row.EventTime:
                time_str = row.EventTime.isoformat() + 'Z' if not row.EventTime.isoformat().endswith('Z') else row.EventTime.isoformat()
            
            feed_items.append({
                'id': f"query_{row.ID}",
                'object': query_text,
                'object_name': row.ObjectName or '',
                'server': row.ServerName or 'Unknown',
                'database': row.DatabaseName or 'Unknown',
                'severity': row.Severity or 'Info',
                'event_status': row.EventStatus or '',
                'time': time_str,
                'duration_ms': row.DurationMs or 0,
                'cpu': row.CPU or 0,
                'reads': row.Reads or 0,
                'writes': row.Writes or 0,
                'type': 'query'
            })
        
        # Get recent deadlocks
        try:
            cursor.execute("""
                SELECT TOP (?)
                    ID,
                    EventTime,
                    DatabaseName,
                    SPID as VictimSPID,
                    HostName as VictimHostName,
                    LoginName as VictimLoginName,
                    ApplicationName as VictimApplicationName
                FROM dbo.MetaHistorySqlServerBlockLog
                WHERE EventTime >= DATEADD(MINUTE, -?, GETDATE())
                    AND WaitType = 'DEADLOCK'
                ORDER BY EventTime DESC
            """, limit // 3, int(hours * 60))

            for row in cursor.fetchall():
                time_str = None
                if row.EventTime:
                    time_str = row.EventTime.isoformat() + 'Z' if not row.EventTime.isoformat().endswith('Z') else row.EventTime.isoformat()
                
                feed_items.append({
                    'id': f"deadlock_{row.ID}",
                    'database': row.DatabaseName or 'Unknown',
                    'victim_spid': row.VictimSPID,
                    'victim_host': row.VictimHostName or 'Unknown',
                    'victim_login': row.VictimLoginName or 'Unknown',
                    'victim_app': row.VictimApplicationName or 'Unknown',
                    'time': time_str,
                    'severity': 'Critical',
                    'type': 'deadlock'
                })
        except:
            pass
        
        # Get recent alerts from vwObjectConditionActionHistory
        try:
            cursor.execute("""
                SELECT TOP (?)
                    ID,
                    EventStartTime,
                    EventEndTime,
                    ObjectTypeName,
                    ObjectName,
                    ConditionTypeName,
                    ActionTypeName,
                    Message,
                    ParentObjectName,
                    Duration
                FROM dbo.vwObjectConditionActionHistory
                WHERE EventStartTime >= DATEADD(MINUTE, -?, GETDATE())
                  AND ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')
                ORDER BY EventStartTime DESC
            """, limit // 2, int(hours * 60))

            for row in cursor.fetchall():
                def safe_str(val):
                    if val is None: return None
                    if isinstance(val, bytes): return val.decode('utf-8', errors='replace')
                    return str(val)

                duration_min = None
                if row.Duration:
                    duration_min = round(row.Duration / 10000000 / 60, 2)  # ticks to minutes

                time_str = None
                if row.EventStartTime:
                    time_str = row.EventStartTime.isoformat()
                    if not time_str.endswith('Z'):
                        time_str += 'Z'

                msg = safe_str(row.Message)
                if msg and len(msg) > 500:
                    msg = msg[:500] + '...'

                # Derive severity from condition/message content
                cond = safe_str(row.ConditionTypeName) or ''
                if 'error' in cond.lower() or 'fail' in cond.lower() or 'critical' in cond.lower():
                    severity = 'Critical'
                elif 'warning' in cond.lower() or 'high' in cond.lower():
                    severity = 'Warning'
                else:
                    severity = 'Info'

                feed_items.append({
                    'id': f"alert_{row.ID}",
                    'object': safe_str(row.ObjectName) or 'Unknown',
                    'server': safe_str(row.ParentObjectName) or 'Unknown',
                    'severity': severity,
                    'time': time_str,
                    'resolved': bool(row.EventEndTime),
                    'duration_minutes': duration_min,
                    'condition_type': safe_str(row.ConditionTypeName),
                    'object_type': safe_str(row.ObjectTypeName),
                    'action_type': safe_str(row.ActionTypeName),
                    'alert_details': msg,
                    'type': 'alert'
                })
        except:
            pass  # vwObjectConditionActionHistory might not exist
        
        # Sort all items by time
        feed_items.sort(key=lambda x: x.get('time') or '', reverse=True)
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'items': feed_items[:limit],
            'total': len(feed_items),
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e), 'items': []}), 500

@app.route('/api/feed/proc-trend')
def get_proc_trend():
    """Get procedure duration trend over time for charting"""
    try:
        hours = float(request.args.get('hours', 1))
        object_name = request.args.get('object_name', '')
        conn = get_db_connection()
        cursor = conn.cursor()

        params = [int(hours * 3600)]
        obj_clause = ""
        if object_name:
            obj_clause = "AND PTD.ObjectName = ?"
            params.append(object_name)

        cursor.execute(f"""
            SELECT
                PTD.StartTime,
                PTD.ObjectName,
                PTD.Duration AS DurationMs,
                PTD.CPU,
                PTD.Reads,
                PTD.Writes,
                PTD.DatabaseName,
                ESC.ServerName,
                LEFT(PTD.TextData, 500) AS TextData,
                PTD.ApplicationName
            FROM dbo.PerformanceAnalysisTraceData PTD WITH (NOLOCK)
            JOIN dbo.EventSourceConnection ESC ON ESC.ID = PTD.EventSourceConnectionID
            WHERE PTD.StartTime >= DATEADD(SECOND, -?, GETDATE())
              AND PTD.ApplicationName NOT LIKE N'SQL Sentry%'
              AND PTD.DatabaseName NOT IN ('master','SentryOne','msdb')
              AND PTD.EventClass IN (10, 41, 45)
              AND PTD.Duration > 10000
              {obj_clause}
            ORDER BY PTD.StartTime ASC
        """, *params)

        points = []
        for row in cursor.fetchall():
            time_str = row.StartTime.isoformat() + 'Z' if row.StartTime else None
            points.append({
                'time': time_str,
                'duration_ms': row.DurationMs or 0,
                'cpu': row.CPU or 0,
                'reads': row.Reads or 0,
                'writes': row.Writes or 0,
                'object_name': row.ObjectName or '',
                'database': row.DatabaseName or '',
                'server': row.ServerName or '',
                'text_data': (row.TextData or '')[:500],
                'application': row.ApplicationName or ''
            })

        cursor.close()
        conn.close()
        return jsonify({'points': points, 'total': len(points)})
    except Exception as e:
        return jsonify({'error': str(e), 'points': [], 'total': 0}), 500


@app.route('/api/feed/proc-statements')
def get_proc_statements():
    """Get statement-level breakdown inside a stored procedure (SP:StmtCompleted events)"""
    try:
        hours = float(request.args.get('hours', 1))
        object_name = request.args.get('object_name', '')
        if not object_name:
            return jsonify({'error': 'object_name required', 'statements': []}), 400

        conn = get_db_connection()
        cursor = conn.cursor()

        # EventClass 45 = SP:StmtCompleted has EMPTY ObjectName.
        # We correlate by finding SPIDs that ran the proc (EC 10) and then
        # getting EC 45 rows for those same SPIDs within the proc's execution window.
        time_seconds = int(hours * 3600)

        cursor.execute("""
            SELECT
                LEFT(S.TextData, 800) AS TextData,
                COUNT(*) AS ExecCount,
                AVG(S.Duration) AS AvgDurationMs,
                MAX(S.Duration) AS MaxDurationMs,
                MIN(S.Duration) AS MinDurationMs,
                SUM(S.Duration) AS TotalDurationMs,
                AVG(S.CPU) AS AvgCPU,
                MAX(S.CPU) AS MaxCPU,
                SUM(S.CPU) AS TotalCPU,
                AVG(S.Reads) AS AvgReads,
                MAX(S.Reads) AS MaxReads,
                SUM(S.Reads) AS TotalReads,
                AVG(S.Writes) AS AvgWrites,
                SUM(S.Writes) AS TotalWrites,
                S.DatabaseName,
                ESC.ServerName
            FROM dbo.PerformanceAnalysisTraceData S WITH (NOLOCK)
            JOIN dbo.EventSourceConnection ESC ON ESC.ID = S.EventSourceConnectionID
            WHERE S.EventClass = 45
              AND S.TextData IS NOT NULL
              AND S.TextData <> ''
              AND S.Duration > 0
              AND S.StartTime >= DATEADD(SECOND, -?, GETDATE())
              AND EXISTS (
                  SELECT 1
                  FROM dbo.PerformanceAnalysisTraceData P WITH (NOLOCK)
                  WHERE P.ObjectName = ?
                    AND P.EventClass = 10
                    AND P.StartTime >= DATEADD(SECOND, -?, GETDATE())
                    AND P.SPID = S.SPID
                    AND P.EventSourceConnectionID = S.EventSourceConnectionID
                    AND S.StartTime >= P.StartTime
                    AND S.StartTime <= DATEADD(MILLISECOND, P.Duration, P.StartTime)
              )
            GROUP BY LEFT(S.TextData, 800), S.DatabaseName, ESC.ServerName
            ORDER BY SUM(S.Duration) DESC
        """, time_seconds, object_name, time_seconds)

        statements = []
        for row in cursor.fetchall():
            statements.append({
                'text': (row.TextData or '').strip(),
                'exec_count': row.ExecCount or 0,
                'avg_duration_ms': row.AvgDurationMs or 0,
                'max_duration_ms': row.MaxDurationMs or 0,
                'min_duration_ms': row.MinDurationMs or 0,
                'total_duration_ms': row.TotalDurationMs or 0,
                'avg_cpu': row.AvgCPU or 0,
                'max_cpu': row.MaxCPU or 0,
                'total_cpu': row.TotalCPU or 0,
                'avg_reads': row.AvgReads or 0,
                'max_reads': row.MaxReads or 0,
                'total_reads': row.TotalReads or 0,
                'avg_writes': row.AvgWrites or 0,
                'total_writes': row.TotalWrites or 0,
                'database': row.DatabaseName or '',
                'server': row.ServerName or '',
                'event_class': 'SP:StmtCompleted'
            })

        # Fallback: if no EC 45 data, show the proc-level calls (EC 10) grouped by TextData
        if not statements:
            cursor.execute("""
                SELECT
                    LEFT(PTD.TextData, 800) AS TextData,
                    COUNT(*) AS ExecCount,
                    AVG(PTD.Duration) AS AvgDurationMs,
                    MAX(PTD.Duration) AS MaxDurationMs,
                    MIN(PTD.Duration) AS MinDurationMs,
                    SUM(PTD.Duration) AS TotalDurationMs,
                    AVG(PTD.CPU) AS AvgCPU,
                    MAX(PTD.CPU) AS MaxCPU,
                    SUM(PTD.CPU) AS TotalCPU,
                    AVG(PTD.Reads) AS AvgReads,
                    MAX(PTD.Reads) AS MaxReads,
                    SUM(PTD.Reads) AS TotalReads,
                    AVG(PTD.Writes) AS AvgWrites,
                    SUM(PTD.Writes) AS TotalWrites,
                    PTD.DatabaseName,
                    ESC.ServerName
                FROM dbo.PerformanceAnalysisTraceData PTD WITH (NOLOCK)
                JOIN dbo.EventSourceConnection ESC ON ESC.ID = PTD.EventSourceConnectionID
                WHERE PTD.StartTime >= DATEADD(SECOND, -?, GETDATE())
                  AND PTD.ObjectName = ?
                  AND PTD.EventClass = 10
                  AND PTD.TextData IS NOT NULL
                  AND PTD.TextData <> ''
                  AND PTD.Duration > 0
                GROUP BY LEFT(PTD.TextData, 800), PTD.DatabaseName, ESC.ServerName
                ORDER BY SUM(PTD.Duration) DESC
            """, time_seconds, object_name)

            for row in cursor.fetchall():
                statements.append({
                    'text': (row.TextData or '').strip(),
                    'exec_count': row.ExecCount or 0,
                    'avg_duration_ms': row.AvgDurationMs or 0,
                    'max_duration_ms': row.MaxDurationMs or 0,
                    'min_duration_ms': row.MinDurationMs or 0,
                    'total_duration_ms': row.TotalDurationMs or 0,
                    'avg_cpu': row.AvgCPU or 0,
                    'max_cpu': row.MaxCPU or 0,
                    'total_cpu': row.TotalCPU or 0,
                    'avg_reads': row.AvgReads or 0,
                    'max_reads': row.MaxReads or 0,
                    'total_reads': row.TotalReads or 0,
                    'avg_writes': row.AvgWrites or 0,
                    'total_writes': row.TotalWrites or 0,
                    'database': row.DatabaseName or '',
                    'server': row.ServerName or '',
                    'event_class': 'RPC:Completed'
                })

        cursor.close()
        conn.close()
        return jsonify({'statements': statements, 'total': len(statements), 'object_name': object_name})
    except Exception as e:
        return jsonify({'error': str(e), 'statements': [], 'total': 0}), 500


@app.route('/api/feed/exec-plan')
def get_exec_plan():
    """Get execution plan for a specific procedure/query from SentryOne cached plans"""
    try:
        hours = float(request.args.get('hours', 1))
        object_name = request.args.get('object_name', '')
        if not object_name:
            return jsonify({'error': 'object_name required', 'plan': None}), 400

        minutes = int(hours * 60)
        conn = get_db_connection()
        cursor = conn.cursor()

        # Find the most recent execution plan for this object
        cursor.execute("""
            SELECT TOP 1
                PP.PlanTextGZ,
                PP.MissingIndexes,
                PP.ID as PlanID,
                TCP.SizeInBytes,
                TCP.UseCounts,
                TCP.PlanCreationTime,
                TCP.DatabaseName,
                PTD.Duration,
                PTD.CPU,
                PTD.Reads,
                PTD.StartTime
            FROM dbo.PerformanceAnalysisTraceData PTD
            JOIN dbo.PerformanceAnalysisTraceDataToCachedPlans TDCP
                ON TDCP.PerformanceAnalysisTraceDataID = PTD.ID
            JOIN dbo.PerformanceAnalysisTraceCachedPlans TCP
                ON TCP.ID = TDCP.PerformanceAnalysisTraceCachedPlansID
            JOIN dbo.PerformanceAnalysisPlan PP
                ON PP.PlanHash = TCP.NormalizedPlanHash
            WHERE PTD.StartTime >= DATEADD(MINUTE, -?, GETDATE())
              AND PTD.EventClass = 10
              AND PTD.ObjectName = ?
            ORDER BY PTD.Duration DESC
        """, minutes, object_name)

        row = cursor.fetchone()
        if not row or not row.PlanTextGZ:
            cursor.close()
            conn.close()
            return jsonify({'plan': None, 'message': 'No execution plan found'})

        # Decompress the gzipped XML plan
        plan_xml = ''
        try:
            plan_xml = _gzip.decompress(bytes(row.PlanTextGZ)).decode('utf-8', errors='replace')
        except Exception:
            cursor.close()
            conn.close()
            return jsonify({'plan': None, 'message': 'Failed to decompress plan'})

        # Parse the XML to extract operator summary
        ns = {'sp': 'http://schemas.microsoft.com/sqlserver/2004/07/showplan'}
        operators = []
        warnings = []
        missing_indexes = []
        total_cost = 0
        try:
            root = _ET.fromstring(plan_xml)
            # Extract operators (RelOp nodes)
            for relop in root.iter('{http://schemas.microsoft.com/sqlserver/2004/07/showplan}RelOp'):
                phys = relop.get('PhysicalOp', '')
                logic = relop.get('LogicalOp', '')
                cost = float(relop.get('EstimatedTotalSubtreeCost', 0))
                rows = float(relop.get('EstimateRows', 0))
                io = float(relop.get('EstimatedIOCost', 0) if relop.get('EstimatedIOCost') else 0)
                cpu_cost = float(relop.get('EstimatedCPUCost', 0) if relop.get('EstimatedCPUCost') else 0)
                parallel = relop.get('Parallel', '0') == '1'
                operators.append({
                    'physical_op': phys,
                    'logical_op': logic,
                    'est_cost': round(cost, 4),
                    'est_rows': round(rows),
                    'est_io': round(io, 4),
                    'est_cpu': round(cpu_cost, 4),
                    'parallel': parallel
                })

            # Extract statement costs
            for stmt in root.iter('{http://schemas.microsoft.com/sqlserver/2004/07/showplan}StmtSimple'):
                sc = stmt.get('StatementSubTreeCost')
                if sc:
                    total_cost += float(sc)

            # Extract warnings
            for warn in root.iter('{http://schemas.microsoft.com/sqlserver/2004/07/showplan}Warnings'):
                for child in warn:
                    tag = child.tag.split('}')[-1] if '}' in child.tag else child.tag
                    warnings.append(tag)

            # Extract missing indexes
            for mi in root.iter('{http://schemas.microsoft.com/sqlserver/2004/07/showplan}MissingIndex'):
                db = mi.get('Database', '')
                schema = mi.get('Schema', '')
                table = mi.get('Table', '')
                cols = []
                for cg in mi:
                    usage = cg.get('Usage', '')
                    for col in cg:
                        cols.append({'name': col.get('Name', ''), 'usage': usage})
                missing_indexes.append({
                    'database': db, 'schema': schema, 'table': table, 'columns': cols
                })
        except Exception:
            pass  # If XML parsing fails, still return the raw XML

        # Summarize operators by type
        op_summary = {}
        for op in operators:
            key = op['physical_op']
            if key not in op_summary:
                op_summary[key] = {'count': 0, 'total_cost': 0, 'total_rows': 0, 'parallel': False}
            op_summary[key]['count'] += 1
            op_summary[key]['total_cost'] = max(op_summary[key]['total_cost'], op['est_cost'])
            op_summary[key]['total_rows'] += op['est_rows']
            if op['parallel']:
                op_summary[key]['parallel'] = True

        op_list = sorted(op_summary.items(), key=lambda x: x[1]['total_cost'], reverse=True)

        creation_time = None
        if row.PlanCreationTime:
            creation_time = row.PlanCreationTime.isoformat()

        cursor.close()
        conn.close()

        return jsonify({
            'plan': {
                'xml': plan_xml,
                'plan_id': row.PlanID,
                'size_bytes': row.SizeInBytes,
                'use_counts': row.UseCounts,
                'creation_time': creation_time,
                'missing_index_count': row.MissingIndexes or 0,
                'total_cost': round(total_cost, 2),
                'operator_count': len(operators),
                'operators': [{'name': k, 'count': v['count'], 'est_cost': round(v['total_cost'], 4), 'est_rows': round(v['total_rows']), 'parallel': v['parallel']} for k, v in op_list[:30]],
                'warnings': warnings,
                'missing_indexes': missing_indexes,
                'exec_duration': row.Duration,
                'exec_cpu': row.CPU,
                'exec_reads': row.Reads,
            }
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'plan': None}), 500


@app.route('/api/feed/object-names')
def get_object_names():
    """Get distinct ObjectName values from trace data for procedure filter dropdown"""
    try:
        hours = float(request.args.get('hours', 24))
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT DISTINCT TOP 200 PTD.ObjectName
            FROM dbo.PerformanceAnalysisTraceData PTD WITH (NOLOCK)
            WHERE PTD.StartTime >= DATEADD(SECOND, -?, GETDATE())
              AND PTD.ApplicationName NOT LIKE N'SQL Sentry%'
              AND PTD.DatabaseName NOT IN ('master','SentryOne','msdb')
              AND PTD.EventClass IN (10, 41, 45)
              AND PTD.Duration > 10000
              AND PTD.ObjectName IS NOT NULL
              AND PTD.ObjectName != ''
            ORDER BY PTD.ObjectName
        """, int(hours * 3600))
        names = [row.ObjectName for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return jsonify({'items': names})
    except Exception as e:
        return jsonify({'error': str(e), 'items': []}), 500

@app.route('/api/feed/stats')
def get_feed_stats():
    """Get real-time statistics"""
    try:
        hours = float(request.args.get('hours', 1))
        conn = get_db_connection()
        cursor = conn.cursor()
        
        stats = {
            'alert_stats': {'total': 0, 'critical': 0, 'warning': 0, 'info': 0},
            'active_now': 0,
            'blocking_count': 0,
            'deadlock_count': 0,
            'query_count': 0,
            'top_servers': [],
            'top_objects': []
        }
        
        # Alert stats for the selected time range
        cursor.execute("""
            SELECT 
                COUNT(*) as Total,
                SUM(CASE WHEN ConditionTypeName LIKE '%Error%' OR ConditionTypeName LIKE '%Fail%' OR ConditionTypeName LIKE '%Critical%' THEN 1 ELSE 0 END) as Critical,
                SUM(CASE WHEN ConditionTypeName LIKE '%Warning%' OR ConditionTypeName LIKE '%High%' THEN 1 ELSE 0 END) as Warning,
                SUM(CASE WHEN ConditionTypeName NOT LIKE '%Error%' AND ConditionTypeName NOT LIKE '%Fail%' AND ConditionTypeName NOT LIKE '%Critical%' AND ConditionTypeName NOT LIKE '%Warning%' AND ConditionTypeName NOT LIKE '%High%' THEN 1 ELSE 0 END) as Info
            FROM dbo.vwObjectConditionActionHistory
            WHERE EventStartTime >= DATEADD(SECOND, -?, GETDATE())
              AND ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')
        """, int(hours * 3600))
        row = cursor.fetchone()
        if row:
            stats['alert_stats'] = {
                'total': row.Total or 0,
                'critical': row.Critical or 0,
                'warning': row.Warning or 0,
                'info': row.Info or 0
            }
        
        # Active alerts (no end time = still active) within selected range
        cursor.execute("""
            SELECT COUNT(*) as Active
            FROM dbo.vwObjectConditionActionHistory
            WHERE EventEndTime IS NULL
              AND EventStartTime >= DATEADD(SECOND, -?, GETDATE())
              AND ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')
        """, int(hours * 3600))
        row = cursor.fetchone()
        if row:
            stats['active_now'] = row.Active or 0
        
        # Blocking count (selected range)
        try:
            cursor.execute("""
                SELECT COUNT(*) as Total
                FROM dbo.BlockChain
                WHERE StartTime >= DATEADD(SECOND, -?, GETDATE())
            """, int(hours * 3600))
            row = cursor.fetchone()
            if row:
                stats['blocking_count'] = row.Total or 0
        except:
            pass
        
        # Deadlock count (selected range)
        try:
            cursor.execute("""
                SELECT COUNT(*) as Total
                FROM dbo.MetaHistorySqlServerBlockLog
                WHERE EventTime >= DATEADD(SECOND, -?, GETDATE())
                    AND WaitType = 'DEADLOCK'
            """, int(hours * 3600))
            row = cursor.fetchone()
            if row:
                stats['deadlock_count'] = row.Total or 0
        except:
            pass
        
        # Query count (selected range)
        try:
            cursor.execute("""
                SELECT COUNT(*) as Total
                FROM dbo.PerformanceAnalysisTraceData
                WHERE StartTime >= DATEADD(SECOND, -?, GETDATE())
                    AND TextData IS NOT NULL
                    AND TextData <> 'sp_trace_getdata 2, 0'
            """, int(hours * 3600))
            row = cursor.fetchone()
            if row:
                stats['query_count'] = row.Total or 0
        except:
            pass
        
        # Top servers by alert count (selected range)
        cursor.execute("""
            SELECT TOP 5
                ParentObjectName as Server,
                COUNT(*) as AlertCount
            FROM dbo.vwObjectConditionActionHistory
            WHERE EventStartTime >= DATEADD(SECOND, -?, GETDATE())
                AND ParentObjectName IS NOT NULL
                AND ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')
            GROUP BY ParentObjectName
            ORDER BY COUNT(*) DESC
        """, int(hours * 3600))
        stats['top_servers'] = [
            {'server': row.Server, 'count': row.AlertCount}
            for row in cursor.fetchall()
        ]
        
        # Top objects by alert count (selected range)
        cursor.execute("""
            SELECT TOP 5
                ObjectName as Object,
                COUNT(*) as AlertCount
            FROM dbo.vwObjectConditionActionHistory
            WHERE EventStartTime >= DATEADD(SECOND, -?, GETDATE())
                AND ObjectName IS NOT NULL
                AND ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')
            GROUP BY ObjectName
            ORDER BY COUNT(*) DESC
        """, int(hours * 3600))
        stats['top_objects'] = [
            {'object': row.Object, 'count': row.AlertCount}
            for row in cursor.fetchall()
        ]
        
        cursor.close()
        conn.close()
        
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/feed/deadlocks')
def get_deadlocks():
    """Get recent deadlocks"""
    try:
        hours = int(request.args.get('hours', 24))
        conn = get_db_connection()
        cursor = conn.cursor()
        
        deadlock_items = []
        
        # Primary: PerformanceAnalysisTraceDeadlock with resource/database joins
        try:
            cursor.execute("""
                SELECT TOP 20
                    PATD.ID,
                    PATD.StartTime,
                    ESC.ServerName,
                    DD.DatabaseName,
                    DR.ResourceName
                FROM dbo.PerformanceAnalysisTraceDeadlock PATD
                JOIN dbo.EventSourceConnection ESC ON ESC.ID = PATD.EventSourceConnectionID
                LEFT JOIN dbo.DeadlockDatabaseDeadlock DDD ON DDD.DeadlockID = PATD.ID
                LEFT JOIN dbo.DeadlockDatabase DD ON DD.ID = DDD.DeadlockDatabaseID
                LEFT JOIN dbo.DeadlockResourceDeadlock DRD ON DRD.DeadlockID = PATD.ID
                LEFT JOIN dbo.DeadlockResource DR ON DR.ID = DRD.DeadlockResourceID
                WHERE PATD.StartTime >= DATEADD(MINUTE, -?, GETDATE())
                ORDER BY PATD.StartTime DESC
            """, int(hours * 60))

            seen_ids = set()
            for row in cursor.fetchall():
                if row.ID in seen_ids:
                    continue
                seen_ids.add(row.ID)
                time_str = None
                if row.StartTime:
                    time_str = row.StartTime.isoformat() + 'Z' if not row.StartTime.isoformat().endswith('Z') else row.StartTime.isoformat()

                deadlock_items.append({
                    'id': f"deadlock_{row.ID}",
                    'server': row.ServerName or 'Unknown',
                    'database': row.DatabaseName or 'Unknown',
                    'resource': row.ResourceName or '',
                    'time': time_str,
                    'source': 'trace',
                    'type': 'deadlock'
                })
        except:
            pass

        # Fallback: MetaHistorySqlServerBlockLog
        if not deadlock_items:
            try:
                cursor.execute("""
                    SELECT TOP 20
                        ID,
                        EventTime,
                        DatabaseName,
                        VictimSPID,
                        VictimHostName,
                        VictimLoginName,
                        VictimApplicationName
                    FROM dbo.MetaHistorySqlServerBlockLog
                    WHERE EventTime >= DATEADD(MINUTE, -?, GETDATE())
                        AND WaitType = 'DEADLOCK'
                    ORDER BY EventTime DESC
                """, int(hours * 60))

                for row in cursor.fetchall():
                    time_str = None
                    if row.EventTime:
                        time_str = row.EventTime.isoformat() + 'Z' if not row.EventTime.isoformat().endswith('Z') else row.EventTime.isoformat()

                    deadlock_items.append({
                        'id': f"deadlock_{row.ID}",
                        'database': row.DatabaseName or 'Unknown',
                        'server': 'Unknown',
                        'resource': '',
                        'victim_spid': row.VictimSPID,
                        'victim_host': row.VictimHostName or 'Unknown',
                        'victim_login': row.VictimLoginName or 'Unknown',
                        'victim_app': row.VictimApplicationName or 'Unknown',
                        'time': time_str,
                        'source': 'blocklog',
                        'type': 'deadlock'
                    })
            except:
                pass
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'items': deadlock_items,
            'total': len(deadlock_items),
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e), 'items': []}), 500

@app.route('/api/feed/blocking')
def get_blocking_feed():
    """Get current blocking sessions using BlockChain tables"""
    try:
        hours = float(request.args.get('hours', 1))
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        blocking_items = []
        
        # Use BlockChain, BlockChainDetail, and EventSourceConnection tables
        cursor.execute("""
            SELECT TOP 200
                BC.ID as ChainID,
                BCD.ID as DetailID,
                BCD.SPID,
                BCD.BlockedBySpid,
                BCD.DatabaseName,
                BCD.HostName,
                BCD.ProgramName,
                BCD.LoginName,
                BCD.WaitType,
                BCD.WaitTime,
                BCD.WaitResource,
                BCD.WaitResourceFriendly,
                LEFT(BCD.CommandText, 1000) as CommandText,
                BCD.ObjectName,
                BCD.LastBatch,
                BC.StartTime,
                BC.EndTime,
                ESC.ServerName
            FROM dbo.BlockChain BC
            JOIN dbo.EventSourceConnection ESC ON ESC.ID = BC.EventSourceConnectionID
            JOIN dbo.BlockChainDetail BCD ON BC.ID = BCD.BlockChainID
            WHERE BC.StartTime >= DATEADD(MINUTE, -?, GETDATE())
            ORDER BY BC.StartTime DESC, BCD.WaitTime DESC
        """, int(hours * 60))

        def _s(v, default='Unknown'):
            if v is None: return default
            return v.decode('utf-8', errors='replace') if isinstance(v, bytes) else str(v)

        for row in cursor.fetchall():
            time_str = None
            if row.StartTime:
                time_str = row.StartTime.isoformat() + 'Z' if not row.StartTime.isoformat().endswith('Z') else row.StartTime.isoformat()
            end_str = None
            if row.EndTime:
                end_str = row.EndTime.isoformat() + 'Z' if not row.EndTime.isoformat().endswith('Z') else row.EndTime.isoformat()
            last_batch_str = None
            if row.LastBatch:
                last_batch_str = row.LastBatch.isoformat() + 'Z' if not row.LastBatch.isoformat().endswith('Z') else row.LastBatch.isoformat()

            blocking_items.append({
                'chain_id': row.ChainID,
                'detail_id': row.DetailID,
                'spid': row.SPID,
                'blocking_spid': row.BlockedBySpid or 0,
                'database': _s(row.DatabaseName),
                'wait_type': _s(row.WaitType),
                'wait_time_ms': row.WaitTime or 0,
                'wait_resource': _s(row.WaitResource, ''),
                'wait_resource_friendly': _s(row.WaitResourceFriendly, ''),
                'command_text': _s(row.CommandText, ''),
                'object_name': _s(row.ObjectName, ''),
                'last_batch': last_batch_str,
                'login': _s(row.LoginName),
                'host': _s(row.HostName),
                'program': _s(row.ProgramName),
                'server': _s(row.ServerName),
                'time': time_str,
                'end_time': end_str,
                'type': 'blocking'
            })
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'items': blocking_items,
            'total': len(blocking_items),
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
        
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'items': []}), 500

@app.route('/api/feed/health')
def get_server_health():
    """Get health status for all monitored SQL Server instances"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        servers = []

        # First, discover which columns exist in EventSourceConnection
        esc_cols = set()
        try:
            cursor.execute("SELECT TOP 0 * FROM dbo.EventSourceConnection")
            esc_cols = {desc[0] for desc in cursor.description}
        except:
            pass

        has_obj_name = 'ObjectName' in esc_cols
        has_watched = 'IsWatched' in esc_cols
        has_last_mod = 'LastModified' in esc_cols
        has_last_sync = 'LastObjectSynchronizationTime' in esc_cols
        has_active = 'IsActive' in esc_cols

        # Build dynamic SELECT
        select_parts = ["ESC.ID", "ESC.ServerName"]
        if has_active:
            select_parts.append("ESC.IsActive")
        if has_obj_name:
            select_parts.append("ESC.ObjectName")
        if has_watched:
            select_parts.append("ESC.IsWatched")
        if has_last_mod:
            select_parts.append("ESC.LastModified")
        if has_last_sync:
            select_parts.append("ESC.LastObjectSynchronizationTime")
            select_parts.append("DATEDIFF(MINUTE, ESC.LastObjectSynchronizationTime, GETUTCDATE()) as MinutesSinceSync")

        # Device columns (safe with LEFT JOIN)
        dev_cols = set()
        try:
            cursor.execute("SELECT TOP 0 * FROM dbo.Device")
            dev_cols = {desc[0] for desc in cursor.description}
        except:
            pass

        has_device = 'DeviceID' in esc_cols
        if has_device:
            if 'HostName' in dev_cols:
                select_parts.append("D.HostName as DeviceHostName")
            if 'FullyQualifiedDomainName' in dev_cols:
                select_parts.append("D.FullyQualifiedDomainName as FQDN")
            if 'IPAddress' in dev_cols:
                select_parts.append("D.IPAddress")

        # Alert and blocking subqueries (using vwObjectConditionActionHistory)
        select_parts.extend([
            """(SELECT COUNT(*) FROM dbo.vwObjectConditionActionHistory V
                 WHERE V.ParentObjectName LIKE '%' + ESC.ServerName + '%'
                   AND V.EventStartTime >= DATEADD(HOUR, -1, GETDATE())
                   AND V.EventEndTime IS NULL
                   AND V.ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')) as ActiveAlerts""",
            """(SELECT COUNT(*) FROM dbo.vwObjectConditionActionHistory V
                 WHERE V.ParentObjectName LIKE '%' + ESC.ServerName + '%'
                   AND V.EventStartTime >= DATEADD(HOUR, -1, GETDATE())
                   AND (V.ConditionTypeName LIKE '%Error%' OR V.ConditionTypeName LIKE '%Fail%' OR V.ConditionTypeName LIKE '%Critical%')
                   AND V.EventEndTime IS NULL
                   AND V.ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')) as CriticalAlerts""",
            """(SELECT COUNT(*) FROM dbo.BlockChain BC
                 WHERE BC.EventSourceConnectionID = ESC.ID
                   AND BC.StartTime >= DATEADD(HOUR, -1, GETDATE())
                   AND BC.EndTime IS NULL) as ActiveBlocking""",
            """(SELECT MAX(V.EventStartTime) FROM dbo.vwObjectConditionActionHistory V
                 WHERE V.ParentObjectName LIKE '%' + ESC.ServerName + '%'
                   AND V.ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')) as LastAlertTime""",
            """(SELECT COUNT(*) FROM dbo.vwObjectConditionActionHistory V
                 WHERE V.ParentObjectName LIKE '%' + ESC.ServerName + '%'
                   AND V.EventStartTime >= DATEADD(HOUR, -24, GETDATE())
                   AND V.ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')) as Alerts24h"""
        ])

        join_clause = "LEFT JOIN dbo.Device D ON D.ID = ESC.DeviceID" if has_device else ""

        query = f"""
            SELECT {', '.join(select_parts)}
            FROM dbo.EventSourceConnection ESC
            {join_clause}
            WHERE ESC.ServerName IS NOT NULL AND ESC.ServerName != ''
            ORDER BY ESC.ServerName
        """
        cursor.execute(query)

        # Build a set of result column names for safe access
        result_cols = {desc[0] for desc in cursor.description}

        def safe(row, col, default=None):
            return getattr(row, col, default) if col in result_cols else default

        for row in cursor.fetchall():
            active_alerts = safe(row, 'ActiveAlerts', 0) or 0
            critical = safe(row, 'CriticalAlerts', 0) or 0
            blocking = safe(row, 'ActiveBlocking', 0) or 0
            mins_since_sync = safe(row, 'MinutesSinceSync')
            is_watched_raw = safe(row, 'IsWatched')
            is_watched = bool(is_watched_raw) if is_watched_raw is not None else True

            # Determine health status
            if has_watched and not is_watched:
                status = 'disabled'
            elif mins_since_sync is not None and mins_since_sync > 30:
                status = 'stale'
            elif critical > 0 or blocking > 2:
                status = 'critical'
            elif active_alerts > 0 or blocking > 0:
                status = 'warning'
            else:
                status = 'healthy'

            last_alert_val = safe(row, 'LastAlertTime')
            last_alert = last_alert_val.isoformat() if last_alert_val else None
            last_sync_val = safe(row, 'LastObjectSynchronizationTime')
            last_sync = last_sync_val.isoformat() if last_sync_val else None
            last_mod_val = safe(row, 'LastModified')
            last_modified = last_mod_val.isoformat() if last_mod_val else None

            servers.append({
                'id': row.ID,
                'server': row.ServerName,
                'object_name': safe(row, 'ObjectName') or row.ServerName,
                'hostname': safe(row, 'DeviceHostName') or '',
                'fqdn': safe(row, 'FQDN') or '',
                'ip_address': safe(row, 'IPAddress') or '',
                'is_active': bool(safe(row, 'IsActive', True)),
                'is_watched': is_watched,
                'status': status,
                'active_alerts': active_alerts,
                'critical_alerts': critical,
                'active_blocking': blocking,
                'alerts_24h': safe(row, 'Alerts24h', 0) or 0,
                'last_alert': last_alert,
                'last_sync': last_sync,
                'last_modified': last_modified,
                'mins_since_sync': mins_since_sync,
                'type': 'health'
            })

        cursor.close()
        conn.close()

        # Summary counts
        healthy = sum(1 for s in servers if s['status'] == 'healthy')
        warning = sum(1 for s in servers if s['status'] == 'warning')
        critical_count = sum(1 for s in servers if s['status'] == 'critical')
        stale = sum(1 for s in servers if s['status'] == 'stale')
        disabled = sum(1 for s in servers if s['status'] == 'disabled')
        watched = sum(1 for s in servers if s['is_watched'])

        return jsonify({
            'items': servers,
            'total': len(servers),
            'healthy': healthy,
            'warning': warning,
            'critical': critical_count,
            'stale': stale,
            'disabled': disabled,
            'watched': watched,
            'timestamp': datetime.now(timezone.utc).isoformat()
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'items': [], 'total': 0}), 500

@app.route('/api/feed/groups')
def get_groups():
    """Return distinct device groups from SQL Sentry for filter dropdown"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Discover group tables
        cursor.execute("""
            SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_NAME IN ('DeviceGroup','ServerGroup','Category','DeviceCategory')
              AND TABLE_SCHEMA = 'dbo'
        """)
        group_tables = {r.TABLE_NAME for r in cursor.fetchall()}

        groups = []

        if 'DeviceGroup' in group_tables:
            # Check columns
            cursor.execute("SELECT TOP 0 * FROM dbo.DeviceGroup")
            dg_cols = {d[0] for d in cursor.description}
            name_col = 'Name' if 'Name' in dg_cols else ('GroupName' if 'GroupName' in dg_cols else None)
            if name_col:
                cursor.execute(f"SELECT DISTINCT {name_col} FROM dbo.DeviceGroup ORDER BY {name_col}")
                groups = [r[0] for r in cursor.fetchall() if r[0]]

        cursor.close()
        conn.close()
        return jsonify({'groups': groups})
    except Exception as e:
        return jsonify({'groups': [], 'error': str(e)})


@app.route('/api/feed/performance')
def get_performance_metrics():
    """Get performance metrics per server from SentryOne PerformanceAnalysisData"""
    try:
        hours = float(request.args.get('hours', 1))
        minutes = int(hours * 60)
        conn = get_db_connection()
        cursor = conn.cursor()

        # Timestamp threshold in SentryOne format (seconds since 2000-01-01 / 5)
        ts_filter = f"DATEDIFF(SECOND, '20000101', DATEADD(MINUTE, -{minutes}, GETUTCDATE())) / 5"

        cursor.execute(f"""
            SELECT
                ESC.ServerName,
                D.HostName,
                -- PLE: counter in SQLSERVER:BUFFER_MANAGER category (latest within range)
                (SELECT TOP 1 PAD.Value
                 FROM dbo.PerformanceAnalysisData PAD WITH (NOLOCK)
                 WHERE PAD.EventSourceConnectionID = ESC.ID
                   AND PAD.PerformanceAnalysisCounterID IN (
                       SELECT PAVC.RawCounterID FROM dbo.PerformanceAnalysisVirtualCounter PAVC
                       WHERE PAVC.FriendlyCounterName LIKE 'Page life expectancy%'
                         AND PAVC.PerformanceAnalysisCounterCategoryID = (
                             SELECT ID FROM dbo.PerformanceAnalysisCounterCategory
                             WHERE CategoryResourceName = 'SQLSERVER:BUFFER_MANAGER'))
                   AND PAD.Timestamp >= {ts_filter}
                 ORDER BY PAD.Timestamp DESC) as PLE,
                -- CPU%: counter 1858 = PROCESSOR_INFORMATION (system-level 0-100%, stored by DeviceID)
                (SELECT TOP 1 PAD.Value
                 FROM dbo.PerformanceAnalysisData PAD WITH (NOLOCK)
                 WHERE PAD.DeviceID = ESC.DeviceID
                   AND PAD.PerformanceAnalysisCounterID = 1858
                   AND PAD.Timestamp >= {ts_filter}
                 ORDER BY PAD.Timestamp DESC) as CPUPercent,
                -- Database count from PerformanceAnalysisSqlDatabase
                (SELECT COUNT(*)
                 FROM dbo.PerformanceAnalysisSqlDatabase PASD
                 WHERE PASD.EventSourceConnectionID = ESC.ID) as DatabaseCount,
                -- Trace data metrics within selected range
                (SELECT COUNT(*)
                 FROM dbo.PerformanceAnalysisTraceData PATD WITH (NOLOCK)
                 WHERE PATD.EventSourceConnectionID = ESC.ID
                   AND PATD.StartTime >= DATEADD(MINUTE, -{minutes}, GETDATE())) as QueriesLastHour,
                (SELECT AVG(CAST(Duration AS FLOAT))
                 FROM dbo.PerformanceAnalysisTraceData PATD WITH (NOLOCK)
                 WHERE PATD.EventSourceConnectionID = ESC.ID
                   AND PATD.StartTime >= DATEADD(MINUTE, -{minutes}, GETDATE())
                   AND Duration > 0) as AvgDurationMs,
                (SELECT SUM(CAST(CPU AS FLOAT))
                 FROM dbo.PerformanceAnalysisTraceData PATD WITH (NOLOCK)
                 WHERE PATD.EventSourceConnectionID = ESC.ID
                   AND PATD.StartTime >= DATEADD(MINUTE, -{minutes}, GETDATE())) as TotalCPUMs,
                (SELECT SUM(CAST(Reads AS FLOAT))
                 FROM dbo.PerformanceAnalysisTraceData PATD WITH (NOLOCK)
                 WHERE PATD.EventSourceConnectionID = ESC.ID
                   AND PATD.StartTime >= DATEADD(MINUTE, -{minutes}, GETDATE())) as TotalReads
            FROM dbo.EventSourceConnection ESC
            LEFT JOIN dbo.Device D ON D.ID = ESC.DeviceID
            WHERE ESC.IsWatched = 1
              AND ESC.ServerName IS NOT NULL AND ESC.ServerName != ''
            ORDER BY ESC.ServerName
        """)

        perf_items = []
        for row in cursor.fetchall():
            sname = row.ServerName
            if isinstance(sname, bytes):
                sname = sname.decode('utf-8', errors='replace')
            hname = row.HostName
            if isinstance(hname, bytes):
                hname = hname.decode('utf-8', errors='replace')

            ple = int(row.PLE) if row.PLE is not None else None
            cpu = round(row.CPUPercent, 1) if row.CPUPercent is not None else None
            avg_dur = round(row.AvgDurationMs, 0) if row.AvgDurationMs is not None else None

            # Determine perf status
            if ple is not None and ple < 300:
                perf_status = 'critical'
            elif cpu is not None and cpu > 90:
                perf_status = 'critical'
            elif (ple is not None and ple < 1000) or (cpu is not None and cpu > 70):
                perf_status = 'warning'
            else:
                perf_status = 'healthy'

            perf_items.append({
                'server': sname or 'Unknown',
                'hostname': hname or '',
                'ple': ple,
                'cpu_percent': cpu,
                'database_count': row.DatabaseCount or 0,
                'queries_1h': row.QueriesLastHour or 0,
                'avg_duration_ms': avg_dur,
                'total_cpu_ms': round(row.TotalCPUMs or 0, 0),
                'total_reads': round(row.TotalReads or 0, 0),
                'status': perf_status,
                'type': 'performance'
            })

        cursor.close()
        conn.close()

        return jsonify({
            'items': perf_items,
            'total': len(perf_items),
            'timestamp': datetime.now(timezone.utc).isoformat()
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'items': [], 'total': 0}), 500

@app.route('/api/feed/perf-history')
def get_perf_history():
    """Time-series CPU% and PLE per SQL Server, bucketed into 5-minute intervals"""
    try:
        hours = float(request.args.get('hours', 1))
        minutes = int(hours * 60)
        conn = get_db_connection()
        cursor = conn.cursor()

        # Each SentryOne timestamp unit = 5 seconds. 60 units = 5 minutes per bucket.
        ts_1h = f"DATEDIFF(SECOND, '20000101', DATEADD(MINUTE, -{minutes}, GETUTCDATE())) / 5"

        # --- CPU history (stored at device level, counter 1858) ---
        cursor.execute(f"""
            SELECT
                ESC.ServerName,
                DATEADD(SECOND, (PAD.Timestamp / 60) * 300, '20000101') AS BucketTime,
                AVG(CAST(PAD.Value AS FLOAT)) AS AvgCPU
            FROM dbo.PerformanceAnalysisData PAD WITH (NOLOCK)
            JOIN dbo.EventSourceConnection ESC WITH (NOLOCK)
                ON ESC.DeviceID = PAD.DeviceID AND ESC.IsWatched = 1
                AND ESC.ServerName IS NOT NULL AND ESC.ServerName != ''
            WHERE PAD.PerformanceAnalysisCounterID = 1858
              AND PAD.Timestamp >= {ts_1h}
            GROUP BY ESC.ServerName, PAD.Timestamp / 60
            ORDER BY ESC.ServerName, BucketTime
        """)
        cpu_rows = cursor.fetchall()

        # --- PLE history (stored at ESC level via virtual counter) ---
        cursor.execute(f"""
            SELECT
                ESC.ServerName,
                DATEADD(SECOND, (PAD.Timestamp / 60) * 300, '20000101') AS BucketTime,
                AVG(CAST(PAD.Value AS FLOAT)) AS AvgPLE
            FROM dbo.PerformanceAnalysisData PAD WITH (NOLOCK)
            JOIN dbo.EventSourceConnection ESC WITH (NOLOCK)
                ON ESC.ID = PAD.EventSourceConnectionID AND ESC.IsWatched = 1
                AND ESC.ServerName IS NOT NULL AND ESC.ServerName != ''
            WHERE PAD.PerformanceAnalysisCounterID IN (
                SELECT PAVC.RawCounterID
                FROM dbo.PerformanceAnalysisVirtualCounter PAVC
                WHERE PAVC.FriendlyCounterName LIKE 'Page life expectancy%'
                  AND PAVC.PerformanceAnalysisCounterCategoryID = (
                      SELECT ID FROM dbo.PerformanceAnalysisCounterCategory
                      WHERE CategoryResourceName = 'SQLSERVER:BUFFER_MANAGER')
            )
              AND PAD.Timestamp >= {ts_1h}
            GROUP BY ESC.ServerName, PAD.Timestamp / 60
            ORDER BY ESC.ServerName, BucketTime
        """)
        ple_rows = cursor.fetchall()
        cursor.close()
        conn.close()

        # Merge into per-server structure
        servers = {}

        for row in cpu_rows:
            sname = row.ServerName
            if isinstance(sname, bytes):
                sname = sname.decode('utf-8', errors='replace')
            if sname not in servers:
                servers[sname] = {'cpu': [], 'ple': []}
            bt = row.BucketTime.isoformat() if row.BucketTime else None
            if bt and row.AvgCPU is not None:
                servers[sname]['cpu'].append({'t': bt, 'v': round(row.AvgCPU, 1)})

        for row in ple_rows:
            sname = row.ServerName
            if isinstance(sname, bytes):
                sname = sname.decode('utf-8', errors='replace')
            if sname not in servers:
                servers[sname] = {'cpu': [], 'ple': []}
            bt = row.BucketTime.isoformat() if row.BucketTime else None
            if bt and row.AvgPLE is not None:
                servers[sname]['ple'].append({'t': bt, 'v': round(row.AvgPLE, 0)})

        return jsonify({'servers': servers})

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'servers': {}}), 500


@app.route('/api/feed/topsql')
def get_top_sql():
    """Get top SQL queries aggregated from PerformanceAnalysisTraceHash"""
    try:
        hours = float(request.args.get('hours', 1))
        limit = int(request.args.get('limit', 25))
        sort = request.args.get('sort', 'cpu')  # cpu, duration, reads, count

        conn = get_db_connection()
        cursor = conn.cursor()

        order_col = {
            'cpu': 'TotCPU',
            'duration': 'TotDuration',
            'reads': 'TotReads',
            'count': 'RecCt'
        }.get(sort, 'TotCPU')

        cursor.execute(f"""
            SELECT TOP (?)
                TH.NormalizedTextData,
                EC.ServerName,
                TopStmts.RecCt,
                TopStmts.TotCPU,
                TopStmts.TotReads,
                TopStmts.TotWrites,
                TopStmts.TotDuration,
                TopStmts.AvgCPU,
                TopStmts.AvgReads,
                TopStmts.AvgWrites,
                TopStmts.AvgDuration,
                TopStmts.MaxDuration,
                TopStmts.MaxCPU,
                TopStmts.MaxReads,
                TopStmts.MinDuration,
                TopStmts.DatabaseName,
                TopStmts.ObjectName
            FROM dbo.PerformanceAnalysisTraceHash TH
            INNER JOIN (
                SELECT
                    EventSourceConnectionID,
                    NormalizedTextMD5,
                    DatabaseName,
                    MAX(ObjectName) AS ObjectName,
                    COUNT(1) AS RecCt,
                    SUM(CAST(CPU AS FLOAT)) AS TotCPU,
                    SUM(CAST(Reads AS FLOAT)) AS TotReads,
                    SUM(CAST(Writes AS FLOAT)) AS TotWrites,
                    SUM(CAST(Duration AS FLOAT)) AS TotDuration,
                    AVG(CAST(CPU AS FLOAT)) AS AvgCPU,
                    AVG(CAST(Reads AS FLOAT)) AS AvgReads,
                    AVG(CAST(Writes AS FLOAT)) AS AvgWrites,
                    AVG(CAST(Duration AS FLOAT)) AS AvgDuration,
                    MAX(Duration) AS MaxDuration,
                    MAX(CPU) AS MaxCPU,
                    MAX(Reads) AS MaxReads,
                    MIN(Duration) AS MinDuration
                FROM dbo.PerformanceAnalysisTraceData
                WHERE StartTime >= DATEADD(MINUTE, -?, GETDATE())
                  AND ApplicationName NOT LIKE 'SQL Sentry%'
                  AND EventClass > 9
                  AND EventClass IN (10, 41, 45)
                GROUP BY EventSourceConnectionID, NormalizedTextMD5, DatabaseName
            ) AS TopStmts ON TH.NormalizedTextMD5 = TopStmts.NormalizedTextMD5
            INNER JOIN dbo.EventSourceConnection EC ON TopStmts.EventSourceConnectionID = EC.ID
            ORDER BY {order_col} DESC
        """, limit, int(hours * 60))

        items = []
        for row in cursor.fetchall():
            text = row.NormalizedTextData or ''
            full_text = text
            if len(text) > 500:
                text = text[:500] + '...'

            obj_name = ''
            if row.ObjectName:
                obj_name = row.ObjectName.decode('utf-8', errors='replace') if isinstance(row.ObjectName, bytes) else str(row.ObjectName)

            items.append({
                'query_text': text,
                'full_text': full_text[:2000] if len(full_text) > 2000 else full_text,
                'object_name': obj_name,
                'server': row.ServerName or 'Unknown',
                'database': row.DatabaseName or 'Unknown',
                'exec_count': row.RecCt or 0,
                'total_cpu': round(row.TotCPU or 0, 0),
                'total_reads': round(row.TotReads or 0, 0),
                'total_writes': round(row.TotWrites or 0, 0),
                'total_duration': round(row.TotDuration or 0, 0),
                'avg_cpu': round(row.AvgCPU or 0, 1),
                'avg_reads': round(row.AvgReads or 0, 0),
                'avg_writes': round(row.AvgWrites or 0, 0),
                'avg_duration': round(row.AvgDuration or 0, 1),
                'max_duration': round(row.MaxDuration or 0, 0),
                'max_cpu': round(row.MaxCPU or 0, 0),
                'max_reads': round(row.MaxReads or 0, 0),
                'min_duration': round(row.MinDuration or 0, 0),
                'type': 'topsql'
            })

        cursor.close()
        conn.close()

        return jsonify({
            'items': items,
            'total': len(items),
            'sort': sort,
            'hours': hours,
            'timestamp': datetime.now(timezone.utc).isoformat()
        })

    except Exception as e:
        return jsonify({'error': str(e), 'items': [], 'total': 0}), 500

@app.route('/api/triage/servers')
def get_triage_servers():
    """Get list of all watched servers for triage configuration"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT ESC.ServerName, D.HostName
            FROM dbo.EventSourceConnection ESC
            LEFT JOIN dbo.Device D ON D.ID = ESC.DeviceID
            WHERE ESC.IsWatched = 1
              AND ESC.ServerName IS NOT NULL AND ESC.ServerName != ''
            ORDER BY ESC.ServerName
        """)
        servers = []
        for row in cursor.fetchall():
            sname = row.ServerName
            if isinstance(sname, bytes): sname = sname.decode('utf-8', errors='replace')
            hname = row.HostName
            if isinstance(hname, bytes): hname = hname.decode('utf-8', errors='replace')
            servers.append({'server': sname, 'hostname': hname or ''})
        cursor.close()
        conn.close()
        return jsonify({'servers': servers})
    except Exception as e:
        return jsonify({'error': str(e), 'servers': []}), 500


@app.route('/api/triage', methods=['GET', 'POST'])
def run_triage():
    """Run triage health check with configurable criteria across selected servers"""
    try:
        cfg = {}
        if request.method == 'POST' and request.is_json:
            cfg = request.get_json() or {}

        selected_servers = cfg.get('servers', [])          # empty = all servers
        window_minutes   = max(1, int(cfg.get('window_minutes', 5)))
        checks           = cfg.get('checks', {})

        cpu_cfg       = checks.get('cpu', {})
        cpu_enabled   = bool(cpu_cfg.get('enabled', True))
        cpu_threshold = float(cpu_cfg.get('threshold', 50))

        ple_cfg       = checks.get('ple', {})
        ple_enabled   = bool(ple_cfg.get('enabled', True))
        ple_threshold = float(ple_cfg.get('threshold', 300))

        blk_cfg     = checks.get('blocking', {})
        blk_enabled = bool(blk_cfg.get('enabled', True))
        blk_wait_ms = int(blk_cfg.get('wait_seconds', 180)) * 1000

        sql_cfg     = checks.get('top_sql', {})
        sql_enabled = bool(sql_cfg.get('enabled', True))
        sql_sort    = sql_cfg.get('sort_by', 'cpu')        # cpu | reads | duration | writes
        sql_top_n   = max(1, int(sql_cfg.get('top_n', 10)))

        alrt_cfg      = checks.get('alerts', {})
        alrt_enabled  = bool(alrt_cfg.get('enabled', True))
        alrt_severity = alrt_cfg.get('severity', 'all')    # all | warning | critical

        lq_cfg      = checks.get('long_queries', {})
        lq_enabled  = bool(lq_cfg.get('enabled', False))
        lq_min_sec  = max(1, int(lq_cfg.get('min_duration_sec', 5)))
        lq_top_n    = max(1, int(lq_cfg.get('top_n', 10)))

        to_cfg      = checks.get('timeouts', {})
        to_enabled  = bool(to_cfg.get('enabled', False))
        to_top_n    = max(1, int(to_cfg.get('top_n', 20)))

        # ── helpers ──────────────────────────────────────────────────
        def _sf_esc(alias='ESC'):
            """Server filter clause for queries that have ESC alias with ServerName"""
            if not selected_servers: return '', []
            ph = ','.join(['?' for _ in selected_servers])
            return f"AND {alias}.ServerName IN ({ph})", list(selected_servers)

        def _sf_col(col):
            """Server filter clause for a bare column name"""
            if not selected_servers: return '', []
            ph = ','.join(['?' for _ in selected_servers])
            return f"AND {col} IN ({ph})", list(selected_servers)

        def _sf_outer(alias='EC'):
            """Server filter as WHERE clause (for queries with no outer WHERE)"""
            if not selected_servers: return '', []
            ph = ','.join(['?' for _ in selected_servers])
            return f"WHERE {alias}.ServerName IN ({ph})", list(selected_servers)

        # ── 1. CPU / PLE ─────────────────────────────────────────────
        def _query_cpu_ple():
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                ts_filter = f"DATEDIFF(SECOND, '20000101', DATEADD(MINUTE, -{window_minutes}, GETUTCDATE())) / 5"
                sf, sp = _sf_esc('ESC')
                cursor.execute(f"""
                    SELECT
                        ESC.ServerName,
                        D.HostName,
                        (SELECT TOP 1 PAD.Value
                         FROM dbo.PerformanceAnalysisData PAD WITH (NOLOCK)
                         WHERE PAD.EventSourceConnectionID = ESC.ID
                           AND PAD.PerformanceAnalysisCounterID IN (
                               SELECT PAVC.RawCounterID FROM dbo.PerformanceAnalysisVirtualCounter PAVC
                               WHERE PAVC.FriendlyCounterName LIKE 'Page life expectancy%'
                                 AND PAVC.PerformanceAnalysisCounterCategoryID = (
                                     SELECT ID FROM dbo.PerformanceAnalysisCounterCategory
                                     WHERE CategoryResourceName = 'SQLSERVER:BUFFER_MANAGER'))
                           AND PAD.Timestamp >= {ts_filter}
                         ORDER BY PAD.Timestamp DESC) as PLE,
                        (SELECT TOP 1 PAD.Value
                         FROM dbo.PerformanceAnalysisData PAD WITH (NOLOCK)
                         WHERE PAD.DeviceID = ESC.DeviceID
                           AND PAD.PerformanceAnalysisCounterID = 1858
                           AND PAD.Timestamp >= {ts_filter}
                         ORDER BY PAD.Timestamp DESC) as CPUPercent
                    FROM dbo.EventSourceConnection ESC
                    LEFT JOIN dbo.Device D ON D.ID = ESC.DeviceID
                    WHERE ESC.IsWatched = 1
                      AND ESC.ServerName IS NOT NULL AND ESC.ServerName != ''
                      {sf}
                    ORDER BY ESC.ServerName
                """, sp)
                results = []
                for row in cursor.fetchall():
                    sname = row.ServerName
                    if isinstance(sname, bytes): sname = sname.decode('utf-8', errors='replace')
                    hname = row.HostName
                    if isinstance(hname, bytes): hname = hname.decode('utf-8', errors='replace')
                    results.append({
                        'server': sname or 'Unknown',
                        'hostname': hname or '',
                        'ple': int(row.PLE) if row.PLE is not None else None,
                        'cpu_percent': round(row.CPUPercent, 1) if row.CPUPercent is not None else None
                    })
                cursor.close(); conn.close()
                return results
            except Exception as e:
                print(f"Triage CPU/PLE error: {e}")
                return []

        # ── 2. Blocking ──────────────────────────────────────────────
        def _query_blocking():
            if not blk_enabled: return []
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                sf, sp = _sf_esc('ESC')
                params = [window_minutes, blk_wait_ms] + sp
                cursor.execute(f"""
                    SELECT TOP 100
                        BC.ID as ChainID,
                        BCD.SPID,
                        BCD.BlockedBySpid,
                        BCD.DatabaseName,
                        BCD.HostName,
                        BCD.ProgramName,
                        BCD.LoginName,
                        BCD.WaitType,
                        BCD.WaitTime,
                        BC.StartTime,
                        ESC.ServerName
                    FROM dbo.BlockChain BC
                    JOIN dbo.EventSourceConnection ESC ON ESC.ID = BC.EventSourceConnectionID
                    JOIN dbo.BlockChainDetail BCD ON BC.ID = BCD.BlockChainID
                    WHERE BC.StartTime >= DATEADD(MINUTE, -?, GETDATE())
                      AND BCD.WaitTime > ?
                      {sf}
                    ORDER BY BCD.WaitTime DESC
                """, params)
                results = []
                for row in cursor.fetchall():
                    def _s(v, default='Unknown'):
                        if v is None: return default
                        return v.decode('utf-8', errors='replace') if isinstance(v, bytes) else str(v)
                    time_str = row.StartTime.isoformat() + 'Z' if row.StartTime else None
                    results.append({
                        'chain_id': row.ChainID,
                        'spid': row.SPID,
                        'blocking_spid': row.BlockedBySpid or 0,
                        'database': _s(row.DatabaseName),
                        'wait_type': _s(row.WaitType),
                        'wait_time_ms': row.WaitTime or 0,
                        'login': _s(row.LoginName),
                        'host': _s(row.HostName),
                        'program': _s(row.ProgramName),
                        'server': _s(row.ServerName),
                        'time': time_str
                    })
                cursor.close(); conn.close()
                return results
            except Exception as e:
                print(f"Triage blocking error: {e}")
                return []

        # ── 3. Top SQL ───────────────────────────────────────────────
        def _query_topsql():
            if not sql_enabled: return []
            try:
                sort_col_map = {
                    'cpu': 'TotCPU', 'reads': 'TotReads',
                    'duration': 'TotDuration', 'writes': 'TotWrites'
                }
                sort_col = sort_col_map.get(sql_sort, 'TotCPU')
                conn = get_db_connection()
                cursor = conn.cursor()
                outer_where, outer_sp = _sf_outer('EC')
                params = [sql_top_n, window_minutes] + outer_sp
                cursor.execute(f"""
                    SELECT TOP (?)
                        TH.NormalizedTextData,
                        EC.ServerName,
                        TopStmts.RecCt,
                        TopStmts.TotCPU,
                        TopStmts.TotReads,
                        TopStmts.TotWrites,
                        TopStmts.TotDuration,
                        TopStmts.AvgCPU,
                        TopStmts.AvgReads,
                        TopStmts.AvgDuration,
                        TopStmts.MaxDuration,
                        TopStmts.DatabaseName
                    FROM dbo.PerformanceAnalysisTraceHash TH
                    INNER JOIN (
                        SELECT
                            EventSourceConnectionID,
                            NormalizedTextMD5,
                            DatabaseName,
                            COUNT(1) AS RecCt,
                            SUM(CAST(CPU AS FLOAT)) AS TotCPU,
                            SUM(CAST(Reads AS FLOAT)) AS TotReads,
                            SUM(CAST(Writes AS FLOAT)) AS TotWrites,
                            SUM(CAST(Duration AS FLOAT)) AS TotDuration,
                            AVG(CAST(CPU AS FLOAT)) AS AvgCPU,
                            AVG(CAST(Reads AS FLOAT)) AS AvgReads,
                            AVG(CAST(Duration AS FLOAT)) AS AvgDuration,
                            MAX(Duration) AS MaxDuration
                        FROM dbo.PerformanceAnalysisTraceData
                        WHERE StartTime >= DATEADD(MINUTE, -?, GETDATE())
                          AND ApplicationName NOT LIKE 'SQL Sentry%'
                          AND EventClass > 9
                          AND EventClass IN (10, 41, 45)
                        GROUP BY EventSourceConnectionID, NormalizedTextMD5, DatabaseName
                    ) AS TopStmts ON TH.NormalizedTextMD5 = TopStmts.NormalizedTextMD5
                    INNER JOIN dbo.EventSourceConnection EC ON TopStmts.EventSourceConnectionID = EC.ID
                    {outer_where}
                    ORDER BY {sort_col} DESC
                """, params)
                results = []
                for row in cursor.fetchall():
                    text = row.NormalizedTextData or ''
                    if len(text) > 500: text = text[:500] + '...'
                    results.append({
                        'query_text': text,
                        'server': row.ServerName or 'Unknown',
                        'database': row.DatabaseName or 'Unknown',
                        'exec_count': row.RecCt or 0,
                        'total_cpu': round(row.TotCPU or 0, 0),
                        'total_reads': round(row.TotReads or 0, 0),
                        'total_writes': round(row.TotWrites or 0, 0),
                        'total_duration': round(row.TotDuration or 0, 0),
                        'avg_cpu': round(row.AvgCPU or 0, 1),
                        'avg_reads': round(row.AvgReads or 0, 0),
                        'avg_duration': round(row.AvgDuration or 0, 1),
                        'max_duration': round(row.MaxDuration or 0, 0)
                    })
                cursor.close(); conn.close()
                return results
            except Exception as e:
                print(f"Triage top SQL error: {e}")
                return []

        # ── 4. Alerts ────────────────────────────────────────────────
        def _query_alerts():
            if not alrt_enabled: return []
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                sev_clause = ''
                if alrt_severity == 'critical':
                    sev_clause = "AND (LOWER(ConditionTypeName) LIKE '%error%' OR LOWER(ConditionTypeName) LIKE '%fail%' OR LOWER(ConditionTypeName) LIKE '%critical%')"
                elif alrt_severity == 'warning':
                    sev_clause = "AND (LOWER(ConditionTypeName) LIKE '%error%' OR LOWER(ConditionTypeName) LIKE '%fail%' OR LOWER(ConditionTypeName) LIKE '%critical%' OR LOWER(ConditionTypeName) LIKE '%warning%' OR LOWER(ConditionTypeName) LIKE '%high%')"
                sf, sp = _sf_col('ParentObjectName')
                params = [window_minutes] + sp
                cursor.execute(f"""
                    SELECT TOP 50
                        ID, EventStartTime, EventEndTime, ObjectTypeName, ObjectName,
                        ConditionTypeName, ActionTypeName, Message, ParentObjectName, Duration
                    FROM dbo.vwObjectConditionActionHistory
                    WHERE EventStartTime >= DATEADD(MINUTE, -?, GETDATE())
                      AND ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')
                      {sev_clause}
                      {sf}
                    ORDER BY EventStartTime DESC
                """, params)
                results = []
                for row in cursor.fetchall():
                    def safe_str(val):
                        if val is None: return None
                        if isinstance(val, bytes): return val.decode('utf-8', errors='replace')
                        return str(val)
                    cond = safe_str(row.ConditionTypeName) or ''
                    if 'error' in cond.lower() or 'fail' in cond.lower() or 'critical' in cond.lower():
                        severity = 'Critical'
                    elif 'warning' in cond.lower() or 'high' in cond.lower():
                        severity = 'Warning'
                    else:
                        severity = 'Info'
                    time_str = row.EventStartTime.isoformat() + 'Z' if row.EventStartTime else None
                    msg = safe_str(row.Message)
                    if msg and len(msg) > 500: msg = msg[:500] + '...'
                    results.append({
                        'id': f"alert_{row.ID}",
                        'object': safe_str(row.ObjectName) or 'Unknown',
                        'server': safe_str(row.ParentObjectName) or 'Unknown',
                        'severity': severity,
                        'time': time_str,
                        'resolved': bool(row.EventEndTime),
                        'condition_type': safe_str(row.ConditionTypeName),
                        'alert_details': msg
                    })
                cursor.close(); conn.close()
                return results
            except Exception as e:
                print(f"Triage alerts error: {e}")
                return []

        # ── 5. Long-running individual queries ───────────────────────
        def _query_long_queries():
            if not lq_enabled: return []
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                lq_min_ms = lq_min_sec * 1000  # Duration is stored in ms
                sf, sp = _sf_esc('EC')
                params = [lq_top_n, window_minutes, lq_min_ms] + sp
                cursor.execute(f"""
                    SELECT TOP (?)
                        PTD.StartTime,
                        PTD.Duration        AS DurationMs,
                        PTD.CPU,
                        PTD.Reads,
                        PTD.Writes,
                        PTD.DatabaseName,
                        PTD.ObjectName,
                        LEFT(PTD.TextData, 500) AS TextData,
                        PTD.ApplicationName,
                        EC.ServerName
                    FROM dbo.PerformanceAnalysisTraceData PTD WITH (NOLOCK)
                    INNER JOIN dbo.EventSourceConnection EC ON EC.ID = PTD.EventSourceConnectionID
                    WHERE PTD.StartTime >= DATEADD(MINUTE, -?, GETDATE())
                      AND PTD.Duration >= ?
                      AND PTD.ApplicationName NOT LIKE 'SQL Sentry%'
                      AND PTD.EventClass IN (10, 41, 45)
                      {sf}
                    ORDER BY PTD.Duration DESC
                """, params)
                results = []
                for row in cursor.fetchall():
                    def _s(v, default=''):
                        if v is None: return default
                        return v.decode('utf-8', errors='replace') if isinstance(v, bytes) else str(v)
                    results.append({
                        'server': _s(row.ServerName, 'Unknown'),
                        'database': _s(row.DatabaseName, 'Unknown'),
                        'object': _s(row.ObjectName),
                        'duration_ms': row.DurationMs or 0,
                        'cpu_ms': row.CPU or 0,
                        'reads': row.Reads or 0,
                        'writes': row.Writes or 0,
                        'start_time': row.StartTime.isoformat() + 'Z' if row.StartTime else None,
                        'application': _s(row.ApplicationName),
                        'query_text': _s(row.TextData)
                    })
                cursor.close(); conn.close()
                return results
            except Exception as e:
                print(f"Triage long queries error: {e}", flush=True)
                return []

        # ── 6. Query timeouts ────────────────────────────────────────
        def _query_timeouts():
            if not to_enabled: return []
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                sf, sp = _sf_col('ParentObjectName')
                params = [to_top_n, window_minutes] + sp
                cursor.execute(f"""
                    SELECT TOP (?)
                        ID, EventStartTime, ObjectName, ParentObjectName,
                        ConditionTypeName, Message, Duration
                    FROM dbo.vwObjectConditionActionHistory
                    WHERE EventStartTime >= DATEADD(MINUTE, -?, GETDATE())
                      AND ActionTypeName NOT IN ('Log To Database','Send to Alerting Channels')
                      AND (
                          LOWER(ConditionTypeName) LIKE '%timeout%'
                          OR LOWER(Message)         LIKE '%timeout%'
                          OR LOWER(ConditionTypeName) LIKE '%timed out%'
                          OR LOWER(Message)           LIKE '%timed out%'
                          OR LOWER(ConditionTypeName) LIKE '%query timeout%'
                          OR LOWER(ConditionTypeName) LIKE '%execution timeout%'
                          OR LOWER(ConditionTypeName) LIKE '%attention%'
                      )
                      {sf}
                    ORDER BY EventStartTime DESC
                """, params)
                results = []
                for row in cursor.fetchall():
                    def safe_str(v):
                        if v is None: return ''
                        return v.decode('utf-8', errors='replace') if isinstance(v, bytes) else str(v)
                    duration_sec = round(row.Duration / 10000000, 1) if row.Duration else None
                    msg = safe_str(row.Message)
                    if len(msg) > 300: msg = msg[:300] + '...'
                    results.append({
                        'server':    safe_str(row.ParentObjectName) or 'Unknown',
                        'object':    safe_str(row.ObjectName) or '',
                        'condition': safe_str(row.ConditionTypeName) or '',
                        'message':   msg,
                        'time':      row.EventStartTime.isoformat() + 'Z' if row.EventStartTime else None,
                        'duration_sec': duration_sec
                    })
                cursor.close(); conn.close()
                return results
            except Exception as e:
                print(f"Triage timeouts error: {e}", flush=True)
                return []

        # ── Run all checks in parallel ───────────────────────────────
        with ThreadPoolExecutor(max_workers=6) as executor:
            fut_cpu   = executor.submit(_query_cpu_ple)
            fut_block = executor.submit(_query_blocking)
            fut_sql   = executor.submit(_query_topsql)
            fut_alrt  = executor.submit(_query_alerts)
            fut_lq    = executor.submit(_query_long_queries)
            fut_to    = executor.submit(_query_timeouts)

        perf_data     = fut_cpu.result()
        blocking_data = fut_block.result()
        topsql_data   = fut_sql.result()
        alerts_data   = fut_alrt.result()
        longq_data    = fut_lq.result()
        timeout_data  = fut_to.result()

        cpu_issues = [s for s in perf_data if cpu_enabled and s.get('cpu_percent') is not None and s['cpu_percent'] > cpu_threshold]
        ple_issues = [s for s in perf_data if ple_enabled and s.get('ple') is not None and s['ple'] < ple_threshold]

        has_critical = bool(cpu_issues or ple_issues or blocking_data or timeout_data)
        has_warnings = bool(alerts_data)
        overall = 'critical' if has_critical else ('warning' if has_warnings else 'healthy')

        return jsonify({
            'cpu_issues': cpu_issues,
            'ple_issues': ple_issues,
            'blocking_issues': blocking_data,
            'heavy_queries': topsql_data,
            'active_alerts': alerts_data,
            'long_queries': longq_data,
            'timeouts': timeout_data,
            'all_servers': perf_data,
            'summary': {
                'total_servers': len(perf_data),
                'cpu_issue_count': len(cpu_issues),
                'ple_issue_count': len(ple_issues),
                'blocking_issue_count': len(blocking_data),
                'heavy_query_count': len(topsql_data),
                'active_alert_count': len(alerts_data),
                'long_query_count': len(longq_data),
                'timeout_count': len(timeout_data),
                'status': overall
            },
            'config': {
                'cpu_threshold': cpu_threshold,
                'ple_threshold': ple_threshold,
                'blk_wait_seconds': blk_wait_ms // 1000,
                'sql_sort': sql_sort,
                'alrt_severity': alrt_severity,
                'lq_min_sec': lq_min_sec,
                'lq_enabled': lq_enabled,
                'to_enabled': to_enabled
            },
            'window_minutes': window_minutes,
            'timestamp': datetime.now(timezone.utc).isoformat()
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'summary': {'status': 'error'}}), 500


def _get_mock_pagerduty():
    """Generate realistic mock PagerDuty incidents for demo mode"""
    services = ['Payment Gateway', 'Auth Service', 'Database Cluster', 'API Gateway', 'Web Frontend', 'Batch Processor']
    urgencies = ['high', 'low']
    statuses = ['triggered', 'acknowledged', 'resolved']
    titles = [
        'High CPU usage on production server',
        'Database connection pool exhausted',
        'Payment processing latency > 5s',
        'SSL certificate expiring in 7 days',
        'Memory utilization above 90%',
        'Failed health check on API Gateway',
        'Disk space below 10% on DB server',
        'Error rate spike on /api/transactions',
        'Replication lag > 30 seconds',
        'Service degradation detected',
        'Unresponsive node in cluster',
        'Queue depth exceeding threshold',
    ]
    incidents = []
    now = datetime.now(timezone.utc)
    for i in range(random.randint(5, 12)):
        status = random.choice(statuses)
        urgency = random.choice(urgencies)
        created = now - timedelta(minutes=random.randint(1, 120))
        incidents.append({
            'id': f'PD-MOCK-{random.randint(10000, 99999)}',
            'incident_number': random.randint(1000, 9999),
            'title': random.choice(titles),
            'status': status,
            'urgency': urgency,
            'service': random.choice(services),
            'created_at': created.isoformat(),
            'updated_at': (created + timedelta(minutes=random.randint(0, 30))).isoformat(),
            'assignments': [f'user{random.randint(1,5)}@payroc.com'],
            'escalation_policy': 'Default',
            'acknowledged_at': (created + timedelta(minutes=random.randint(1, 15))).isoformat() if status != 'triggered' else '',
            'type': 'pagerduty'
        })
    incidents.sort(key=lambda x: x['created_at'], reverse=True)
    return incidents

def _get_live_pagerduty():
    """Fetch real PagerDuty incidents via REST API v2"""
    headers = {
        'Authorization': f'Token token={PD_API_KEY}',
        'Content-Type': 'application/json',
        'Accept': 'application/vnd.pagerduty+json;version=2'
    }
    params = {
        'sort_by': 'created_at:desc',
        'limit': 50,
        'statuses[]': ['triggered', 'acknowledged']
    }
    try:
        resp = requests.get(f'{PD_API_HOST}/incidents', headers=headers, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        items = []
        for inc in data.get('incidents', []):
            items.append({
                'id': inc.get('id', ''),
                'incident_number': inc.get('incident_number', 0),
                'title': inc.get('title', ''),
                'status': inc.get('status', 'unknown'),
                'urgency': inc.get('urgency', 'low'),
                'service': inc.get('service', {}).get('summary', 'Unknown'),
                'created_at': inc.get('created_at', ''),
                'updated_at': inc.get('updated_at', ''),
                'assignments': [a.get('assignee', {}).get('summary', '') for a in inc.get('assignments', [])],
                'escalation_policy': inc.get('escalation_policy', {}).get('summary', 'Unknown'),
                'acknowledged_at': inc.get('last_status_change_on', '') if inc.get('status') in ('acknowledged', 'resolved') else '',
                'type': 'pagerduty'
            })
        return items
    except Exception as e:
        print(f"PagerDuty API error: {e}")
        return []

def _get_mock_pagerduty_history(days=30):
    """Generate realistic mock PagerDuty incidents spread over N days"""
    services = ['Payment Gateway', 'Auth Service', 'Database Cluster', 'API Gateway', 'Web Frontend', 'Batch Processor']
    urgencies = ['high', 'low']
    statuses_weights = ['resolved'] * 65 + ['acknowledged'] * 20 + ['triggered'] * 15
    titles = [
        'High CPU usage on production server',
        'Database connection pool exhausted',
        'Payment processing latency > 5s',
        'SSL certificate expiring in 7 days',
        'Memory utilization above 90%',
        'Failed health check on API Gateway',
        'Disk space below 10% on DB server',
        'Error rate spike on /api/transactions',
        'Replication lag > 30 seconds',
        'Service degradation detected',
        'Unresponsive node in cluster',
        'Queue depth exceeding threshold',
    ]
    policies = ['Default', 'Database Team', 'Infrastructure', 'Application Support']
    incidents = []
    now = datetime.now(timezone.utc)
    for day_offset in range(days):
        date = now - timedelta(days=day_offset)
        count = random.randint(0, 3)
        if random.random() < 0.1:
            count = random.randint(6, 12)
        for _ in range(count):
            status = random.choice(statuses_weights)
            created = date.replace(hour=random.randint(6, 22), minute=random.randint(0, 59), second=random.randint(0, 59))
            incidents.append({
                'id': f'PD-MOCK-{random.randint(10000, 99999)}',
                'incident_number': random.randint(1000, 9999),
                'title': random.choice(titles),
                'status': status,
                'urgency': random.choice(urgencies),
                'service': random.choice(services),
                'created_at': created.isoformat(),
                'updated_at': (created + timedelta(minutes=random.randint(5, 180))).isoformat(),
                'assignments': [random.choice(['John Smith', 'Sarah Johnson', 'Mike Chen', 'Emily Davis', 'Alex Kumar'])],
                'escalation_policy': random.choice(policies),
                'acknowledged_at': (created + timedelta(minutes=random.randint(1, 30))).isoformat() if status != 'triggered' else '',
                'type': 'pagerduty'
            })
    incidents.sort(key=lambda x: x['created_at'], reverse=True)
    return incidents


def _get_live_pagerduty_history(days=30):
    """Fetch historical PagerDuty incidents with pagination (all statuses)"""
    headers = {
        'Authorization': f'Token token={PD_API_KEY}',
        'Content-Type': 'application/json',
        'Accept': 'application/vnd.pagerduty+json;version=2'
    }
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    until = datetime.now(timezone.utc).isoformat()
    all_items = []
    offset = 0
    limit = 100

    while True:
        params = {
            'since': since,
            'until': until,
            'sort_by': 'created_at:desc',
            'limit': limit,
            'offset': offset,
            'statuses[]': ['triggered', 'acknowledged', 'resolved']
        }
        try:
            resp = requests.get(f'{PD_API_HOST}/incidents', headers=headers, params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
            for inc in data.get('incidents', []):
                all_items.append({
                    'id': inc.get('id', ''),
                    'incident_number': inc.get('incident_number', 0),
                    'title': inc.get('title', ''),
                    'status': inc.get('status', 'unknown'),
                    'urgency': inc.get('urgency', 'low'),
                    'service': inc.get('service', {}).get('summary', 'Unknown'),
                    'created_at': inc.get('created_at', ''),
                    'updated_at': inc.get('updated_at', ''),
                    'assignments': [a.get('assignee', {}).get('summary', '') for a in inc.get('assignments', [])],
                    'escalation_policy': inc.get('escalation_policy', {}).get('summary', 'Unknown'),
                    'acknowledged_at': inc.get('last_status_change_on', '') if inc.get('status') in ('acknowledged', 'resolved') else '',
                    'type': 'pagerduty'
                })
            if not data.get('more', False):
                break
            offset += limit
            if offset > 1000:
                break
        except Exception as e:
            print(f"PagerDuty history API error: {e}")
            break

    return all_items


@app.route('/api/feed/pagerduty/history')
def get_pagerduty_history():
    """Get 30-day PagerDuty incident history aggregated by day and service"""
    try:
        days = int(request.args.get('days', 120))
        days = min(days, 120)

        if PD_API_KEY and PD_API_KEY != 'REPLACE_ME':
            items = _get_live_pagerduty_history(days)
            mode = 'live'
        else:
            items = _get_mock_pagerduty_history(days)
            mode = 'mock'

        # Aggregate by date
        day_counts = {}
        services = set()
        for item in items:
            created = item.get('created_at', '')
            if created:
                try:
                    dt = datetime.fromisoformat(created.replace('Z', '+00:00'))
                    day_key = dt.strftime('%Y-%m-%d')
                    day_counts[day_key] = day_counts.get(day_key, 0) + 1
                except:
                    pass
            services.add(item.get('service', 'Unknown'))

        return jsonify({
            'heatmap': day_counts,
            'services': sorted(services),
            'items': items,
            'total_incidents': len(items),
            'mode': mode,
            'days': days,
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e), 'heatmap': {}, 'services': [], 'items': [], 'mode': 'error'}), 500


@app.route('/api/feed/pagerduty/oncall')
def get_pagerduty_oncall():
    """Fetch current on-call schedules from PagerDuty"""
    try:
        if not PD_API_KEY or PD_API_KEY == 'REPLACE_ME':
            return jsonify({'error': 'PagerDuty API key not configured', 'oncalls': [], 'schedules': []})

        headers = {
            'Authorization': f'Token token={PD_API_KEY}',
            'Content-Type': 'application/json',
            'Accept': 'application/vnd.pagerduty+json;version=2'
        }

        # Fetch current on-call entries
        resp = requests.get(
            f'{PD_API_HOST}/oncalls',
            headers=headers,
            params={'include[]': ['users', 'schedules', 'escalation_policies'], 'limit': 100},
            timeout=15
        )
        resp.raise_for_status()
        raw_oncalls = resp.json().get('oncalls', [])

        # Fetch schedules list for overview
        resp2 = requests.get(
            f'{PD_API_HOST}/schedules',
            headers=headers,
            params={'limit': 50},
            timeout=15
        )
        resp2.raise_for_status()
        raw_schedules = resp2.json().get('schedules', [])

        oncalls = []
        for o in raw_oncalls:
            user = o.get('user') or {}
            schedule = o.get('schedule') or {}
            policy = o.get('escalation_policy') or {}
            oncalls.append({
                'escalation_level': o.get('escalation_level', 1),
                'start': o.get('start', ''),
                'end':   o.get('end', ''),
                'user': {
                    'name':        user.get('name', 'Unknown'),
                    'email':       user.get('email', ''),
                    'avatar_url':  user.get('avatar_url', ''),
                    'id':          user.get('id', '')
                },
                'schedule': {
                    'name': schedule.get('name', 'No Schedule'),
                    'id':   schedule.get('id', '')
                },
                'policy': {
                    'name': policy.get('name', ''),
                    'id':   policy.get('id', '')
                }
            })

        schedules = [{
            'id':          s.get('id', ''),
            'name':        s.get('name', ''),
            'description': s.get('description', ''),
            'timezone':    s.get('time_zone', ''),
            'teams':       [t.get('summary', '') for t in (s.get('teams') or [])]
        } for s in raw_schedules]

        return jsonify({'oncalls': oncalls, 'schedules': schedules, 'total': len(oncalls)})

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'oncalls': [], 'schedules': []}), 500


@app.route('/api/feed/pagerduty')
def get_pagerduty_feed():
    """Get PagerDuty incidents - real API or mock data"""
    try:
        hours = float(request.args.get('hours', 1))
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=int(hours * 3600))
        if PD_API_KEY and PD_API_KEY != 'REPLACE_ME':
            items = _get_live_pagerduty()
            mode = 'live'
        else:
            items = _get_mock_pagerduty()
            mode = 'mock'
        # Filter by time range
        filtered = []
        for item in items:
            t = item.get('created_at', '')
            if t:
                try:
                    dt = datetime.fromisoformat(t.replace('Z', '+00:00'))
                    if dt >= cutoff:
                        filtered.append(item)
                except:
                    filtered.append(item)
            else:
                filtered.append(item)
        items = filtered
        
        return jsonify({
            'items': items,
            'total': len(items),
            'mode': mode,
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e), 'items': [], 'mode': 'error'}), 500

@app.route('/api/feed/disk')
def get_disk_usage():
    """Get SQL file disk utilization per server/database"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Discover which tables exist
        cursor.execute("""
            SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_NAME IN (
                'Device','PerformanceAnalysisDeviceLogicalDisk',
                'PerformanceAnalysisSqlFile','PerformanceAnalysisSqlDatabase',
                'EventSourceConnection','PerformanceAnalysisData'
            )
        """)
        available = {r.TABLE_NAME for r in cursor.fetchall()}

        required = {'Device','PerformanceAnalysisSqlFile','PerformanceAnalysisSqlDatabase',
                     'EventSourceConnection','PerformanceAnalysisData'}
        if not required.issubset(available):
            missing = required - available
            return jsonify({'error': f'Missing tables: {missing}', 'items': []}), 500

        has_disk = 'PerformanceAnalysisDeviceLogicalDisk' in available

        # Discover Device columns
        cursor.execute("SELECT TOP 0 * FROM dbo.Device")
        dev_cols = {d[0] for d in cursor.description}

        # Build device name expression
        if 'FullyQualifiedDomainName' in dev_cols and 'HostName' in dev_cols:
            dev_name = "COALESCE(D.FullyQualifiedDomainName, D.HostName, D.IPAddress)"
        elif 'HostName' in dev_cols:
            dev_name = "COALESCE(D.HostName, D.IPAddress)"
        else:
            dev_name = "D.IPAddress"

        # Step 1: Get file metadata (server, database, file, disk)
        disk_join = ""
        disk_col = "'N/A' as DiskName"
        if has_disk:
            disk_join = """LEFT JOIN dbo.PerformanceAnalysisDeviceLogicalDisk LD
                           ON SF.FileName LIKE LD.Name + '%' AND ESC.DeviceID = LD.DeviceID"""
            disk_col = "COALESCE(LD.Name, 'N/A') as DiskName"

        file_query = f"""
            SELECT
                ESC.DeviceID,
                {dev_name} as DeviceName,
                ESC.ID as ESCID,
                ESC.ServerName,
                ESC.ObjectName as InstanceName,
                DB.Name as DatabaseName,
                SF.DatabaseID,
                SF.FileID,
                SF.Name as LogicalFileName,
                SF.FileName as PhysicalFileName,
                {disk_col}
            FROM dbo.PerformanceAnalysisSqlFile SF
            JOIN dbo.PerformanceAnalysisSqlDatabase DB
                ON DB.DatabaseID = SF.DatabaseID
                AND DB.EventSourceConnectionID = SF.EventSourceConnectionID
            JOIN dbo.EventSourceConnection ESC ON ESC.ID = SF.EventSourceConnectionID
            JOIN dbo.Device D ON D.ID = ESC.DeviceID
            {disk_join}
            WHERE ESC.ServerName IS NOT NULL AND ESC.ServerName != ''
            ORDER BY ESC.ServerName, DB.Name, SF.Name
        """
        cursor.execute(file_query)
        file_cols = {d[0] for d in cursor.description}

        files = {}
        for row in cursor.fetchall():
            key = f"{row.ESCID},{row.DatabaseID},{row.FileID}"
            sname = row.ServerName
            if isinstance(sname, bytes):
                sname = sname.decode('utf-8', errors='replace')
            oname = row.InstanceName
            if isinstance(oname, bytes):
                oname = oname.decode('utf-8', errors='replace')
            dbname = row.DatabaseName
            if isinstance(dbname, bytes):
                dbname = dbname.decode('utf-8', errors='replace')
            lname = row.LogicalFileName
            if isinstance(lname, bytes):
                lname = lname.decode('utf-8', errors='replace')
            pname = row.PhysicalFileName
            if isinstance(pname, bytes):
                pname = pname.decode('utf-8', errors='replace')
            dname = row.DiskName
            if isinstance(dname, bytes):
                dname = dname.decode('utf-8', errors='replace')
            dv = row.DeviceName
            if isinstance(dv, bytes):
                dv = dv.decode('utf-8', errors='replace')

            files[key] = {
                'device_id': row.DeviceID,
                'device_name': dv or 'Unknown',
                'esc_id': row.ESCID,
                'server': sname or 'Unknown',
                'instance': oname or sname or 'Unknown',
                'database': dbname or 'Unknown',
                'database_id': row.DatabaseID,
                'file_id': row.FileID,
                'logical_name': lname or 'Unknown',
                'physical_file': pname or 'Unknown',
                'disk': dname or 'N/A',
                'total_size_mb': None,
                'used_size_mb': None,
                'is_data_file': None
            }

        # Step 2: Get latest file sizes from PerformanceAnalysisData
        # Counters: 251=data total, 252=data used, 253=log total, 254=log used
        # Timestamp = seconds/5 since 2000-01-01
        try:
            cursor.execute("""
                SELECT PAD.DeviceID, PAD.EventSourceConnectionID, PAD.InstanceName,
                       PAD.PerformanceAnalysisCounterID, PAD.Value
                FROM dbo.PerformanceAnalysisData PAD WITH (NOLOCK)
                INNER JOIN (
                    SELECT DeviceID, EventSourceConnectionID, InstanceName,
                           PerformanceAnalysisCounterID, MAX(Timestamp) as MaxTS
                    FROM dbo.PerformanceAnalysisData WITH (NOLOCK)
                    WHERE PerformanceAnalysisCounterID IN (251, 252, 253, 254)
                      AND Timestamp >= DATEDIFF(SECOND, '20000101 00:00:00', DATEADD(DAY, -1, GETDATE())) / 5
                    GROUP BY DeviceID, EventSourceConnectionID, InstanceName, PerformanceAnalysisCounterID
                ) Latest ON PAD.DeviceID = Latest.DeviceID
                    AND PAD.EventSourceConnectionID = Latest.EventSourceConnectionID
                    AND PAD.InstanceName = Latest.InstanceName
                    AND PAD.PerformanceAnalysisCounterID = Latest.PerformanceAnalysisCounterID
                    AND PAD.Timestamp = Latest.MaxTS
            """)

            for row in cursor.fetchall():
                iname = row.InstanceName
                if isinstance(iname, bytes):
                    iname = iname.decode('utf-8', errors='replace')
                key = str(iname) if iname else ''
                counter = row.PerformanceAnalysisCounterID
                val = row.Value or 0

                if key in files:
                    if counter in (251, 253):  # total size
                        files[key]['total_size_mb'] = round(val, 2)
                        files[key]['is_data_file'] = (counter == 251)
                    elif counter in (252, 254):  # used size
                        files[key]['used_size_mb'] = round(val, 2)
        except Exception as e:
            print(f"[DISK] PerformanceAnalysisData query failed: {e}")
            traceback.print_exc()

        cursor.close()
        conn.close()

        # Step 3: Aggregate by server → database → files
        servers = {}
        for key, f in files.items():
            srv = f['server']
            if srv not in servers:
                servers[srv] = {
                    'server': srv,
                    'instance': f['instance'],
                    'device_name': f['device_name'],
                    'databases': {},
                    'total_size_mb': 0,
                    'used_size_mb': 0,
                    'file_count': 0
                }
            db = f['database']
            if db not in servers[srv]['databases']:
                servers[srv]['databases'][db] = {
                    'database': db,
                    'disk': f['disk'],
                    'files': [],
                    'total_size_mb': 0,
                    'used_size_mb': 0
                }

            total = f['total_size_mb'] or 0
            used = f['used_size_mb'] or 0
            free = round(total - used, 2) if total and used else None

            file_info = {
                'logical_name': f['logical_name'],
                'physical_file': f['physical_file'],
                'disk': f['disk'],
                'total_size_mb': total,
                'used_size_mb': used,
                'free_mb': free,
                'pct_used': round((used / total) * 100, 1) if total > 0 else None,
                'is_data_file': f['is_data_file']
            }
            servers[srv]['databases'][db]['files'].append(file_info)
            servers[srv]['databases'][db]['total_size_mb'] += total
            servers[srv]['databases'][db]['used_size_mb'] += used
            servers[srv]['total_size_mb'] += total
            servers[srv]['used_size_mb'] += used
            servers[srv]['file_count'] += 1

        # Convert to list
        items = []
        for srv_name, srv in sorted(servers.items()):
            db_list = []
            for db_name, db in sorted(srv['databases'].items()):
                db['total_size_mb'] = round(db['total_size_mb'], 2)
                db['used_size_mb'] = round(db['used_size_mb'], 2)
                db['free_mb'] = round(db['total_size_mb'] - db['used_size_mb'], 2)
                db['pct_used'] = round((db['used_size_mb'] / db['total_size_mb']) * 100, 1) if db['total_size_mb'] > 0 else None
                db_list.append(db)

            items.append({
                'server': srv['server'],
                'instance': srv['instance'],
                'device_name': srv['device_name'],
                'total_size_mb': round(srv['total_size_mb'], 2),
                'used_size_mb': round(srv['used_size_mb'], 2),
                'free_mb': round(srv['total_size_mb'] - srv['used_size_mb'], 2),
                'pct_used': round((srv['used_size_mb'] / srv['total_size_mb']) * 100, 1) if srv['total_size_mb'] > 0 else None,
                'file_count': srv['file_count'],
                'database_count': len(db_list),
                'databases': db_list,
                'type': 'disk'
            })

        return jsonify({
            'items': items,
            'total': len(items),
            'total_size_mb': round(sum(i['total_size_mb'] for i in items), 2),
            'total_used_mb': round(sum(i['used_size_mb'] for i in items), 2),
            'timestamp': datetime.now(timezone.utc).isoformat()
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'items': []}), 500

@app.route('/api/prtg/coverage')
def get_prtg_coverage():
    """Fetch PRTG device and sensor coverage data"""
    try:
        import urllib.parse

        def prtg_api(path, params):
            params['username'] = PRTG_USERNAME
            params['passhash'] = PRTG_PASSHASH
            query = '&'.join(f"{k}={urllib.parse.quote(str(v))}" for k, v in params.items())
            url = f"{PRTG_SERVER}{path}?{query}"
            resp = requests.get(url, verify=False, timeout=30)
            resp.raise_for_status()
            return resp.json()

        # Fetch devices
        dev_data = prtg_api('/api/table.json', {
            'content': 'devices',
            'columns': 'objid,parentid,name,probe,group,device,statustext,active',
            'count': '50000',
            'output': 'json'
        })
        devices = dev_data.get('devices', [])

        # Fetch sensors
        sen_data = prtg_api('/api/table.json', {
            'content': 'sensors',
            'columns': 'objid,parentid,name,statustext,type,active',
            'count': '50000',
            'output': 'json'
        })
        sensors = sen_data.get('sensors', [])

        # Group sensors by parent device id
        sensors_by_device = {}
        for s in sensors:
            pid = str(s.get('parentid', ''))
            sensors_by_device.setdefault(pid, []).append(s)

        paused_texts = {'Paused by User', 'Paused by Dependency', 'Paused by Schedule', 'Paused Until', 'Paused'}
        alarm_texts  = {'Down', 'Warning', 'Down (Acknowledged)'}

        results = []
        gap_count = 0

        for dev in devices:
            dev_id = str(dev.get('objid', ''))
            dev_sensors = sensors_by_device.get(dev_id, [])

            total   = len(dev_sensors)
            active  = sum(1 for s in dev_sensors if str(s.get('active', '')) in ('1', 'True', 'true'))
            paused  = sum(1 for s in dev_sensors if s.get('statustext', '') in paused_texts)
            alarm   = sum(1 for s in dev_sensors if s.get('statustext', '') in alarm_texts)

            has_ping   = any('ping' in s.get('name','').lower() or 'icmp' in s.get('name','').lower() or 'ping' in s.get('type','').lower() for s in dev_sensors)
            has_disk   = any('disk' in s.get('name','').lower() or 'free' in s.get('name','').lower() or 'disk' in s.get('type','').lower() for s in dev_sensors)
            has_cpu    = any('cpu' in s.get('name','').lower() or 'load' in s.get('name','').lower() or 'cpu' in s.get('type','').lower() for s in dev_sensors)
            has_memory = any('mem' in s.get('name','').lower() or 'mem' in s.get('type','').lower() for s in dev_sensors)

            coverage_gap = total < 3 or not has_ping or not has_disk or not has_cpu or not has_memory
            if coverage_gap:
                gap_count += 1

            results.append({
                'id':           dev_id,
                'name':         dev.get('device') or dev.get('name', ''),
                'probe':        dev.get('probe', ''),
                'group':        dev.get('group', ''),
                'status':       dev.get('statustext', ''),
                'active':       dev.get('active', ''),
                'totalSensors': total,
                'active_sensors': active,
                'pausedSensors': paused,
                'alarmSensors':  alarm,
                'hasPing':    has_ping,
                'hasDisk':    has_disk,
                'hasCpu':     has_cpu,
                'hasMemory':  has_memory,
                'coverageGap': coverage_gap
            })

        return jsonify({
            'items':       results,
            'total':       len(results),
            'gap_count':   gap_count,
            'sensor_count': len(sensors)
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'items': [], 'total': 0, 'gap_count': 0}), 500


@app.route('/api/prtg/sensors')
def get_prtg_sensors():
    """Fetch per-device sensor details from PRTG: CPU, Disk, Memory, SQL services, Ping"""
    try:
        import urllib.parse

        def prtg_api(path, params):
            params['username'] = PRTG_USERNAME
            params['passhash'] = PRTG_PASSHASH
            query = '&'.join(f"{k}={urllib.parse.quote(str(v))}" for k, v in params.items())
            url = f"{PRTG_SERVER}{path}?{query}"
            resp = requests.get(url, verify=False, timeout=30)
            resp.raise_for_status()
            return resp.json()

        # Fetch devices
        dev_data = prtg_api('/api/table.json', {
            'content': 'devices',
            'columns': 'objid,name,device,probe,group,statustext,active',
            'count': '50000',
            'output': 'json'
        })
        # Filter to MSSQL group only
        devices = {
            str(d.get('objid', '')): d
            for d in dev_data.get('devices', [])
            if 'mssql' in d.get('group', '').lower()
        }

        # Fetch sensors with last values
        sen_data = prtg_api('/api/table.json', {
            'content': 'sensors',
            'columns': 'objid,parentid,name,statustext,type,active,lastvalue,lastvalue_raw,device',
            'count': '50000',
            'output': 'json'
        })
        sensors = sen_data.get('sensors', [])

        def classify(s):
            n = s.get('name', '').lower()
            t = s.get('type', '').lower()
            if any(x in n for x in ('ping', 'icmp')) or 'ping' in t:
                return 'ping'
            if any(x in n for x in ('cpu', 'processor', 'cpu load')) or 'cpu' in t:
                return 'cpu'
            if any(x in n for x in ('memory', ' mem ', 'ram', 'physical memory')) or 'mem' in t:
                return 'memory'
            if any(x in n for x in ('disk', 'free space', 'volume', 'drive', 'logical disk')) or 'disk' in t:
                return 'disk'
            if any(x in n for x in ('sql server', 'mssql', 'sql service', 'sql agent', 'sqlserver')) \
               or any(x in t for x in ('winsvc', 'sql')):
                return 'sql_service'
            return 'other'

        # Group sensors by device
        by_device = {}
        for s in sensors:
            pid = str(s.get('parentid', ''))
            by_device.setdefault(pid, []).append(s)

        results = []
        for dev_id, dev in devices.items():
            dev_sensors = by_device.get(dev_id, [])
            categorised = {'cpu': [], 'disk': [], 'memory': [], 'ping': [], 'sql_service': [], 'other': []}
            for s in dev_sensors:
                cat = classify(s)
                categorised[cat].append({
                    'id':        s.get('objid', ''),
                    'name':      s.get('name', ''),
                    'status':    s.get('statustext', ''),
                    'value':     s.get('lastvalue', '—'),
                    'value_raw': s.get('lastvalue_raw', None),
                    'active':    s.get('active', '1')
                })

            results.append({
                'id':     dev_id,
                'name':   dev.get('device') or dev.get('name', ''),
                'probe':  dev.get('probe', ''),
                'group':  dev.get('group', ''),
                'status': dev.get('statustext', ''),
                'sensors': categorised,
                'total':   len(dev_sensors)
            })

        results.sort(key=lambda x: x['name'].lower())
        return jsonify({'devices': results, 'total': len(results)})

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'devices': [], 'total': 0}), 500


@app.route('/api/prtg/history')
def get_prtg_sensor_history():
    """Return 24h historical data for a list of PRTG sensor IDs"""
    try:
        import urllib.parse

        sensor_ids = request.args.getlist('id')  # multiple ?id=xxx&id=yyy
        hours = int(request.args.get('hours', 24))

        if not sensor_ids:
            return jsonify({'error': 'No sensor IDs provided', 'series': {}})

        now = datetime.now()
        start = now - timedelta(hours=hours)
        sdate = start.strftime('%Y-%m-%d-%H-%M-%S')
        edate = now.strftime('%Y-%m-%d-%H-%M-%S')

        def prtg_history(sensor_id):
            params = {
                'id':       sensor_id,
                'avg':      '3600',  # 1-hour averages for 24h view
                'sdate':    sdate,
                'edate':    edate,
                'username': PRTG_USERNAME,
                'passhash': PRTG_PASSHASH,
                'output':   'json'
            }
            query = '&'.join(f"{k}={urllib.parse.quote(str(v))}" for k, v in params.items())
            url = f"{PRTG_SERVER}/api/historicdata.json?{query}"
            resp = requests.get(url, verify=False, timeout=30)
            resp.raise_for_status()
            return resp.json()

        import re

        def parse_prtg_dt(dt_str):
            """Convert PRTG datetime string to ISO 8601 for Chart.js"""
            # Strip timezone suffix e.g. " [GMT+1]"
            dt_str = re.sub(r'\s*\[.*?\]', '', dt_str).strip()
            for fmt in ('%d.%m.%Y %H:%M:%S', '%m/%d/%Y %H:%M:%S', '%Y-%m-%d %H:%M:%S'):
                try:
                    return datetime.strptime(dt_str, fmt).isoformat()
                except ValueError:
                    pass
            return dt_str  # fallback: return as-is

        series = {}
        for sid in sensor_ids:
            try:
                raw = prtg_history(sid)
                points = []
                for entry in raw.get('histdata', []):
                    dt_raw = entry.get('datetime', '')
                    if not dt_raw:
                        continue
                    iso_dt = parse_prtg_dt(dt_raw)

                    # PRTG historicdata entries use 'value_raw' for numeric value.
                    # For multi-channel sensors keys are like 'value (channel)', try both.
                    val = entry.get('value_raw')
                    if val is None:
                        # Try any key ending in _raw that isn't coverage
                        for k, v in entry.items():
                            if k.endswith('_raw') and k != 'coverage_raw' and v not in (None, ''):
                                val = v
                                break

                    if val not in (None, ''):
                        try:
                            points.append({'t': iso_dt, 'v': round(float(val), 2)})
                        except (ValueError, TypeError):
                            pass

                print(f"PRTG history sid={sid}: {len(points)} points, sample keys={list(raw.get('histdata',[{}])[0].keys()) if raw.get('histdata') else 'no data'}")
                series[sid] = {'points': points}
            except Exception as ex:
                print(f"PRTG history error sid={sid}: {ex}")
                series[sid] = {'points': [], 'error': str(ex)}

        return jsonify({'series': series})

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'series': {}}), 500


@app.route('/api/prtg/alarms')
def get_prtg_alarms():
    """Fetch active alarms from PRTG — sensors currently in Down or Warning state"""
    try:
        import urllib.parse

        def prtg_api(path, params):
            params['username'] = PRTG_USERNAME
            params['passhash'] = PRTG_PASSHASH
            query = '&'.join(f"{k}={urllib.parse.quote(str(v))}" for k, v in params.items())
            url = f"{PRTG_SERVER}{path}?{query}"
            resp = requests.get(url, verify=False, timeout=30)
            resp.raise_for_status()
            return resp.json()

        # PRTG /api/table.json with content=alarms returns active alarm records
        raw = prtg_api('/api/table.json', {
            'content':  'alarms',
            'columns':  'objid,name,device,message,status,priority,datetime,probe,group,parent',
            'count':    '2500',
            'output':   'json'
        })

        alarms_raw = raw.get('alarms', [])

        # Filter to MSSQL group only (consistent with sensors view)
        alarms = []
        for a in alarms_raw:
            grp = a.get('group', '')
            if 'mssql' not in grp.lower():
                continue
            alarms.append({
                'id':       a.get('objid', ''),
                'name':     a.get('name', ''),
                'device':   a.get('device', ''),
                'message':  a.get('message', ''),
                'status':   a.get('status', ''),
                'priority': a.get('priority', ''),
                'datetime': a.get('datetime', ''),
                'probe':    a.get('probe', ''),
                'group':    a.get('group', ''),
            })

        # Sort: Down first, then Warning
        def alarm_rank(a):
            s = a['status'].lower()
            if 'down' in s: return 0
            if 'warn' in s: return 1
            return 2

        alarms.sort(key=alarm_rank)
        return jsonify({'alarms': alarms, 'total': len(alarms)})

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'alarms': [], 'total': 0}), 500


def _get_mock_prtg_alarm_history(days=120):
    """Generate realistic mock PRTG alarm history spread over N days"""
    devices = ['SQL-PROD-01', 'SQL-PROD-02', 'SQL-PROD-03', 'SQL-DR-01', 'SQL-DEV-01', 'SQL-RPT-01', 'SQL-STAGE-01']
    sensors = ['CPU Load', 'Memory Usage', 'Disk Free Space', 'Ping', 'SQL Server Service', 'Disk Read/Write', 'Network Traffic']
    severities = ['Down'] * 30 + ['Warning'] * 50 + ['Unusual'] * 20
    messages = [
        'CPU usage exceeds 95% for 5 minutes',
        'Memory usage above 90%',
        'Disk free space below 10%',
        'Ping timeout - device unreachable',
        'SQL Server service stopped',
        'Disk I/O latency above threshold',
        'Network packet loss detected',
        'Sensor returned unusual value',
        'Connection refused on port 1433',
        'High disk queue length detected',
        'Page Life Expectancy below threshold',
        'Buffer cache hit ratio below 95%',
    ]
    probes = ['Local Probe', 'Remote Probe DC1', 'Remote Probe DC2']
    alarms = []
    now = datetime.now(timezone.utc)
    for day_offset in range(days):
        date = now - timedelta(days=day_offset)
        count = random.randint(0, 4)
        if random.random() < 0.08:
            count = random.randint(8, 15)  # spike day
        for _ in range(count):
            severity = random.choice(severities)
            device = random.choice(devices)
            created = date.replace(hour=random.randint(0, 23), minute=random.randint(0, 59), second=random.randint(0, 59))
            resolved_mins = random.randint(5, 240) if random.random() < 0.75 else 0
            is_resolved = resolved_mins > 0 and day_offset > 0
            alarms.append({
                'id': f'PRTG-MOCK-{random.randint(10000, 99999)}',
                'name': random.choice(sensors),
                'device': device,
                'message': random.choice(messages),
                'status': severity,
                'priority': str(random.randint(1, 5)),
                'datetime': created.strftime('%Y-%m-%d %H:%M:%S'),
                'probe': random.choice(probes),
                'group': 'MSSQL',
                'resolved': is_resolved,
                'resolved_at': (created + timedelta(minutes=resolved_mins)).strftime('%Y-%m-%d %H:%M:%S') if is_resolved else '',
                'type': 'prtg_alarm'
            })
    alarms.sort(key=lambda x: x['datetime'], reverse=True)
    return alarms


@app.route('/api/prtg/alarms/history')
def get_prtg_alarm_history():
    """Get historical PRTG alarm data for heatmap and table"""
    try:
        days = int(request.args.get('days', 120))
        days = min(days, 120)

        # For now, use mock data (PRTG doesn't have a simple historical alarms API)
        # In production, you could query PRTG messages/logs API
        items = _get_mock_prtg_alarm_history(days)

        # Aggregate by date
        day_counts = {}
        devices = set()
        for item in items:
            dt_str = item.get('datetime', '')
            if dt_str:
                day_key = dt_str[:10]
                day_counts[day_key] = day_counts.get(day_key, 0) + 1
            devices.add(item.get('device', 'Unknown'))

        return jsonify({
            'heatmap': day_counts,
            'devices': sorted(devices),
            'items': items,
            'total_alarms': len(items),
            'days': days
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'items': [], 'total_alarms': 0}), 500


@app.route('/api/prtg/history/debug')
def debug_prtg_history():
    """Return raw PRTG historicdata response for a single sensor — use to verify field names"""
    try:
        import urllib.parse
        sid = request.args.get('id', '')
        if not sid:
            return jsonify({'error': 'Provide ?id=<sensor_objid>'})
        now = datetime.now()
        start = now - timedelta(hours=2)
        params = {
            'id': sid, 'avg': '300',
            'sdate': start.strftime('%Y-%m-%d-%H-%M-%S'),
            'edate': now.strftime('%Y-%m-%d-%H-%M-%S'),
            'username': PRTG_USERNAME, 'passhash': PRTG_PASSHASH, 'output': 'json'
        }
        query = '&'.join(f"{k}={urllib.parse.quote(str(v))}" for k, v in params.items())
        resp = requests.get(f"{PRTG_SERVER}/api/historicdata.json?{query}", verify=False, timeout=30)
        raw = resp.json()
        # Return top 3 entries + keys so we can see the field structure
        sample = raw.get('histdata', [])[:3]
        return jsonify({'keys': list(sample[0].keys()) if sample else [], 'sample': sample, 'channels': raw.get('channels', [])})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


def _rubrik_get_token(server):
    with _rubrik_token_lock:
        now = time.time()
        cached = _rubrik_token_cache.get(server, {})
        if cached.get('token') and cached.get('expires_at', 0) > now + 60:
            print(f'[Rubrik] Using cached token for {server}', flush=True)
            return cached['token']
        print(f'[Rubrik] Requesting new token from {server}...', flush=True)
        r = requests.post(
            f"https://{server}/api/v1/service_account/session",
            json={'serviceAccountId': RUBRIK_CLIENT_ID, 'secret': RUBRIK_CLIENT_SECRET},
            headers={'Content-Type': 'application/json', 'Accept': 'application/json'},
            verify=False, timeout=15
        )
        print(f'[Rubrik] Auth response from {server}: HTTP {r.status_code}', flush=True)
        if r.status_code != 200:
            raise ValueError(f"Rubrik auth failed for {server} HTTP {r.status_code}: {r.text[:200]}")
        token_data = r.json()
        token = token_data.get('token') or token_data.get('access_token') or token_data.get('session_token')
        if not token:
            raise ValueError(f"No token in Rubrik response from {server}. Keys: {list(token_data.keys())}")
        _rubrik_token_cache[server] = {'token': token, 'expires_at': now + 82800}
        return token


def _rubrik_get(server, path, params=None, _session=None):
    token = _rubrik_get_token(server)
    hdrs = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}
    caller = _session or requests
    url = f"https://{server}{path}"
    r = caller.get(url, headers=hdrs, params=params or {}, verify=False, timeout=30)
    r.raise_for_status()
    return r.json()


def _rubrik_get_all(server, path, params=None):
    from requests.adapters import HTTPAdapter
    session = requests.Session()
    session.mount('https://', HTTPAdapter(max_retries=1))

    params = dict(params or {})
    params['limit'] = 500
    all_data = []
    page_num = 0
    while True:
        page_num += 1
        print(f"[Rubrik] {server} {path} page {page_num} (got {len(all_data)} so far)", flush=True)
        page = _rubrik_get(server, path, params, _session=session)
        items = page.get('data', [])
        all_data.extend(items)
        print(f"[Rubrik] {server} {path} page {page_num} returned {len(items)} items, hasMore={page.get('hasMore')}", flush=True)
        if not page.get('hasMore', False) or not items:
            break
        params['after_id'] = items[-1]['id']
    return all_data


def _fmt_bytes(b):
    try:
        b = float(b)
        for unit in ['B','KB','MB','GB','TB']:
            if b < 1024: return f"{b:.1f} {unit}"
            b /= 1024
        return f"{b:.1f} PB"
    except Exception:
        return '—'


@app.route('/api/rubrik/debug/auth')
def rubrik_debug_auth():
    results = []
    hdrs = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    bare_id = RUBRIK_CLIENT_ID.split('|', 1)[-1] if '|' in RUBRIK_CLIENT_ID else RUBRIK_CLIENT_ID
    candidates = [
        {'client_id': RUBRIK_CLIENT_ID,        'client_secret': RUBRIK_CLIENT_SECRET},
        {'client_id': bare_id,                 'client_secret': RUBRIK_CLIENT_SECRET},
        {'serviceAccountId': RUBRIK_CLIENT_ID, 'secret': RUBRIK_CLIENT_SECRET},
        {'serviceAccountId': bare_id,          'secret': RUBRIK_CLIENT_SECRET},
        {'id': RUBRIK_CLIENT_ID,               'secret': RUBRIK_CLIENT_SECRET},
        {'id': bare_id,                        'secret': RUBRIK_CLIENT_SECRET},
    ]
    endpoints = [
        f"https://{RUBRIK_SERVERS[0]}/api/v1/service_account/session",
        f"https://{RUBRIK_SERVERS[0]}/api/internal/service_account/session",
    ]
    for ep in endpoints:
        for body in candidates:
            try:
                r = requests.post(ep, json=body, headers=hdrs, verify=False, timeout=10)
                results.append({'endpoint': ep, 'fields': list(body.keys()), 'status': r.status_code, 'response': r.text[:500]})
            except Exception as ex:
                results.append({'endpoint': ep, 'fields': list(body.keys()), 'status': 'error', 'response': str(ex)})
    return jsonify(results)


@app.route('/api/rubrik/hosts')
def rubrik_hosts():
    """Returns only SQL Server hosts (hosts that have MSSQL instances) across all clusters."""
    try:
        print('[Rubrik] /api/rubrik/hosts request received', flush=True)
        now = time.time()
        if _rubrik_backups_cache['data'] and (now - _rubrik_backups_cache['ts']) < _RUBRIK_CACHE_TTL:
            print('[Rubrik] Returning cached hosts', flush=True)
            return jsonify(_rubrik_backups_cache['data'])

        all_hosts = []
        errors = []
        for server in RUBRIK_SERVERS:
            try:
                print(f'[Rubrik] Fetching MSSQL instances from {server}...', flush=True)
                instances = _rubrik_get_all(server, '/api/v1/mssql/instance')
                # Build set of host IDs that have SQL instances
                sql_host_ids = set()
                sql_host_instances = {}  # host_id -> [instance_names]
                for inst in instances:
                    root = inst.get('rootProperties') or {}
                    hid = root.get('rootId', '')
                    if hid:
                        sql_host_ids.add(hid)
                        sql_host_instances.setdefault(hid, []).append(inst.get('name', ''))
                print(f'[Rubrik] {server}: {len(instances)} instances on {len(sql_host_ids)} SQL hosts', flush=True)

                # Now fetch host details only for SQL hosts
                raw_hosts = _rubrik_get_all(server, '/api/v1/host')
                for h in raw_hosts:
                    hid = h.get('id', '')
                    if hid not in sql_host_ids:
                        continue
                    name = h.get('name') or h.get('hostname', '')
                    if not name:
                        continue
                    all_hosts.append({
                        'id': hid,
                        'hostname': name,
                        'os': h.get('operatingSystemType', '') or h.get('operatingSystem', ''),
                        'agentStatus': (h.get('agentStatus') or {}).get('agentStatus', '') or h.get('status', ''),
                        'cluster': server,
                        'clusterName': '',
                        'instances': sql_host_instances.get(hid, []),
                    })
            except Exception as e:
                errors.append(f"{server}: {e}")
                print(f"[Rubrik] hosts from {server} failed: {e}", flush=True)

        all_hosts.sort(key=lambda x: x['hostname'].lower())
        result = {'hosts': all_hosts, 'totalHosts': len(all_hosts), 'clusterErrors': errors}
        _rubrik_backups_cache['data'] = result
        _rubrik_backups_cache['ts'] = time.time()
        return jsonify(result)
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'hosts': []}), 500


@app.route('/api/rubrik/cluster/summary')
def rubrik_cluster_summary():
    """Fetch summary across all Rubrik clusters."""
    try:
        clusters = []
        all_slas = []
        total_nodes = 0

        for server in RUBRIK_SERVERS:
            cl = {'ip': server}
            try:
                token = _rubrik_get_token(server)
                hdrs = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

                info = requests.get(f'https://{server}/api/v1/cluster/me', headers=hdrs, verify=False, timeout=10).json()
                cl['name'] = info.get('name', server)
                cl['version'] = info.get('version', '—')
                node_count = len(info.get('nodes', [])) if isinstance(info.get('nodes'), list) else info.get('nodeCount', 1)
                cl['nodeCount'] = node_count
                total_nodes += node_count

                slas = _rubrik_get_all(server, '/api/v1/sla_domain')
                cl['slaCount'] = len(slas)
                for s in slas:
                    all_slas.append({'id': s.get('id',''), 'name': s.get('name',''), 'cluster': cl['name']})
            except Exception as e:
                cl['name'] = server
                cl['error'] = str(e)
            clusters.append(cl)

        # Deduplicate SLA names across clusters
        seen = set()
        unique_slas = []
        for s in all_slas:
            if s['name'] not in seen:
                seen.add(s['name'])
                unique_slas.append(s)

        return jsonify({
            'clusters': clusters,
            'totalClusters': len(clusters),
            'totalNodes': total_nodes,
            'slaDomains': unique_slas,
            'totalSlas': len(unique_slas),
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/api/rubrik/host/<path:host_id>/databases')
def rubrik_host_databases(host_id):
    """On-demand: fetch databases for a single host via hierarchy → instance_id filter."""
    try:
        server = request.args.get('cluster', RUBRIK_SERVERS[0])
        print(f'[Rubrik] Fetching DBs for host {host_id} on {server}', flush=True)

        # Step 1: Get SQL instances for this host via hierarchy
        instances = _rubrik_get_all(server, f'/api/v1/mssql/hierarchy/{host_id}/children')
        print(f'[Rubrik] Host {host_id} has {len(instances)} SQL instances', flush=True)

        # Step 2: Get databases per instance using instance_id filter (which actually works)
        raw_dbs = []
        for inst in instances:
            inst_id = inst.get('id', '')
            inst_dbs = _rubrik_get_all(server, '/api/v1/mssql/db', params={'instance_id': inst_id})
            print(f'[Rubrik]   Instance {inst.get("name","?")} ({inst_id}): {len(inst_dbs)} DBs', flush=True)
            raw_dbs.extend(inst_dbs)
        print(f'[Rubrik] Total {len(raw_dbs)} DBs for host {host_id}', flush=True)

        databases = []
        status_counts = {'Protected': 0, 'Unprotected': 0, 'DoNotProtect': 0}
        for db in raw_dbs:
            sla_name = db.get('effectiveSlaDomainName') or db.get('configuredSlaDomainName') or 'Unprotected'
            if 'do_not' in sla_name.lower():
                protection = 'DoNotProtect'; status_counts['DoNotProtect'] += 1
            elif sla_name and sla_name not in ('Unprotected', 'UNPROTECTED', ''):
                protection = 'Protected'; status_counts['Protected'] += 1
            else:
                protection = 'Unprotected'; status_counts['Unprotected'] += 1

            databases.append({
                'id': db.get('id', ''),
                'name': db.get('name', '—'),
                'instance': db.get('instanceName', ''),
                'sla': sla_name,
                'protection': protection,
                'latestRecoveryPoint': db.get('latestRecoveryPoint', ''),
                'oldestRecoveryPoint': db.get('oldestRecoveryPoint', ''),
                'numMissedSnapshot': db.get('numMissedSnapshot', 0),
                'snapshotCount': db.get('snapshotCount', 0),
                'recoveryModel': db.get('recoveryModel', ''),
                'state': db.get('state', ''),
                'isRelic': db.get('isRelic', False),
                'isLiveMount': db.get('isLiveMount', False),
                'cluster': server,
            })

        databases.sort(key=lambda d: (0 if d['protection'] == 'Unprotected' else 1 if d['protection'] == 'DoNotProtect' else 2, d['name'].lower()))
        return jsonify({'databases': databases, 'total': len(databases), 'statusCounts': status_counts})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'databases': [], 'total': 0}), 500


@app.route('/api/rubrik/db/<db_id>/snapshots')
def rubrik_db_snapshots(db_id):
    try:
        server = request.args.get('cluster', RUBRIK_SERVERS[0])
        snaps_raw = _rubrik_get_all(server, f'/api/v1/mssql/db/{db_id}/snapshot')
        snapshots = []
        for s in snaps_raw:
            sz_raw = s.get('snapshotSize') or s.get('size')
            snapshots.append({
                'id': s.get('id', ''), 'date': s.get('date', ''),
                'expiry': s.get('expirationDate', ''),
                'sla': s.get('slaName', '') or (s.get('slaDomain') or {}).get('name', ''),
                'size': _fmt_bytes(sz_raw) if sz_raw else '—',
                'onDemand': s.get('isOnDemandSnapshot', False),
                'cloudState': s.get('cloudState', 0),
            })

        recoverable_ranges = []
        try:
            for r in _rubrik_get(server, f'/api/v1/mssql/db/{db_id}/recoverable_range').get('data', []):
                recoverable_ranges.append({'beginTime': r.get('beginTime', ''), 'endTime': r.get('endTime', '')})
        except Exception:
            pass

        oldest = min((r['beginTime'] for r in recoverable_ranges if r['beginTime']), default='')
        latest = max((r['endTime']   for r in recoverable_ranges if r['endTime']),   default='')
        return jsonify({'snapshots': snapshots, 'totalSnapshots': len(snapshots),
                        'recoverableRanges': recoverable_ranges, 'oldestRecovery': oldest, 'latestRecovery': latest})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'snapshots': [], 'recoverableRanges': []}), 500


@app.route('/api/dashboard/summary')
def dashboard_summary():
    """Aggregated landing page metrics from all services."""
    result = {}

    # SQL Sentry stats
    try:
        from flask import current_app
        with current_app.test_request_context():
            stats_resp = get_feed_stats()
            result['sentry'] = stats_resp.get_json() if hasattr(stats_resp, 'get_json') else {}
    except Exception:
        try:
            result['sentry'] = get_feed_stats().get_json()
        except Exception as e:
            result['sentry'] = {'error': str(e)}

    # PagerDuty
    try:
        import urllib.request, json as _json
        pd_resp = requests.get('http://127.0.0.1:5001/api/feed/pagerduty?hours=24', timeout=8)
        pd = pd_resp.json()
        triggered = sum(1 for i in pd.get('items', []) if i.get('status') == 'triggered')
        acknowledged = sum(1 for i in pd.get('items', []) if i.get('status') == 'acknowledged')
        resolved = sum(1 for i in pd.get('items', []) if i.get('status') == 'resolved')
        result['pagerduty'] = {
            'total': pd.get('total', 0),
            'triggered': triggered,
            'acknowledged': acknowledged,
            'resolved': resolved,
            'mode': pd.get('mode', ''),
        }
    except Exception as e:
        result['pagerduty'] = {'error': str(e), 'total': 0, 'triggered': 0, 'acknowledged': 0, 'resolved': 0}

    # PRTG
    try:
        prtg_resp = requests.get('http://127.0.0.1:5001/api/prtg/alarms', timeout=8)
        prtg = prtg_resp.json()
        prtg_statuses = {}
        for a in prtg.get('alarms', []):
            s = a.get('status', 'Unknown')
            prtg_statuses[s] = prtg_statuses.get(s, 0) + 1
        result['prtg'] = {
            'totalSensors': prtg.get('total', 0),
            'statuses': prtg_statuses,
        }
    except Exception as e:
        result['prtg'] = {'error': str(e), 'totalSensors': 0, 'statuses': {}}

    # Rubrik (from cache if available)
    try:
        rbk_hosts = _rubrik_backups_cache.get('data', {})
        result['rubrik'] = {
            'totalHosts': rbk_hosts.get('totalHosts', 0) if rbk_hosts else 0,
        }
    except Exception:
        result['rubrik'] = {'totalHosts': 0}

    return jsonify(result)


# ── DBCC Live Mount Dashboard ─────────────────────────────────────────────────
DBCC_SQL_DATABASE = 'admindb'
DBCC_SERVERS = {
    'ELKPRDDBC01': os.getenv('DBCC_SERVER1', 'ELKPRDDBC01'),
    'ELKPRDDBC02': os.getenv('DBCC_SERVER2', 'ELKPRDDBC02'),
}

def get_dbcc_conn(server):
    return pyodbc.connect(
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={server};"
        f"DATABASE={DBCC_SQL_DATABASE};"
        f"UID={SQL_USERNAME};"
        f"PWD={SQL_PASSWORD};"
        f"Connection Timeout=8"
    )

def _dbcc_safe(v):
    if v is None: return None
    if isinstance(v, bytes): return v.decode('utf-8', errors='replace')
    if isinstance(v, datetime): return v.isoformat()
    return v

def _dbcc_row(cursor, row):
    cols = [d[0] for d in cursor.description]
    return {cols[i]: _dbcc_safe(row[i]) for i in range(len(cols))}

def dbcc_query_all(sql, params=None, server_filter='all'):
    targets = [(l, h) for l, h in DBCC_SERVERS.items()
               if server_filter == 'all' or server_filter == l]
    results, errors = [], {}
    for label, host in targets:
        try:
            conn = get_dbcc_conn(host)
            cur  = conn.cursor()
            cur.execute(sql, params) if params else cur.execute(sql)
            for row in cur.fetchall():
                rec = _dbcc_row(cur, row)
                rec['_source_server'] = label
                results.append(rec)
            cur.close(); conn.close()
        except Exception as e:
            errors[label] = str(e)
    return results, errors

def dbcc_query_one(server_label, sql, params=None):
    host = DBCC_SERVERS.get(server_label)
    if not host:
        return None, f"Unknown server: {server_label}"
    try:
        conn = get_dbcc_conn(host)
        cur  = conn.cursor()
        cur.execute(sql, params) if params else cur.execute(sql)
        rows = [_dbcc_row(cur, r) for r in cur.fetchall()]
        cur.close(); conn.close()
        return rows, None
    except Exception as e:
        return None, str(e)

_DBCC_BASE = """
    SourceServer, TestServer, [Database],
    FileExists, RestoreStart, RestoreEnd, RestoreResult,
    TRY_CAST(RestoreElapsed AS FLOAT) AS RestoreElapsed,
    DbccStart, DbccEnd, DbccResult,
    TRY_CAST(DbccElapsed AS FLOAT) AS DbccElapsed,
    BatchTime
"""
_DBCC_DETAIL = _DBCC_BASE + ", BackupFiles"


@app.route('/dbcc/api/servers')
def dbcc_api_servers():
    out = []
    for label, host in DBCC_SERVERS.items():
        try:
            conn = get_dbcc_conn(host); conn.close()
            out.append({'label': label, 'host': host, 'online': True})
        except Exception as e:
            out.append({'label': label, 'host': host, 'online': False, 'error': str(e)})
    return jsonify({'servers': out})


@app.route('/dbcc/api/summary')
def dbcc_api_summary():
    try:
        days          = int(request.args.get('days', 30))
        server_filter = request.args.get('server', 'all')
        sql = """
            SELECT
                COUNT(*)                                                                           AS total_runs,
                SUM(CASE WHEN DbccResult = 'PASS'    THEN 1 ELSE 0 END)                           AS pass_count,
                SUM(CASE WHEN DbccResult = 'FAIL'    THEN 1 ELSE 0 END)                           AS fail_count,
                SUM(CASE WHEN DbccResult = 'ERROR'   THEN 1 ELSE 0 END)                           AS error_count,
                SUM(CASE WHEN DbccResult = 'Skipped' THEN 1 ELSE 0 END)                           AS skipped_count,
                SUM(CASE WHEN DbccResult NOT IN ('PASS','FAIL','ERROR','Skipped')
                          AND DbccResult IS NOT NULL                     THEN 1 ELSE 0 END)        AS in_progress,
                MAX(CASE WHEN DbccResult = 'PASS' THEN DbccEnd END)                               AS last_completed,
                AVG(TRY_CAST(DbccElapsed    AS FLOAT) / 60.0)                                      AS avg_dbcc_min,
                MAX(TRY_CAST(DbccElapsed    AS FLOAT))                                             AS max_dbcc_sec,
                AVG(TRY_CAST(RestoreElapsed AS FLOAT) / 60.0)                                      AS avg_restore_min,
                MAX(TRY_CAST(RestoreElapsed AS FLOAT))                                             AS max_restore_sec,
                COUNT(DISTINCT [Database])                                                         AS unique_databases
            FROM dbo.DBCCCHECK_RESTORE
            WHERE BatchTime >= DATEADD(DAY, -?, GETDATE())
        """
        rows, errors = dbcc_query_all(sql, params=[days], server_filter=server_filter)
        totals = {
            'total_runs': 0, 'pass_count': 0, 'fail_count': 0,
            'error_count': 0, 'skipped_count': 0, 'in_progress': 0,
            'avg_dbcc_min': None, 'max_dbcc_sec': None,
            'avg_restore_min': None, 'max_restore_sec': None,
            'unique_databases': 0, 'last_completed': None
        }
        dbcc_avgs, restore_avgs = [], []
        for r in rows:
            totals['total_runs']       += r.get('total_runs')       or 0
            totals['pass_count']       += r.get('pass_count')       or 0
            totals['fail_count']       += r.get('fail_count')       or 0
            totals['error_count']      += r.get('error_count')      or 0
            totals['skipped_count']    += r.get('skipped_count')    or 0
            totals['in_progress']      += r.get('in_progress')      or 0
            totals['unique_databases'] += r.get('unique_databases') or 0
            if r.get('avg_dbcc_min')    is not None: dbcc_avgs.append(r['avg_dbcc_min'])
            if r.get('avg_restore_min') is not None: restore_avgs.append(r['avg_restore_min'])
            mx_dbcc    = r.get('max_dbcc_sec')
            mx_restore = r.get('max_restore_sec')
            if mx_dbcc    and (totals['max_dbcc_sec']    is None or mx_dbcc    > totals['max_dbcc_sec']):    totals['max_dbcc_sec']    = mx_dbcc
            if mx_restore and (totals['max_restore_sec'] is None or mx_restore > totals['max_restore_sec']): totals['max_restore_sec'] = mx_restore
            lc = r.get('last_completed')
            if lc and (totals['last_completed'] is None or lc > totals['last_completed']): totals['last_completed'] = lc
        totals['avg_dbcc_min']    = round(sum(dbcc_avgs)    / len(dbcc_avgs),    1) if dbcc_avgs    else None
        totals['avg_restore_min'] = round(sum(restore_avgs) / len(restore_avgs), 1) if restore_avgs else None
        return jsonify({'summary': totals, 'server_errors': errors, 'days': days})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/dbcc/api/databases')
def dbcc_api_databases():
    try:
        days          = int(request.args.get('days', 30))
        server_filter = request.args.get('server', 'all')
        sql = f"""
            SELECT {_DBCC_BASE}
            FROM dbo.DBCCCHECK_RESTORE
            WHERE BatchTime >= DATEADD(DAY, -?, GETDATE())
            ORDER BY BatchTime DESC
        """
        rows, errors = dbcc_query_all(sql, params=[days], server_filter=server_filter)
        db_map = {}
        for r in rows:
            key = r.get('Database') or 'Unknown'
            db_map.setdefault(key, []).append(r)
        databases = []
        for db_name, runs in sorted(db_map.items()):
            latest = runs[0]
            history = [{'result': r.get('DbccResult'),
                        'restore_result': r.get('RestoreResult'),
                        'time': r.get('BatchTime'),
                        'server': r.get('_source_server')}
                       for r in runs[:10]]
            databases.append({
                'name':            db_name,
                'latest_result':   latest.get('DbccResult'),
                'restore_result':  latest.get('RestoreResult'),
                'latest_time':     latest.get('BatchTime'),
                'source_server':   latest.get('SourceServer'),
                'test_server':     latest.get('TestServer'),
                'dbcc_dur_sec':    latest.get('DbccElapsed'),
                'restore_dur_sec': latest.get('RestoreElapsed'),
                'file_exists':     latest.get('FileExists'),
                'total_runs':      len(runs),
                'pass_count':      sum(1 for r in runs if r.get('DbccResult') == 'PASS'),
                'fail_count':      sum(1 for r in runs if r.get('DbccResult') == 'FAIL'),
                'error_count':     sum(1 for r in runs if r.get('DbccResult') == 'ERROR'),
                'skipped_count':   sum(1 for r in runs if r.get('DbccResult') == 'Skipped'),
                'in_progress':     sum(1 for r in runs if r.get('DbccResult') not in
                                       ('PASS', 'FAIL', 'ERROR', 'Skipped') and r.get('DbccResult') is not None),
                'history':         history,
            })
        return jsonify({'databases': databases, 'server_errors': errors})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/dbcc/api/history')
def dbcc_api_history():
    try:
        days          = int(request.args.get('days', 30))
        server_filter = request.args.get('server', 'all')
        db_filter     = request.args.get('db', '').strip()
        result_filter = request.args.get('result', '').strip()
        page          = max(1, int(request.args.get('page', 1)))
        limit         = min(200, max(10, int(request.args.get('limit', 50))))
        where_parts = ["BatchTime >= DATEADD(DAY, -?, GETDATE())"]
        params = [days]
        if db_filter:
            where_parts.append("[Database] = ?"); params.append(db_filter)
        if result_filter:
            where_parts.append("DbccResult = ?"); params.append(result_filter)
        sql = f"""
            SELECT {_DBCC_BASE}
            FROM dbo.DBCCCHECK_RESTORE
            WHERE {' AND '.join(where_parts)}
            ORDER BY BatchTime DESC
        """
        rows, errors = dbcc_query_all(sql, params=params, server_filter=server_filter)
        rows.sort(key=lambda r: r.get('BatchTime') or '', reverse=True)
        total     = len(rows)
        start     = (page - 1) * limit
        page_rows = rows[start: start + limit]
        return jsonify({'history': page_rows, 'total': total, 'page': page,
                        'limit': limit, 'pages': (total + limit - 1) // limit,
                        'server_errors': errors})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/dbcc/api/row/<server_label>')
def dbcc_api_row_detail(server_label):
    try:
        batch = request.args.get('batch', '').strip()
        db    = request.args.get('db',    '').strip()
        svr   = request.args.get('svr',   '').strip()
        if not batch or not db or not svr:
            return jsonify({'error': 'batch, db, and svr parameters are required'}), 400
        sql = f"SELECT {_DBCC_DETAIL} FROM dbo.DBCCCHECK_RESTORE WHERE BatchTime = ? AND [Database] = ? AND SourceServer = ?"
        rows, err = dbcc_query_one(server_label, sql, params=[batch, db, svr])
        if err:      return jsonify({'error': err}), 500
        if not rows: return jsonify({'error': 'Row not found'}), 404
        row = rows[0]; row['_source_server'] = server_label
        return jsonify({'run': row})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/dbcc/api/distinct_databases')
def dbcc_api_distinct_dbs():
    try:
        days          = int(request.args.get('days', 90))
        server_filter = request.args.get('server', 'all')
        sql = """
            SELECT DISTINCT [Database] FROM dbo.DBCCCHECK_RESTORE
            WHERE BatchTime >= DATEADD(DAY, -?, GETDATE())
              AND [Database] IS NOT NULL
            ORDER BY [Database]
        """
        rows, _ = dbcc_query_all(sql, params=[days], server_filter=server_filter)
        dbs = sorted(set(r['Database'] for r in rows if r.get('Database')))
        return jsonify({'databases': dbs})
    except Exception as e:
        return jsonify({'databases': [], 'error': str(e)})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True, threaded=True)
