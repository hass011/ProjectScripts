#!/usr/bin/env python3
"""Query today's alerts from SQL Sentry"""

import pyodbc
from datetime import datetime

server = "elkcrpsql02"
database = "SentryOne"
username = "Windsirf"
password = "Cday321"

conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}"

try:
    conn = pyodbc.connect(conn_str, timeout=10)
    cursor = conn.cursor()
    
    query = """
        SELECT 
            COUNT(*) as TotalAlerts,
            SUM(CASE WHEN IsResolved = 0 THEN 1 ELSE 0 END) as ActiveAlerts,
            SUM(CASE WHEN IsResolved = 1 THEN 1 ELSE 0 END) as ResolvedAlerts,
            SUM(CASE WHEN Severity = 3 THEN 1 ELSE 0 END) as CriticalAlerts,
            SUM(CASE WHEN Severity = 2 THEN 1 ELSE 0 END) as WarningAlerts,
            SUM(CASE WHEN Severity = 1 THEN 1 ELSE 0 END) as InfoAlerts
        FROM dbo.AlertingChannelLog
        WHERE CAST(NormalizedStartTimeUtc as DATE) = CAST(GETDATE() as DATE)
    """
    
    cursor.execute(query)
    row = cursor.fetchone()
    
    print("=" * 80)
    print(f"SQL Sentry Alerts for Today ({datetime.now().strftime('%Y-%m-%d')})")
    print("=" * 80)
    print(f"\nTotal Alerts Triggered: {row.TotalAlerts or 0}")
    print(f"  - Active (Unresolved): {row.ActiveAlerts or 0}")
    print(f"  - Resolved: {row.ResolvedAlerts or 0}")
    print(f"\nBy Severity:")
    print(f"  - Critical: {row.CriticalAlerts or 0}")
    print(f"  - Warning: {row.WarningAlerts or 0}")
    print(f"  - Informational: {row.InfoAlerts or 0}")
    
    # Get top 10 alerts today
    print(f"\n{'=' * 80}")
    print("Top 10 Alerts Today:")
    print("=" * 80)
    
    query2 = """
        SELECT TOP 10
            ObjectName,
            ParentObjectName,
            NormalizedStartTimeUtc,
            NormalizedEndTimeUtc,
            Severity,
            IsResolved,
            Duration
        FROM dbo.AlertingChannelLog
        WHERE CAST(NormalizedStartTimeUtc as DATE) = CAST(GETDATE() as DATE)
        ORDER BY NormalizedStartTimeUtc DESC
    """
    
    cursor.execute(query2)
    rows = cursor.fetchall()
    
    if rows:
        for i, r in enumerate(rows, 1):
            severity_name = {1: "Info", 2: "Warning", 3: "Critical"}.get(r.Severity, "Unknown")
            status = "Resolved" if r.IsResolved else "ACTIVE"
            duration_min = r.Duration / 60000000000 if r.Duration else 0
            
            print(f"\n{i}. [{severity_name}] {r.ObjectName}")
            print(f"   Server: {r.ParentObjectName or 'N/A'}")
            print(f"   Started: {r.NormalizedStartTimeUtc}")
            print(f"   Status: {status}")
            if r.IsResolved and r.NormalizedEndTimeUtc:
                print(f"   Ended: {r.NormalizedEndTimeUtc}")
            if duration_min > 0:
                print(f"   Duration: {duration_min:.1f} minutes")
    else:
        print("\nNo alerts found for today.")
    
    cursor.close()
    conn.close()
    
    print("\n" + "=" * 80)
    
except Exception as e:
    print(f"Error: {e}")
